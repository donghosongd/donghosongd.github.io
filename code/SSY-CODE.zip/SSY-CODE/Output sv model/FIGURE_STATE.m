[lrr95,lrr80,lrr,lrr20,lrr05]      = moment2(statesim(ts:te,:,1));
[lrs95,lrs80,lrs,lrs20,lrs05]      = moment2(statesim(ts:te,:,2));
[vol195,vol180,vol1,vol120,vol105] = moment2(hsim(ts:te,:));

load recession.txt
recession = recession(6:end,:);
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.5]);
hold on
for kk = 1:length(xx), bar(xx(kk),1.5*max(lrr80),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.5*min(lrr20),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,lrr80',lrr20',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,lrr,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1)-1/12 time(end) min(1.05*min(lrr20)) max(1.05*max(lrr80)) ])


fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.5]);
hold on
for kk = 1:length(xx), bar(xx(kk),2*max(vol180),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),2*min(vol120),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol180',vol120',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol1,'Color',[0.1,0.1,0.1],'LineWidth',2)
axis([time(1)-1/12 time(end) min(1.05*min(vol120)) max(1.05*max(vol180)) ])
