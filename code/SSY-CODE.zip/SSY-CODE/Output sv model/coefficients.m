function [D,Z,PHI,SIG,RR] = coefficients(para)

%% State-Space
% Y(t) = D + Z*S(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)

mu      = para(1);
rho     = para(2);
xix     = para(3);
sigma   = para(4);

D = 3*mu;
    
PHI = [rho  0  0  0  0  0  0  0  0  0;
        1   0  0  0  0  0  0  0  0  0;
        0   1  0  0  0  0  0  0  0  0;
        0   0  1  0  0  0  0  0  0  0;
        0   0  0  1  0  0  0  0  0  0;
        0   0  0  0  0  0  0  0  0  0;
        0   0  0  0  0  1  0  0  0  0;
        0   0  0  0  0  0  1  0  0  0;
        0   0  0  0  0  0  0  1  0  0;
        0   0  0  0  0  0  0  0  1  0];       
        
        
SIG      = zeros(10,10);
SIG(1,1) = (xix*sigma)^2*(1-rho^2);
SIG(6,6) = sigma^2;

Z   = [1 2 3 2 1 1 2 3 2 1]/3;
       
RR  = 0;

        



