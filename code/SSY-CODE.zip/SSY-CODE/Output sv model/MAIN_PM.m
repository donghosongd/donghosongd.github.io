%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% load data
M = 3;
load_data
nT = length(YY.GDP);


% optimization
opt = 1;

load proposal
para = paraest;
% load prior, bound 
load prior.txt
bound;
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;
npara    = length(para);
H0       = 1e-4*eye(npara); 

% set optimization routine environment 
nit  = 1000;        % maximum number of iteration 
crit = 1E-10;       % tolerance 

%Hlast = zeros(nT,1);
load vol.txt
Hlast = vol;
%% use Sims's optimization procedure 
[ fh, xh, gh, H, itct, fcount, retcodeh ] ...
= csminwel( 'objfcn', para,  H0, [], crit, nit, Hlast, pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,opt);

paraest = real(xh);
paraest = paraest.*pmaskinv + pfix.*pmask;

savefilename = 'Posterior Mode/proposal.mat';
save(savefilename,'paraest','H','fh');

path=ls;

