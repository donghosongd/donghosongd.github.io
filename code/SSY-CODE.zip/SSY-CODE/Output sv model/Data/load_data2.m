load 1959_MONTHLY.txt
gr_mcon = X1959_MONTHLY;

%[gr_gdp,~] = xlsread('rgdp.xls');
[data2,~]=xlsread('rgdp_percapita.xls');
gr_gdp2 = data2(2:end,2) - data2(1:end-1,2);
gr_gdp2 = gr_gdp2(end-223:end);


[data,~] = xlsread('nipa.csv');
YG = data(3,3:end) - data(24,3:end);
gtime  = 1947.5:.25:2015;
nGS    = find(gtime==1959.25);
nGE    = find(gtime==2015);

gr_gdp = reshape(diff(log(YG)),[],1);
gr_gdp = gr_gdp(nGS:nGE);
YY.GDP = kron(gr_gdp,ones(3,1));
YY.CON = [0.0016;gr_mcon];

time = 1959+1/12:1/12:2015;

index = repmat([0;0;1],length(gr_gdp),1);


% stack monthly consumption only: 1959:M1 - 2014:M12
clear YCM
YCM = [];
for gg=1:M
    YCM = [YCM gr_mcon(M+1-gg:end+1-gg)];
end
top = [];
for gg=1:M-1
    top = [top gr_mcon(M-gg)];
end
top = [top 0];
YCM = [top;YCM];
YCM = [zeros(M-1,M);YCM];

YY.YCM = YCM;








load recession.txt
recession = recession(6:end,:);
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);


fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.5]);
hold on
for kk = 1:length(xx), bar(xx(kk),10,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-10,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on;
k1 = plot(time(end-223:end),gr_gdp2,'Color',[0.1 0.1 0.1],'linewidth',3);
k2 = plot(time(end-223:end),gr_gdp,'Color',[0.9 0.2 0.1],'linewidth',1,'marker','o');
hh = legend([k1,k2],'$$\Delta$$log($$Y_t$$-$$G_t$$)','$$\Delta y_t$$');
set(hh,'location','northeast','interpreter','latex');
legend('boxoff');
axis([time(end-223) time(end) 1.2*min(gr_gdp2) 1.2*max(gr_gdp2)]) 














