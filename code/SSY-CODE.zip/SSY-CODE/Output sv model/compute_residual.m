function e_vec = compute_residual(At_old,para)

% model-coefficients
[~,~,PHI,SIG,~] = coefficients(para);
       
e_vec1 = (At_old(:,1)-PHI(1,1)*At_old(:,2))./sqrt(SIG(1,1));
e_vec2 =  At_old(:,6)./sqrt(SIG(6,6));

e_vec   = [e_vec1 e_vec2];