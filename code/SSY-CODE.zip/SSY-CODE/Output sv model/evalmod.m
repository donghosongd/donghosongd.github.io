function [loglh, At_draw] = evalmod(para,sigt,YY,index,opt)

[T,~] = size(YY.GDP);

% model-coefficients
[DD,ZZ,PHIF,SIG,RR] = coefficients(para);    

mdim = size(PHIF,1);
SIGT = zeros(T,mdim);

for tt=1:T
    SIGT(tt,:) = diag(SIG);
    SIGT(tt,1) = SIGT(tt,1)*exp(2*sigt(tt,1));
    SIGT(tt,6) = SIGT(tt,6)*exp(2*sigt(tt,1));
end   

% initialization of the filter    
At = zeros(mdim,1);    
Pt = zeros(mdim,mdim);
for kk=1:100
    Pt=PHIF*Pt*PHIF'+SIG;
end

At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);

loglh = 0;

% Filter loop 
% Filter loop 
for t = 1:T

   if index(t)==1     % we have data
        MS              = 1;
        data            = YY.GDP(t);
    else
        MS   = [];
        data = [];
    end

    At1  = At;
    Pt1  = Pt;

    % Forecasting   
    alphahat = PHIF * At1 ;
    Phat     = PHIF * Pt1 * PHIF' + diag(SIGT(t,:));
    Phat     = 0.5*(Phat+Phat');
        
    if ~isempty(MS)
    
    MD = MS*DD;    
    MZ = MS*ZZ;
    MR = MS*RR*MS';        

    yhat = MD + MZ*alphahat;
    nut  = data - yhat;

    Ft = MZ*Phat*MZ' + MR;  
    Ft = 0.5*(Ft+Ft');

    invFt = eye(size(Ft,1))/Ft;
    detFt = det(Ft);       

    loglh = loglh -0.5*length(data)*log(2*pi)-0.5*log(detFt)-0.5*nut'*invFt*nut;

    % updating 
    At = alphahat + (Phat*MZ')*invFt*nut;
    Pt = Phat - (Phat*MZ')*invFt*(Phat*MZ')';   
       
    else
        
    At = alphahat;
    Pt = Phat;
    
    end
    
    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,mdim^2);

end

if opt==0
    
At_draw = zeros(T,mdim);
Yt_draw = zeros(T,1);

% singular value decomposition
[u, s, v] = svd(reshape(Pt_mat(T,:),mdim,mdim));
Pchol = u*sqrt(s);
At_draw(T,:)   = At_mat(T,:)+(Pchol*randn(mdim,1))';
Yt_draw(T,:)   = ZZ*At_draw(T,:)'; 
% Kalman Smoother 
for i = 1:T-1

    Att  = At_mat(T-i,:)';
    Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

    Phat = PHIF * Ptt * PHIF' + diag(SIGT(T-i,:));
    Phat = 0.5*(Phat+Phat');

%    inv_Phat = eye(mdim)/Phat;
    
    [Up, Sp, Vp] = svd(Phat);
    sp = diag(Sp); kp = sum(sp>1e-12);
    inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';    

    nut  = At_draw(T-i+1,:)'- PHIF*Att;

    Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
    Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   

    % singular value decomposition
    [um, sm, ~] = svd(Pmean);
    Pmchol = um*sqrt(sm);
    At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
    Yt_draw(T-i,:)   = DD + ZZ*At_draw(T-i,:)';     
end

else
    
   At_draw = At_mat;
   
end