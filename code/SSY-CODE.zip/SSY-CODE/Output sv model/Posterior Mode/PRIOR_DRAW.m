
% [para,~] = xlsread('para.xls');
% mP   = length(para);
% nsim = 1000;

load proposal
para = paraest;
mP   = length(para);
nsim = 1000;
hess      = H;

[u, s, v] = svd(hess);
Pchol     = u*sqrt(s);
hess      = Pchol*Pchol';    
paravec   = mvnrnd(para, hess,nsim)';

store   = zeros(mP,3);

for ii=1:mP
    store(ii,:) = [quantile(paravec(ii,:),0.05) quantile(paravec(ii,:),0.5) quantile(paravec(ii,:),0.95)];
end

clc;
store

















