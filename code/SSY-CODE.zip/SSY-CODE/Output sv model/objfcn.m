%==========================================================================
% This function is for defining the objective function to minimize:
% the negative of log posterior
%==========================================================================

function [retp1,retp2,At_draw]= objfcn(para,Hlast,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,opt)

if all(para > lubound(:,1) & para < lubound(:,2))     % in bounds 

    % likelihood 
    modelpara = para.*pmaskinv + pfix.*pmask;
    
    % consumption 
    [lnpY, At_draw] = evalmod(modelpara,Hlast,YY,index,opt);
    npara = length(para);

    % Evaluate the Prior distribution 
    lnprior = 0;

    for i = 1:npara
    
        if pmask(i) == 1
    
            lnprior = lnprior;
    
        else
        
        if pshape(i) == 1;      % BETA Prior
            a = (1-pmean(i))*pmean(i)^2/pstdd(i)^2 - pmean(i);
            b = a*(1/pmean(i) -1);
            lnprior = lnprior + lpdfbeta(para(i), a, b);
            
        elseif pshape(i) == 2;  % GAMMA PRIOR 
            b = pstdd(i)^2/pmean(i);
            a = pmean(i)/b;
            lnprior = lnprior + lpdfgam(para(i), a, b);
      
        elseif pshape(i) == 3;  % GAUSSIAN PRIOR 
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + lpdfnor(para(i), a, b);

        elseif pshape(i) == 4;  % INVGAMMA PRIOR 
            
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + lpdfig(para(i), a, b);

        elseif pshape(i) == 5;  % uniform prior 
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + log(1/(b-a)*all(para(i)>a & para(i)<b));

        end
    
        end    
    
    end
    
    if opt==0
        % maximize posterior
        retp1 = real( lnpY(1) + lnprior ); 
        retp2 = real( lnpY(1));
    elseif opt ==1
        % negative posterior minimization
        retp1 = -real( lnpY(1) + lnprior ); 
        retp2 = -real( lnpY(1));    
    end
        
else % out of bounds 
    
    if opt==0
        retp1 = -1E20;
        retp2 = -1E20;
    elseif opt==1
        retp1 = 1E20;
        retp2 = 1E20;
    end
    At_draw = [];
    
end

    
    
    