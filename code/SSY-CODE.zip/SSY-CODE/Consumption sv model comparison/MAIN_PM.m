%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% select frequency M = 3 quarterly, M = 12 annual
M     = 3;
% if post-war data, short = 1
short = 1;
% if optimization (i.e., no-smoothing required)
opt   = 1;
% if use only low-frequency data (make sure you select short = 1)
lowfq = 1;
% without low-frequency measurement errors
nolowfqme = 0;
% if MHCV
mhcv  = 0;
% load data      
transform_data

prior_data   
bound

% adjust again
if     lowfq==0 && nolowfqme==0
    select = [1 1 1 1 1 1]';
elseif lowfq==0 && nolowfqme==1
    select = [1 1 1 1 1 0]';    
elseif lowfq==1 && nolowfqme==0
    select = [1 1 1 1 0 1]';
elseif lowfq==1 && nolowfqme==1
    select = [1 1 1 1 0 0]';    
end
lubound  = lubound(select==1,:);
prior    = prior(select==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

%% Initial parameter values
para = [0.0016
        0.5250
        0.1991
        0.0019
        0.0018
        0.0018];    

para  = para(select==1);
npara = length(para);
H0    = 1e-3*eye(npara); 

% set optimization routine environment 
nit  = 1000;        % maximum number of iteration 
crit = 1E-15;        % tolerance 

% constant volatility
Hlast = zeros(size(YDATA,1),1);

%% use Sims's optimization procedure 
[ fh, xh, gh, H, itct, fcount, retcodeh ] ...
= csminwel( 'objfcn', para,  H0, [], crit, nit, Hlast, pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,M,index,short,opt,mhcv);

paraest = real(xh);
paraest = paraest.*pmaskinv + pfix.*pmask;

savefilename = ['Posterior Mode\proposal_data_', num2str(M) '_lowfq_' num2str(lowfq), '_nolowfqme_' num2str(nolowfqme), '.mat'];  
save(savefilename,'paraest','H','fh');

path=ls;

