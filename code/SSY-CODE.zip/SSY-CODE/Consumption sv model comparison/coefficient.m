function [D,Z,PHI,SIG,RR,D1,Z1] = coefficient(para,M)

%% State-Space
% Y(t) = D + Z*S(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)

if length(para)==6
    mu      = para(1);
    rho     = para(2);
    xix     = para(3);
    sigma   = para(4);
    sig_mem = para(5);
    sig_mea = para(6);
elseif length(para)==5 % use low-frequency data, no monthly measurement errors
    mu      = para(1);
    rho     = para(2);
    xix     = para(3);
    sigma   = para(4);
    sig_mem = 0;
    sig_mea = para(5);
elseif length(para)==4 % use low-frequency data, no measurement errors
    mu      = para(1);
    rho     = para(2);
    xix     = para(3);
    sigma   = para(4);
    sig_mem = 0;
    sig_mea = 0;    
end
PHI = zeros(7*M  ,7*M);
Z   = zeros(2*M-1,7*M);
SIG = zeros(7*M  ,7*M);

order = [2*M 4*M-1 6*M-1 7*M];

% construct PHI & SIG
for jj=1:order(end)
    if jj<=order(1)
        if jj==1
            PHI(jj,jj) = rho;
            SIG(jj,jj) = (xix*sigma)^2*(1-rho^2);
        else
            PHI(jj,jj-1) = 1;
        end
    elseif jj>order(1) && jj<=order(2)
        if jj==order(1)+1
            SIG(jj,jj) = sigma^2;
        elseif jj>(order(1)+1)
            PHI(jj,jj-1) = 1;        
        end    
    elseif jj>order(2) && jj<=order(3)
        if jj==order(2)+1
            SIG(jj,jj)   = sig_mem^2;  
        elseif jj>(order(2)+1)
            PHI(jj,jj-1) = 1;        
        end     
    elseif jj>order(3) && jj<=order(4)
        if jj==order(3)+1
            SIG(jj,jj)   = sig_mea^2;  
        elseif jj>(order(3)+1)
            PHI(jj,jj-1) = 1;        
        end     
    end
end

Z(1:2*M-1,2:order(1)) = eye(order(1)-1);
Z(1:2*M-1,order(1)+1:order(2)) = eye(order(2)-order(1));

for kk=1:2*M-1
    for jj=order(2)+1:order(3)
        if jj==order(2)+kk
            Z(kk,jj) = 1;
        elseif jj==order(2)+kk+1
            Z(kk,jj) = -1;
        end
    end
end
Z(M,order(2)+1:order(2)+M-1)     = -ones(1,M-1)/M;
Z(M,order(2)+M)                  = (M-1)/M;
Z(M,order(2)+M+2:order(2)+2*M)   = ones(1,M-1)/M;
Z(M,order(2)+M+1)                = -(M-1)/M;
Z(M,order(3)+1:order(4))         = [1 zeros(1,M-1) -1];

% construct RR
RR  = zeros(2*M-1,2*M-1);
D   = mu*ones(2*M-1,1);

D1  = mu;
Z1  = zeros(1,7*M); Z1(2) = 1; Z1(2*M+1) = 1;



