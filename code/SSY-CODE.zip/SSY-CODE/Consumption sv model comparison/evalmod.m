function [loglh, At_draw, Yt_draw] = evalmod(para,Hlast,YDATA,M,index,short,opt)
   
time   = 1930+1/12:1/12:2015;
nStart = find(time==1959+1/12); 
if short==1
    YDATA = YDATA(nStart:end,:);
    index = index(nStart:end,:);
end

T = size(YDATA,1);
% model-coefficients
[DD,ZZ,PHIF,SIG,RR,D1,Z1] = coefficient(para,M);
mZ   = size(ZZ,1);
mdim = size(PHIF,1);
SIGT = zeros(T,mdim);
for tt=1:T
    SIGT(tt,:)       = diag(SIG);
    SIGT(tt,1)       = SIG(1,1)*exp(2*Hlast(tt,1));
    SIGT(tt,2*M+1)   = SIG(2*M+1,2*M+1)*exp(2*Hlast(tt,1));
    if tt>217 && short==0
        SIGT(tt,6*M) = 0; % impose annual consumption measurement errors 1930-1948
    end
end

% initialization of the filter    
Pt = zeros(mdim,mdim);
for ii=1:100
   Pt = PHIF*Pt*PHIF' + SIG; 
end
%At = reshape(mvnrnd(zeros(mdim,1),Pt),[],1);    
At     = zeros(mdim,1);
At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);  

Yt_mat = zeros(T,mZ);
loglh  = 0;

% Filter loop 
for t = 1:T

    if index(t)==1     % we have monthly consumption data
        MS            = zeros(M,mZ);
        MS(1:M,1:M)   = eye(M);
        data          = YDATA(t,1:M)';
    elseif index(t)==M % we have low-frequency consumption data
        MS            = zeros(1,mZ);
        MS(1,:)       = ([[1:1:M] M-([1:1:M-1])])/M;
        data          = YDATA(t,1)';
    elseif index(t)==0
        MS            = [];
        data          = [];
    end
            
    At1 = At;
    Pt1 = Pt;
           
    alphahat = PHIF * At1;
    Phat     = PHIF * Pt1 * PHIF' + diag(SIGT(t,:));
    Phat     = 0.5*(Phat+Phat');
             
       
    if isempty(MS)==0
                
        MsD = MS*DD;
        MsZ = MS*ZZ; if size(MsZ,1)==1;MsZ(1,4*M:6*M-1) = 0; end % aggregation of monthly measurement erros is zero
        MsR = MS*RR*MS';
        
        yhat = MsD + MsZ*alphahat;
        nut  = data - yhat;

        Ft = MsZ*Phat*MsZ' + MsR;  
        Ft = 0.5*(Ft+Ft');  

        inv_Ft = eye(size(Ft,1))/Ft;
        det_Ft = det(Ft);    
        
        loglh = loglh -0.5*length(data)*log(2*pi)-0.5*log(det_Ft)-0.5*nut'*inv_Ft*nut;    
        loglh = real(loglh);
        
        % Updating 
        At = alphahat + (Phat*MsZ')*inv_Ft*nut;
        Pt = Phat - (Phat*MsZ')*inv_Ft*(Phat*MsZ')';            
        
    else
        
        At = alphahat;
        Pt = Phat;
    
    end

    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,(mdim)^2);   
    Yt_mat(t,:)  = DD + ZZ*At;

end


%% posterior maximization: we don't need smoother, opt == 1

if opt==0

    At_draw = zeros(T,mdim);
    Yt_draw = zeros(T,1);

    % transform variance-covariance matrix
    PtT          = reshape(Pt_mat(T,:),mdim,mdim);
    [um, sm, ~]  = svd(PtT);
    Pmchol       = um*sqrt(sm);    
    At_draw(T,:) = (At_mat(T,:)'+Pmchol*randn(mdim,1))';
    Yt_draw(T,:) = D1 + Z1*At_draw(T,:)';

    % Kalman Smoother 
    for i = 1:T-1

        Att  = At_mat(T-i,:)';
        Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

        Phat = PHIF * Ptt * PHIF' + diag(SIGT(T-i,:));
        Phat = 0.5*(Phat+Phat');

        
        [Up, Sp, Vp] = svd(Phat);
        sp = diag(Sp); kp = sum(sp>1e-12);
        inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';        
        inv_Phat = 0.5*(inv_Phat + inv_Phat');

        nut   = At_draw(T-i+1,:)'- PHIF*Att;

        Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
        Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   
        Pmean = 0.5*(Pmean+Pmean');

        % singular value decomposition
        [um, sm, ~] = svd(Pmean);
        Pmchol = um*sqrt(sm);
        At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
        Yt_draw(T-i,:)   = D1 + Z1*At_draw(T-i,:)';
    end
 
else
        At_draw = At_mat;
        Yt_draw = [];
        
end


