tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% data frequency 
M     = 12;
% if only use low-frequency data, lowfq = 1
lowfq = 1;
% if post-war data, short = 1
short = 1;
% without low-frequency measurement errors
nolowfqme = 0;

% load results
load(['result_cv_data_', num2str(M) '_lowfq_' num2str(lowfq), '_nolowfqme_' num2str(nolowfqme), '_short_' num2str(short),'.mat']);

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[zx, zx05, zx95]=moment(likesim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));

%% prior evaluation
nP = size(prior,1);
store  = zeros(nP,3);
storev = zeros(4,3);

for ii=1:nP
    a = prior(ii,2);
    b = prior(ii,3);
    
    if prior(ii,1) == 5; % uniform
        this = [a + (b-a)/20 a+(b-a)/2  b-(b-a)/20];  
    elseif prior(ii,1) == 4; % inverted gamma
        [g05, g20, g50, g80, g95]=invgamcheck(a,b);
        this = [g05 g50 g95]; 
    elseif prior(ii,1) == 3; % normal 
        temp = a + b*randn(10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];
    elseif prior(ii,1) == 2; % gamma
        [g05, g20, g50, g80, g95]=gamcheck(a,b);
        this = [g05 g50 g95];    
    elseif prior(ii,1) == 1 % beta 
        temp = betarnd(a,b,10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];    
    end
    store(ii,:) = this;
end


sum_vec1 = [store;nan(3,3)];

sum_vec2 = [[yy05' yy' yy95'];
           [nan mean(rej(1:j-1)) nan];[zx05' zx' zx95'];[yx05' yx' yx95']];
sum_vec  = [sum_vec1 sum_vec2];      
       
%% description
clc;
vartype1    = {'\mu','\rho','\varphi_x','\sigma','\sigma_{\epsilon}','\sigma_{A,\epsilon}'};
vartype2    = {'rejection','\likelihood','\posterior'};
vartype     = [vartype1(select==1) vartype2];           
disp('==============================================================================================================');   
disp('                                                                                                             '); 
disp(['                                                        Data: ', num2str(M)                                 ]);  
disp('                                                                                                             '); 
disp(['                                                        Postwar Data: ', num2str(short)                      ]);  
disp('                                                                                                             '); 
disp(['                                                        Low-frequency only: ', num2str(lowfq)                ]);  
disp('                                                                                                             '); 
disp(['                                                        Low-frequency no merror: ', num2str(nolowfqme)        ]);  
disp('                                                                                                             '); 
disp(['                                       Prior Distribution                    Posterior Draws: ', num2str(j)  ]);
disp('                                                                                                             ');
disp('==============================================================================================================');
disp([' Variable Name                       5%         50%        95%              5%        50%       95%         ']);
disp('==============================================================================================================');
for hh=1:length(vartype);
    fprintf('%-30s %10.4f %10.4f %10.4f %15.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3),sum_vec(hh,4),sum_vec(hh,5),sum_vec(hh,6));    
end
disp('==============================================================================================================');     
     


