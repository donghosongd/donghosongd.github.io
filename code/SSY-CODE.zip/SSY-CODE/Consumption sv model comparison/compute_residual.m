function e_vec = compute_residual(At_old,para,M)

% model-coefficients
[~,~,PHI,SIG,~] = coefficient(para,M);
       
e_vec1 = (At_old(:,1)-PHI(1,1)*At_old(:,2))./sqrt(SIG(1,1));
e_vec2 =  At_old(:,2*M+1)./sqrt(SIG(2*M+1,2*M+1));

e_vec   = [e_vec1 e_vec2];