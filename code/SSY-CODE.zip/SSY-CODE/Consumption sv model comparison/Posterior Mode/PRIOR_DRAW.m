%load proposal1
para = paraest;
mP   = length(para);
nsim = 1000;
hess      = H;
[u, s, v] = svd(hess);
Pchol     = u*sqrt(s);
hess      = Pchol*Pchol';    
paravec   = mvnrnd(para, hess,nsim)';

store   = zeros(mP,3);

for ii=1:mP
    [a,b,c] = moment(paravec(ii,:)');
    store(ii,:) = [b a c];
end

clc;
store

















