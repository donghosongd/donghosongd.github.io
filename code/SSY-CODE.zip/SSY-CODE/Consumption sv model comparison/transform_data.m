%% conditional on M, we compile YDATA,index (for mixed-frequency data) and YA, indexA (for low-frequency data)

% load consumption data
vm_load_data

% redefine data
if M==12
    YCA  = kron(gr_acon,ones(M,1));
    pick = 1961;
elseif M==3
    YCA  = kron(gr_qcon,ones(M,1));    
    pick = 1959+6/12; 
end

% set time and index
time         = 1930+1/12:1/12:2015;
indexM       = repmat([zeros(M-1,1);1],length(time)/M,1);
indexA       = repmat([zeros(M-1,1);M],length(time)/M,1);
cut          = find(time==pick);
indexM(1:cut) = M*indexM(1:cut);
nT           = length(time);

indexM(1:nT-size(YCA,1))  = 0;
indexA(1:nT-size(YCA,1)) = 0;

% store data
YA                          = zeros(nT,1);
YA(end-size(YCA,1)+1:end,:) = YCA;
YM                          = zeros(nT,M);
YM(end-size(YCM,1)+1:end,:) = YCM;

YD                          = zeros(nT,M);

for t = 1:nT
    if indexM(t)==1     % we have monthly consumption data 
        YD(t,1:M) = YM(t,:) ;
    elseif indexM(t)==M % we have low-frequency consumption data
        YD(t,1)   = YA(t,:);
    end
end


% final output depends on M and lowfq
if lowfq == 0
    YDATA = YD; 
    index = indexM;
elseif lowfq == 1
    YDATA = YA;
    index = indexA;
end
   

