%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% select frequency M = 3 quarterly, M = 12 annual
M     = 3;
% if post-war data, short = 1
short = 1;
% if optimization (i.e., no-smoothing required)
opt   = 1;
% if use only low-frequency data (make sure you select short = 1)
lowfq = 1;
% without low-frequency measurement errors
nolowfqme = 0;
% if MHCV
mhcv  = 1;
% load data      
transform_data

% load proposal
loadfilename = ['Posterior Mode\proposal_data_', num2str(M) '_lowfq_' num2str(lowfq), '_nolowfqme_' num2str(nolowfqme), '.mat'];  
load(loadfilename)

% import prior specification, parameter bounds
prior_data   
bound

% adjust again
if     lowfq==0 && nolowfqme==0
    select = [1 1 1 1 1 1]';
elseif lowfq==0 && nolowfqme==1
    select = [1 1 1 1 1 0]';    
elseif lowfq==1 && nolowfqme==0
    select = [1 1 1 1 0 1]';
elseif lowfq==1 && nolowfqme==1
    select = [1 1 1 1 0 0]';    
end
lubound  = lubound(select==1,:);
prior    = prior(select==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

paraold  = paraest; 
npara    = length(paraold);
sigscale = H;
fcn      = @(x1) objfcn(x1,zeros(nT,1),pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,M,index,short,opt,mhcv);
%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 2;
nsim     = 50000;
cc       = 0.5;  

%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-HASTINGS ALGORITHM                                ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold] = fcn(paraold); 
%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

for iblock = 1:nblocks
        
    % storages 
    parasim  = zeros(nsim,npara);       % parameter draws
    likesim  = zeros(nsim,1);           % likelihood
    postsim  = zeros(nsim,1);           % posterior probability
    rej      = zeros(nsim,1);           % rej = 1: rejected
    
    % with-in block loop 
    for j = 1:nsim
        
        if j==2
        disp('                                                         ');
        disp('    ESTIMATION STARTS                                     ');
        disp('                                                         ');
        end
        
        % report 
        if mod(j,100)==0
        disp('                                                         ');
        disp(['  DATA FREQ:   ',     num2str(M)]                       ); 
        disp('                                                         ');
        disp(['  SHORT DATA:   ',     num2str(short)]                  );     
        disp('                                                         ');
        disp(['  LOW-FREQUENCY DATA:   ',     num2str(lowfq)]           );        
        disp('                                                         ');
        disp(['  LOW-FREQUENCY NO MERROR:   ',     num2str(nolowfqme)]  );        
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
        disp('                                                         ');        
        disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');
        
        savefilename = ['result_cv_data_', num2str(M) '_lowfq_', num2str(lowfq) '_nolowfqme_', num2str(nolowfqme) '_short_' num2str(short), '.mat'];
        save(savefilename);
        end      
        
        % propose
        genacc=0;
        while genacc<1
            paranew = mvnrnd(paraold, cc*sigscale,1)';
            paranew = paranew.*pmaskinv + pfix.*pmask;
            genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));
        end
        
        % evaluate at the new candidate
        [postnew, likenew] = fcn(paranew);   
        
        r = min([1 exp( postnew - postold)]);            
        
        if rand > r 
           % reject proposed jump             
           rej(j) = 1;
        else
           % accept proposed jump          
           paraold = paranew;
           postold = postnew;
           likeold = likenew;
        end
        
        % store simulated variables
        parasim(j,:) = paraold';
        likesim(j,:) = likeold;
        postsim(j,:) = postold;
        
        
    end       % with-in block  

end           % block 

    
path=ls;
