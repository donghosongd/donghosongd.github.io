tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

select = 1;

load(['result_sv_model_', num2str(select), '.mat']);

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[yz, yz05, yz95]=moment(hbsim(ts:te,1:2));
[yk, yk05, yk95]=moment(hvsim(ts:te,1:2));[vk, vk05, vk95]=moment(hvsim2(ts:te,1:2));
[zx, zx05, zx95]=moment(likesim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));


%% prior evaluation
nP = size(prior,1);
store  = zeros(nP,3);
storev = zeros(4,3);

for ii=1:nP
    a = prior(ii,2);
    b = prior(ii,3);
    
    if prior(ii,1) == 5; % uniform
        this = [a + (b-a)/20 a+(b-a)/2  b-(b-a)/20];  
    elseif prior(ii,1) == 4; % inverted gamma
        [g05, g20, g50, g80, g95]=invgamcheck(a,b);
        this = [g05 g50 g95]; 
    elseif prior(ii,1) == 3; % normal 
        temp = a + b*randn(10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];
    elseif prior(ii,1) == 2; % gamma
        [g05, g20, g50, g80, g95]=gamcheck(a,b);
        this = [g05 g50 g95];    
    elseif prior(ii,1) == 1 % beta 
        temp = betarnd(a,b,10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];    
    end
    store(ii,:) = this;
end

for ii=1:2    
    temp = Hprior.R1(ii) + sqrt(Hprior.R2(ii))*randn(10000,1);
    [m50, m05, m95] = moment(temp);
    if m95>1
        m95 = 0.9999;
    end
    this = [m05 m50 m95];
    storev(ii,:) = this;
    [g05, g20, g50, g80, g95]=invgamcheck(Hprior.T(ii),Hprior.V(ii));

    storev(ii+2,:) = [g05 g50 g95];
end

sum_vec1 = [store;storev; nan(3,3)];

sum_vec2 = [[yy05' yy' yy95'];[yz05' yz' yz95'];[vk05' vk' vk95'];
           [zx05' zx' zx95'];[yx05' yx' yx95'];[nan mean(rej(1:j-1)) nan];];
sum_vec  = [sum_vec1 sum_vec2];       
       
%% description
clc;
vartype = {'\mu','\rho','\varphi_x','\sigma', '\sigma_{eps}','\rho_{s}','\varphi_{s}',...
           '\phi_{yc}','\rho_hc','\rho_hs','\sigma_hc^2','\sigma_hs^2','likelihood','posterior','rejection'}';  

disp('==============================================================================================================');   
disp('                                                                                                             '); 
disp(['                                                              Model: ', num2str(select)                      ]); 
disp('                                                                                                             '); 
disp('                                                                                                             '); 
disp('==============================================================================================================');
disp('                                                                                                             '); 
disp(['                                       Prior Distribution                    Posterior Draws: ', num2str(j)   ] );
disp('                                                                                                             ');
disp('==============================================================================================================');
disp([' Variable Name                       5%         50%        95%              5%        50%       95%         ']);
disp('==============================================================================================================');
for hh=1:length(vartype);
    fprintf('%-30s %10.4f %10.4f %10.4f %15.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3),sum_vec(hh,4),sum_vec(hh,5),sum_vec(hh,6));    
end
disp('==============================================================================================================');     
     


[vol195,vol180,vol1,vol120,vol105] = moment2(hsim(ts:te,:,1));
[vol295,vol280,vol2,vol220,vol205] = moment2(hsim(ts:te,:,2));

load recession.txt
time      = linspace(1959,2014,672);
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.25]);
subplot(2,1,1);
hold on
for kk = 1:length(xx), bar(xx(kk),2,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-2,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol180',vol120',[0.9 0.7 0.7],[0.9 0.7 0.7]);
hold on
plot(time,vol1,'Color',[0.9,0.3,0.3],'LineWidth',3)
axis([time(1) time(end) -1 1])
title('$$h_{c,t}$$')

subplot(2,1,2);
hold on
for kk = 1:length(xx), bar(xx(kk),2,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-2,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol280',vol220',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol1,'Color',[0.9,0.3,0.3],'LineWidth',3)
plot(time,vol2,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1) time(end) -1 1])
title('$$h_{s,t}$$')








