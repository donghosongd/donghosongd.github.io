function [loglh, At_draw, At_mat] = evalmod_smooth(para,Hlast,YY,index,select)
M   = 3;
T   = size(YY.GDP,1);
% model-coefficients
if select==1
[DD,ZZ,PHIF,SIG,RR] = coefficient_NoCorr(para,M);
elseif select==2
[DD,ZZ,PHIF,SIG,RR] = coefficient_Corr(para,M);
elseif select==3
[DD,ZZ,PHIF,SIG,RR] = coefficient_CorrPhi(para,M);
end
mZ   = size(ZZ,1);
mdim = size(PHIF,1);

% initialization of the filter    
Pt = zeros(mdim,mdim);
for ii=1:50
   Pt = PHIF*Pt*PHIF' + SIG; 
end
At     = zeros(mdim,1);    
At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);   
   
SIGT = zeros(T,mdim);
for tt=1:T
    SIGT(tt,:)       = diag(SIG);
    SIGT(tt,1)       = SIG(1,1)*exp(2*Hlast(tt,1));
    SIGT(tt,2*M+1)   = SIG(2*M+1,2*M+1)*exp(2*Hlast(tt,1));
    SIGT(tt,6*M)     = SIG(6*M  ,6*M)  *exp(2*Hlast(tt,2));
end

loglh  = 0;

% Filter loop 
for t = 1:T

   if index(t)==1     % we have both output and consumption growth
        MS              = zeros(M+1,mZ);
        MS(M+1,M+1:end) = ([[1:1:M] M-([1:1:M-1])])/M;
        MS(1:M,1:M)     = eye(M);     
        data            = [YY.YCM(t,:) YY.GDP(t)]';
    else
        MS   = [];
        data = [];
    end

    At1  = At;
    Pt1  = Pt;

    % Forecasting   
    alphahat = PHIF * At1 ;
    Phat     = PHIF * Pt1 * PHIF' + diag(SIGT(t,:));
    Phat     = 0.5*(Phat+Phat');
        
    if ~isempty(MS)
    
    MD = MS*DD;
    MZ = MS*ZZ;
    MR = MS*RR*MS';        

    yhat = MD+MZ*alphahat;
    nut  = data - yhat;

    Ft = MZ*Phat*MZ' + MR;  
    Ft = 0.5*(Ft+Ft');

    invFt = eye(size(Ft,1))/Ft;
    detFt = det(Ft);       

    loglh = loglh -0.5*length(data)*log(2*pi)-0.5*log(detFt)-0.5*nut'*invFt*nut;

    % updating 
    At = alphahat + (Phat*MZ')*invFt*nut;
    Pt = Phat - (Phat*MZ')*invFt*(Phat*MZ')';   
       
    else
        
    At = alphahat;
    Pt = Phat;
    
    end
    
    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,mdim^2);

end

 At_draw = zeros(T,mdim);

% singular value decomposition
[u, s, v] = svd(reshape(Pt_mat(T,:),mdim,mdim));
Pchol = u*sqrt(s);
At_draw(T,:)   = At_mat(T,:)+(Pchol*randn(mdim,1))';

% Kalman Smoother 
for i = 1:T-1

    Att  = At_mat(T-i,:)';
    Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

    Phat = PHIF * Ptt * PHIF' + diag(SIGT(T-i,:));
    Phat = 0.5*(Phat+Phat');
    
    [Up, Sp, Vp] = svd(Phat);
    sp = diag(Sp); kp = sum(sp>1e-12);
    inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
    

    nut  = At_draw(T-i+1,:)'- PHIF*Att;

    Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
    Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   

    % singular value decomposition
    [um, sm, ~] = svd(Pmean);
    Pmchol = um*sqrt(sm);
    At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
    
end
