clc;clear;
[data,~]=xlsread('rgdp_percapita.xls');

diff = data(:,2) - data(:,1);

time = 1947.25:.25:2015;

load recession.txt
recession = recession(6:end,:);
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);




nS = sum(isnan(data(:,3)))+1;

[bv,sebv,R2v,R2vadj,v,F] = olsgmm(diff(nS:end),[ones(length(diff(nS:end)),1) data(nS:end,3)],0,0);

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.5]);
hold on
for kk = 1:length(xx), bar(xx(kk),10,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-10,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
k1 = plot(time,diff - mean(diff),'Color',[0.1 0.1 0.1],'linewidth',3);
k2 = plot(time,2*bv(2)*data(:,3),'Color',[0.9 0.2 0.1],'linewidth',1,'marker','o');
hh = legend([k1,k2],'$$y_t$$-$$c_t$$','$$x_t$$');
set(hh,'location','northeast','interpreter','latex');
legend('boxoff');
axis([time(nS) time(end) 1.2*min(diff- mean(diff)) 1.1*max(diff- mean(diff))]) 



