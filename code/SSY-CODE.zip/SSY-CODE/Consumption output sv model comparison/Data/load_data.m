load 1959_MONTHLY.txt
gr_mcon = X1959_MONTHLY;

%[gr_gdp,~] = xlsread('rgdp.xls');
[data,~]=xlsread('rgdp_percapita.xls');
gr_gdp = data(2:end,2) - data(1:end-1,2);
gr_gdp = gr_gdp(end-223:end);
YY.GDP = kron(gr_gdp,ones(3,1));
YY.CON = [0.0016;gr_mcon];

time = 1959+1/12:1/12:2015;

index = repmat([0;0;1],length(gr_gdp),1);


% stack monthly consumption only: 1959:M1 - 2014:M12
clear YCM
YCM = [];
for gg=1:M
    YCM = [YCM gr_mcon(M+1-gg:end+1-gg)];
end
top = [];
for gg=1:M-1
    top = [top gr_mcon(M-gg)];
end
top = [top 0];
YCM = [top;YCM];
YCM = [zeros(M-1,M);YCM];

YY.YCM = YCM;