%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear
clc

ls = path;
path('Data',path);
path('Prior',path);
path('Moment',path);
path('Posterior Mode',path);
path('Sims Code',path);

M = 3;

load_data    
load prior.txt
bound
load selection.txt

select = 3;

prior    = prior(selection(select,:)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

lubound  = lubound(selection(select,:)==1,:);
lb = lubound(:,1);
ub = lubound(:,2);

options = psoptimset('Display', 'iter',  'UseParallel', 'always', 'CompletePoll', 'on', 'Vectorized', 'off', 'MaxIter',300);

fun = @(x) objfcn(x,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,select);

paraest =  [ 0.0017
            0.9113
            0.6650
            0.0018
            0.0018
            0.9863
           16.1250
           -1.3495
            0];

% paraest = [ 0.0017
%             0.8859
%             0.6494
%             0.0018
%             0.0018
%             0.9751
%             9.6250
%           -10.0995
%            14.2500];

paraest = paraest(selection(select,:)==1);

[x,fval,exitflag,output] = patternsearch(fun,paraest,[],[],[],[],lb,ub,[],options);

[paraest x]