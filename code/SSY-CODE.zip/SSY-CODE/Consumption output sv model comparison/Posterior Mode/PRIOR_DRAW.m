load proposal_2
para = paraest;
mP   = length(para);
nsim = 1000;
hess = H;

% hess(1,1) = 1000*hess(1,1);
% hess(2,2) = .1*hess(2,2);
% hess(6,6) = 1000*hess(6,6);
% [u, s, v] = svd(hess);
% Pchol     = u*sqrt(s);
% hess      = Pchol*Pchol';    


paravec   = mvnrnd(para, hess,nsim)';

store   = zeros(mP,3);

for ii=1:mP
    store(ii,:) = [quantile(paravec(ii,:),0.05) quantile(paravec(ii,:),0.5) quantile(paravec(ii,:),0.95)];
end

clc;
store

















