%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

% select model: there are 1 model
for select=3:3

% load prior, bound and selection matrix
load prior.txt
bound
load selection.txt

% load data
M          = 3;
load_data

% set optimization routine environment 
nit  = 1000;        % maximum number of iteration 
crit = 1E-15;        % tolerance 

%% Initial parameter values
init = [0.0016
        0.9277
        0.6375
        0.0018
        0.0018
        0.9490
        8.5313
        0
        0.5547];
H0      = 1e-4*eye(length(init));
H0(2,2) = 1e-5;
H0(7,7) = 2;
H0(8,8) = 2;
para    = init(selection(select,:)==1);   
H0      = H0(selection(select,:)==1,selection(select,:)==1);

%% redefine variables
prior    = prior(selection(select,:)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

lubound  = lubound(selection(select,:)==1,:);
lb = lubound(:,1);
ub = lubound(:,2);


%% use Sims's optimization procedure 
[ fh, xh, gh, H, itct, fcount, retcodeh ] ...
= csminwel( 'objfcn', para, H0, [], crit, nit, pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,select);

paraest = real(xh);
paraest = paraest.*pmaskinv + pfix.*pmask;

save(['Posterior Mode/proposal_', num2str(select), '.mat'],'paraest','H','fh');

end

path=ls;
