tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);


smoothed = [];
filtered = [];

for select=1:3

    load(['result_', num2str(select), '.mat'])

    ts = floor(0.15*j);
    te = floor(j-1);
    
    [para,~,~]=moment(parasim(ts:te,:));
    
    [loglh, At_draw, At_mat] = evalmod_smooth(para,YY,index,select);

    smoothed(select).lrr = At_draw(:,1);
    smoothed(select).lry = At_draw(:,19);
        
    filtered(select).lrr = At_mat(:,1);
    filtered(select).lry = At_mat(:,19);
end

time = 1959+1/12:1/12:2015;
nT   = length(time);
lrrQ = zeros(nT/3-1,3);
lryQ = zeros(nT/3-1,3);

beta  = ([[1:1:M] M-([1:1:M-1])])/M;
for ii=2:nT/3
    lrrQ(ii,1) = smoothed(1).lrr(3*(ii-2)+2:3*ii)'*beta';
    lrrQ(ii,2) = smoothed(2).lrr(3*(ii-2)+2:3*ii)'*beta';
    lrrQ(ii,3) = smoothed(3).lrr(3*(ii-2)+2:3*ii)'*beta';
    
    lryQ(ii,1) = smoothed(1).lry(3*(ii-2)+2:3*ii)'*beta';
    lryQ(ii,2) = smoothed(2).lry(3*(ii-2)+2:3*ii)'*beta';
    lryQ(ii,3) = smoothed(3).lry(3*(ii-2)+2:3*ii)'*beta';
end




scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')  
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);


% fig = figure('Position',[20,20,900,600],'Name',...
%         '','Color','w',...
%         'Position',[1 scrsz(4)/13 scrsz(3)/1 scrsz(4)/1.25]);
% subplot(2,1,1)    
% hold on
% plot(time,smoothed(1).lry,'Color',[0.1 0.1 0.1],'linewidth',1)
% plot(time,smoothed(2).lry,'Color',[0.9 0.2 0.1],'linewidth',2)
% axis tight
% subplot(2,1,2)    
% hold on
% plot(time,smoothed(1).lry,'Color',[0.1 0.1 0.1],'linewidth',1)
% plot(time,smoothed(3).lry,'Color',[0.1 0.6 0.1],'linewidth',2)
% axis tight


disp('filtered lrr correlation')
corrcoef([filtered(1).lrr filtered(2).lrr filtered(3).lrr])

disp('filtered lry correlation')
corrcoef([filtered(1).lry filtered(2).lry filtered(3).lry])















path = ls;