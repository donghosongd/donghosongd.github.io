function [loglh, At_mat] = evalmod(para,YY,index,select)
M   = 3;
T   = size(YY.GDP,1);
% model-coefficients
if select==1
[DD,ZZ,PHIF,SIG,RR] = coefficient_NoCorr(para,M);
elseif select==2
[DD,ZZ,PHIF,SIG,RR] = coefficient_Corr(para,M);
elseif select==3
[DD,ZZ,PHIF,SIG,RR] = coefficient_CorrPhi(para,M);
end
mZ   = size(ZZ,1);
mdim = size(PHIF,1);

% initialization of the filter    
Pt = zeros(mdim,mdim);
for ii=1:50
   Pt = PHIF*Pt*PHIF' + SIG; 
end
At     = zeros(mdim,1);    
At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);   
   
loglh  = 0;

% Filter loop 
for t = 1:T

   if index(t)==1     % we have both output and consumption growth
        MS              = zeros(M+1,mZ);
        MS(M+1,M+1:end) = ([[1:1:M] M-([1:1:M-1])])/M;
        MS(1:M,1:M)     = eye(M);     
        data            = [YY.YCM(t,:) YY.GDP(t)]';
    else
        MS   = [];
        data = [];
    end

    At1  = At;
    Pt1  = Pt;

    % Forecasting   
    alphahat = PHIF * At1 ;
    Phat     = PHIF * Pt1 * PHIF' + SIG;
    Phat     = 0.5*(Phat+Phat');
        
    if ~isempty(MS)
    
    MD = MS*DD;
    MZ = MS*ZZ;
    MR = MS*RR*MS';        

    yhat = MD+MZ*alphahat;
    nut  = data - yhat;

    Ft = MZ*Phat*MZ' + MR;  
    Ft = 0.5*(Ft+Ft');

    invFt = eye(size(Ft,1))/Ft;
    detFt = det(Ft);       

    loglh = loglh -0.5*length(data)*log(2*pi)-0.5*log(detFt)-0.5*nut'*invFt*nut;

    % updating 
    At = alphahat + (Phat*MZ')*invFt*nut;
    Pt = Phat - (Phat*MZ')*invFt*(Phat*MZ')';   
       
    else
        
    At = alphahat;
    Pt = Phat;
    
    end
    
    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,mdim^2);

end

 
