tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

select = 1;
load(['result_', num2str(select), '.mat'])

ts = floor(0.15*j);
te = floor(j-1);

H = 80;
irf_vecC  = zeros(nsim,H+1);
cirf_vecC = zeros(nsim,H+1);
irf_vecY  = zeros(nsim,H+1);
cirf_vecY = zeros(nsim,H+1);


for kk=ts:te

    if mod(kk-ts+1,1000)==0
        kk
    end
    
    if select==1
    [DD,Z,PHI,SIG,RR] = coefficient_NoCorr(parasim(kk,:),M);
    elseif select==2
    [DD,Z,PHI,SIG,RR] = coefficient_Corr(parasim(kk,:),M);
    elseif select==3
    [DD,Z,PHI,SIG,RR] = coefficient_CorrPhi(parasim(kk,:),M);
    end
    
    Pick = zeros(size(SIG,1),1);
    Pick(1) = 1;

    for ii=1:H+1        
        temp = PHI^(ii-1)*(reshape(sqrt(diag(SIG)),[],1).*Pick);    
        this = Z*temp;
        irf_vecC(kk,ii) = this(1);
        irf_vecY(kk,ii) = this(4);        
    end
    cirf_vecC(kk,:) = cumsum(irf_vecC(kk,:));
    cirf_vecY(kk,:) = cumsum(irf_vecY(kk,:));    
end


[aC, bC, cC]=moment(1200*cirf_vecC(ts:te,1:end-1));
[aY, bY, cY]=moment(1200*cirf_vecY(ts:te,1:end-1));

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')  
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.85 scrsz(4)/1.25]);
hold on
f90=shadedplot(1:1:H,bY,cY,[0.8 0.8 0.8],[0.1 0.1 0.1]);
hold on
k1 = plot(aY,'Color',[0.1 0.1 0.1],'LineWidth',4);
k2 = plot(aC,'Color',[0.9 0.2 0.1],'LineWidth',3,'marker','o');
hh = legend([k1,k2],'$$\Delta y_t$$','$$\Delta c_t$$');
set(hh,'location','south','interpreter','latex','orientation','horizontal');
legend('boxoff');
axis([1 H 1.2*min(bY) max(cY)])
%axis([1 H -1 8])
ylabel('Cumulative Impulse')
xlabel('Months')