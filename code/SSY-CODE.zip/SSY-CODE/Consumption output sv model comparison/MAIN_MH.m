%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

% select model: there are 3 models
for select=1:1

% load prior, bound and selection matrix
load prior.txt
bound;
load selection.txt

% load data
M          = 3;
load_data

%% redefine variables
prior    = prior(selection(select,:)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

lubound  = lubound(selection(select,:)==1,:);
lb = lubound(:,1);
ub = lubound(:,2);

% load proposal
load(['proposal_', num2str(select), '.mat'])

paraold  = paraest;
npara    = length(paraold);
sigscale = H;
fcn      = @(x1) objfcn_MH(x1,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,select);
%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 30000;
cc       = .5;  
%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-WITHIN-GIBBS ALGORITHM                             ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold, At_draw] = fcn(paraold);
    
%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------
        
% storages 
parasim  = zeros(nsim,npara);       % parameter draws
likesim  = zeros(nsim,1);           % likelihood
postsim  = zeros(nsim,1);           % posterior probability
rej      = zeros(nsim,1);           % rej = 1: rejected

% with-in block loop 
for j = 1:nsim
    if j==2
    disp('                                                         ');
    disp('    ESTIMATION STARTS                                     ');
    disp('                                                         ');
    end
    % propose   
    genacc=0;
    while genacc<1
        paranew = mvnrnd(paraold, cc*sigscale,1)';
        paranew = paranew.*pmaskinv + pfix.*pmask;
        genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));        
    end

    % evaluate at the new candidate 
    [postnew, likenew] = fcn(paranew);         

    r = min([1 exp( postnew - postold)]);            

    if rand > r 
       % reject proposed jump             
       rej(j) = 1;
    else
       % accept proposed jump          
       paraold = paranew;
       postold = postnew;
       likeold = likenew;
    end

    % store simulated variables
    parasim(j,:) = paraold';
    likesim(j,:) = likeold;
    postsim(j,:) = postold;

    %% report 
    if mod(j,1000)==0        
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
    disp('                                                         ');        
    disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
    disp('                                                         ');
    disp(['  MODEL :   ',    num2str(select)]                 );
    disp('                                                         ');
    disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
    disp('                                                         ');
    savefilename = ['result_', num2str(select), '.mat'];
    save(savefilename);
    end
end       % with-in block  

end           % models
     
path=ls;
