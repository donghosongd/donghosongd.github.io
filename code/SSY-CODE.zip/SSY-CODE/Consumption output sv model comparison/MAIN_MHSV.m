%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

% select model: there are 3 models
for select=1:3

% load prior, bound and selection matrix
load prior.txt
bound;
load selection.txt

% load data
M = 3;
load_data
nT = size(YY.GDP,1);
%% redefine variables
prior    = prior(selection(select,:)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

lubound  = lubound(selection(select,:)==1,:);
lb = lubound(:,1);
ub = lubound(:,2);

% load proposal
load(['proposal_', num2str(select), '.mat'])

paraold  = paraest;
npara    = length(paraold);
sigscale = H;
fcn      = @(x1,x2) objfcn_MHSV(x1,x2,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YY,index,select);

%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 50000;
cc       = 1;  

% prior for SV
Hprior.R1 = [0.80  0.80]; %mean
Hprior.R2 = [0.1   0.1 ]'; %variance
Hprior.T  = [1.5   1.5 ];
Hprior.V  = [.005  .005];
% unit-root
Hprior.unitroot = 0;
    
Rlast = [0.99 0.99]';
% prior for stochastic volatilities
in_shat       = zeros(2,1);  
Vlast         = [0.005 0.005]';
Hlast         = zeros(nT,2);
Hlast(1,:)    =(in_shat(:))';
for zz=2:nT
    Hlast(zz,:)=(diag(Hprior.R1)*Hlast(zz-1,:)'+mvnrnd(zeros(2,1),diag(Vlast.*(1-Rlast.^2)),1)')';
end 
% check prior moments
wshock  = gamrnd(Hprior.T(1),1/Hprior.V(1),100000,1);
VlastUB = quantile(1./wshock,0.975);
%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-WITHIN-GIBBS ALGORITHM                             ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold, At_old] = fcn(paraold,Hlast); 

%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

for iblock = 1:nblocks
        
    % storages 
    parasim  = zeros(nsim,npara);       % parameter draws
    likesim  = zeros(nsim,1);           % likelihood
    postsim  = zeros(nsim,1);           % posterior probability
    rej      = zeros(nsim,1);           % rej = 1: rejected
    statesim = zeros(nsim,nT,3);
    hsim     = zeros(nsim,nT,2);
    hbsim    = zeros(nsim,2);
    hvsim    = zeros(nsim,2);
    hvsim2   = zeros(nsim,2);
    % with-in block loop 
    for j = 1:nsim
        
        if j==2
        disp('                                                         ');
        disp('    ESTIMATION STARTS                                     ');
        disp('                                                         ');
        end
        
        % report 
        if mod(j,100)==0
        
        disp(['  MODEL:   ',              num2str(select)]              );
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
        disp('                                                         ');        
        disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - VOL PER:   ',    num2str(median(hbsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - VOL VAR:   ',    num2str(10000*median(hvsim2(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');

        savefilename = ['result_sv_model_', num2str(select), '.mat'];
        save(savefilename);
        
        end      
        
        % propose
        genacc=0;
        while genacc<1
            paranew = mvnrnd(paraold, cc*sigscale,1)';
            paranew = paranew.*pmaskinv + pfix.*pmask;
            genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));
        end
        
        % evaluate at the new candidate
        [postnew, likenew, At_new] = fcn(paranew,Hlast);   
        % evaluate at the old candidate              
        [postold, likeold, At_old] = fcn(paraold,Hlast);    
       
        r = min([1 exp( postnew - postold)]);            
        
        if rand > r 
           % reject proposed jump             
           rej(j) = 1;
        else
           % accept proposed jump          
           paraold = paranew;
           postold = postnew;
           likeold = likenew;
           At_old  = At_new;
        end
        
        % store simulated variables
        statesim(j,:,:) = [At_old(:,1) At_old(:,2*M+1) At_old(:,6*M)]; 
        parasim(j,:) = paraold';
        likesim(j,:) = likeold;
        postsim(j,:) = postold;
                
        % construct normalized residuals
        e_vec11 = (At_old(:,1)-paraold(2)*At_old(:,2))./(sqrt(1-paraold(2)^2)*paraold(3)*paraold(4));
        e_vec12 = At_old(:,2*M+1)./paraold(4);
        e_vec2  = (At_old(:,6*M)-paraold(6)*At_old(:,6*M+1))./(sqrt(1-paraold(6)^2)*paraold(7)*paraold(4)); 
        
        % order: LRR CONS DIVD      
        % LRR, CONS: common-SV
        e_vec1 = [e_vec11 e_vec12];
        [Hlast1,Rlast1,Vlast1] = step_sv_multivariate(e_vec1,Hlast(:,1),Rlast(1),Vlast(1),Hprior);  
        % DIV: single SV
        [Hlast2,Rlast2,Vlast2] = step_sv(e_vec2,Hlast(:,2),Rlast(2),Vlast(2),Hprior);
        Hlast = [Hlast1 Hlast2];
        Rlast = [Rlast1;Rlast2];
        Vlast = [Vlast1;Vlast2]; 
        
        % set upper bound: cannot allow too much time-variations
        for jj=1:2
            Hlast(:,jj) = Hlast(:,jj)-mean(Hlast(:,jj));
        end       
        % cannot exceed upper bound: 97.5% of prior distribution
        vindex = Vlast>VlastUB;
        Vlast(vindex==1) = VlastUB;
        
        hsim(j,:,1) = Hlast(:,1)'; hbsim(j,1) = Rlast(1); hvsim(j,1) = sqrt(Vlast(1)/(1-Rlast(1)^2)); hvsim2(j,1) = Vlast(1);
        hsim(j,:,2) = Hlast(:,2)'; hbsim(j,2) = Rlast(2); hvsim(j,2) = sqrt(Vlast(2)/(1-Rlast(2)^2)); hvsim2(j,2) = Vlast(2);   
                
    end       % with-in block  

end           % block 

end
%=========================================================================
%                    DISPLAY ESTIMATION RESULTS
%=========================================================================

     
path=ls;

elapsedtime=toc;