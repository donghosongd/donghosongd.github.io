function [D,Z,PHI,SIG,RR] = coefficient_Corr(para,M)

%% State-Space
% Y(t) = D + Z*S(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)

mu      = para(1);
rho     = para(2);
xix     = para(3);
sigma   = para(4);
sig_mem = para(5);
rho_g   = para(6);
xig     = para(7);
alpha   = para(8);
phi     = para(9);

PHI = zeros(8*M  ,8*M);
Z   = zeros(3*M-1,8*M);
SIG = zeros(8*M  ,8*M);

order = [2*M+1 4*M 6*M 8*M];

% construct PHI & SIG
for jj=1:order(end)
    if jj<=order(1)
        if jj==1
            PHI(jj,jj) = rho;
            SIG(jj,jj) = (xix*sigma)^2*(1-rho^2);
        else
            PHI(jj,jj-1) = 1;
        end
    elseif jj>order(1) && jj<=order(2)
        if jj==order(1)+1
            SIG(jj,jj) = sigma^2;
        elseif jj>(order(1)+1)
            PHI(jj,jj-1) = 1;        
        end      
    elseif jj>order(2) && jj<=order(3)
        if jj==order(2)+1
            SIG(jj,jj)   = sig_mem^2;  
        elseif jj>(order(2)+1)
            PHI(jj,jj-1) = 1;        
        end   
    elseif jj>order(3) && jj<=order(4)
        if jj==order(3)+1
            PHI(jj,jj) = rho_g;
            SIG(jj,jj) = (phi*xix*sigma)^2*(1-rho_g^2)+(xig*sigma)^2*(1-rho_g^2);
            SIG(jj,1)  = sqrt(1-rho_g^2)*sqrt(1-rho^2)*phi*(xix*sigma)^2;
            SIG(1,jj)  = sqrt(1-rho_g^2)*sqrt(1-rho^2)*phi*(xix*sigma)^2;
        elseif jj>(order(3)+1)
            PHI(jj,jj-1) = 1;        
        end     
    end
end

for kk=1:M
for jj=order(2)+1:order(3)
    if jj==order(2)+kk
        Z(kk,jj) = 1;
    elseif jj==order(2)+kk+1
        Z(kk,jj) = -1;
    end
end
end

Z(1:M,2:1+M)                     = eye(M);
Z(1:M,order(1)+1:order(1)+M)     = eye(M);
% Z(M,order(2)+1:order(2)+M-1)     = -ones(1,M-1)/M;
% Z(M,order(2)+M)                  = (M-1)/M;
% Z(M,order(2)+M+2:order(2)+2*M)   = ones(1,M-1)/M;
% Z(M,order(2)+M+1)                = -(M-1)/M;
    
Z(M+1:end,2:order(1)) = (1+alpha)*[eye(2*M-1) zeros(2*M-1,1)] - alpha*[zeros(2*M-1,1) eye(2*M-1) ]; 
Z(M+1:end,order(1)+1:order(2)) = eye(2*M-1);
Z(M+1:end,order(3)+1:end)      = [eye(2*M-1) zeros(2*M-1,1)] - [zeros(2*M-1,1) eye(2*M-1) ]; 



% construct RR
RR  = zeros(3*M-1,3*M-1);
D   = [mu*ones(M,1);mu*ones(2*M-1,1)];



