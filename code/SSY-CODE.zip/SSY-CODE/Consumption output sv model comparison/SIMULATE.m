tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

select = 3;
load(['result_', num2str(select), '.mat'])

ts = floor(0.15*j);
te = floor(j-1);
nT = 672;
if select==1
[D,Z,PHI,SIG,RR] = coefficient_NoCorr(parasim(1,:),M);
elseif select==2
[D,Z,PHI,SIG,RR] = coefficient_Corr(parasim(1,:),M);
elseif select==3
[D,Z,PHI,SIG,RR] = coefficient_CorrPhi(parasim(1,:),M);
end
mdim = size(PHI,1);
svec = zeros(nsim,mdim);
yvec = zeros(nsim,nT);
cvec = zeros(nsim,nT);
cQvec = zeros(nsim,nT/3-1);
yQvec = zeros(nsim,nT/3-1);
aQvec = zeros(nsim,2);

beta  = ([[1:1:M] M-([1:1:M-1])])/M;

for kk=ts:te
    if mod(kk-ts+1,1000)==0
        kk
    end
    
    if select==1
    [D,Z,PHI,SIG,RR] = coefficient_NoCorr(parasim(kk,:),M);
    elseif select==2
    [D,Z,PHI,SIG,RR] = coefficient_Corr(parasim(kk,:),M);
    elseif select==3
    [D,Z,PHI,SIG,RR] = coefficient_CorrPhi(parasim(kk,:),M);
    end
    
    for tt=1:nT
        if tt>1
        svec(tt,:) = PHI*svec(tt-1,:)' + sqrt(diag(SIG)).*randn(mdim,1);
        else
        svec(tt,:) = sqrt(diag(SIG)).*randn(mdim,1);            
        end
        temp       = D + Z*svec(tt,:)';
        cvec(kk,tt) = temp(1);
        yvec(kk,tt) = temp(M+1);        
    end      
    
    for tt=2:nT/3
        cQvec(kk,tt-1) = cvec(kk,3*(tt-2)+2:3*tt)*beta';  
        yQvec(kk,tt-1) = yvec(kk,3*(tt-2)+2:3*tt)*beta';   
    end
    
    aQvec(kk,1) = [0 1]*autocorr(cQvec(kk,:)',1);
    aQvec(kk,2) = [0 1]*autocorr(yQvec(kk,:)',1);
    
end

[ac,bc,cc] = moment(aQvec(ts:te,:));

[bc' ac' cc']




