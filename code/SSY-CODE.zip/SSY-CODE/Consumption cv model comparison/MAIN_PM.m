%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

% select model: there are 9 models
for select=1:9

% load prior and selection matrix
[prior,~]          = xlsread('prior.xls');
[para_index,vname] = xlsread('selection.xls');

% load data
M          = 12;
vm_load_data
YY         = [0.0016;gr_mcon];
YCM(12,12) = 0.0016;

% set index
if select==1 || select==4 || select==5 || select==6
    index = repmat([zeros(11,1);1],672/12,1);
else
    index = 2*ones(672,1);
end

% set optimization routine environment 
nit  = 1000;        % maximum number of iteration 
crit = 1E-15;        % tolerance 


%% Initial parameter values
% 1   2    3   4   5     6       7         8          9      10     11   12
% mu,rho,rho2,xix,xix2,sigma,sigma_eps,sigma_eps^a,rho_eps,rho_eta,zeta1,zeta2
init  = [0.0016 0.9 0.05  0.70 0.70 0.002 0.0018 0.0018 0.02 0.02 -1.13 0.3]';
if select==2; % NoME model
    init(2) = -0.3;
    init(5) = 1.7;
end
% bound
bound    = [[-0.002  0.002]; %1
            [-0.9999 0.9999];%2
            [-0.9999 0.9999];%3
            [1e-10   0.9999];%4
            [1e-10   1.9999];%5
            [1e-10   0.0500];%6
            [1e-10   0.0500];%7
            [1e-10   0.0500];%8
            [-0.9999 0.9999];%9
            [-0.9999 0.9999];%10
            [-10     10];    %11
            [-10     10]];   %12             

% re-define
para     = init(para_index(:,select)==1);
bound    = bound(para_index(:,select)==1,:);
npara    = length(para);
H0       = 1e-4*eye(npara);
prior    = prior(para_index(:,select)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

%% use Sims's optimization procedure 
[ fh, xh, gh, H, itct, fcount, retcodeh ] ...
= csminwel( 'objfcn', para, H0, [], crit, nit, pshape,pmean,pstdd,pmask,pmaskinv,pfix,bound,YCM,YY,index,select);

paraest = real(xh);
paraest = paraest.*pmaskinv + pfix.*pmask;

savefilename = ['proposal_', num2str(select), '.mat'];
save(savefilename,'paraest','H','fh');

end

path=ls;
