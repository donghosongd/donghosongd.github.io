%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

para_vec  = nan(12,9);
loglh_vec = zeros(9,1);

% select model: there are 9 models
for select=1:9

% load prior and selection matrix
[prior,~]          = xlsread('prior.xls');
[para_index,vname] = xlsread('selection.xls');

% load data
M          = 12;
vm_load_data
YY         = [0.0016;gr_mcon];
YCM(12,12) = 0.0016;

% set index
if select==1 || select==4 || select==5 || select==6
    index = repmat([zeros(11,1);1],672/12,1);
else
    index = 2*ones(672,1);
end

% load proposal
load(['proposal_', num2str(select), '.mat'])

% evaluate likelihood
[loglh, At_mat] = evalmod(paraest,YCM,YY,index,select);

loglh_vec(select)  = loglh;
para_vec(1:length(paraest),select) = paraest; 

end

path=ls;