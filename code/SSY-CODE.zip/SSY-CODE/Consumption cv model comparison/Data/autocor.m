 scrsz = get(0,'ScreenSize');
    fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/20 scrsz(3)/1 scrsz(4)/1.5]);     
    set(0,'DefaultAxesColorOrder',[0 0 0],...      
    'DefaultAxesFontSize',20,... 
    'DefaultLineLineWidth',2,...
    'defaulttextinterpreter','latex')

subplot(1,3,1)
autocorr(gr_mcon,10)
set(gca,'FontSize',20)
axis([.5 10 -0.3 .5])
subplot(1,3,2)
autocorr(gr_qcon,10)
set(gca,'FontSize',20)
axis([.5 10 -0.3 .5])
subplot(1,3,3)
autocorr(gr_acon,10)
set(gca,'FontSize',20)
axis([.5 10 -0.3 .5])

nK = size(gr_mcon)+1;


    fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/20 scrsz(3)/1 scrsz(4)/1.5]);     
    set(0,'DefaultAxesColorOrder',[0 0 0],...      
    'DefaultAxesFontSize',20,... 
    'DefaultLineLineWidth',2,...
    'defaulttextinterpreter','latex')

subplot(1,3,1)
autocorr(gr_mcon,10)
set(gca,'FontSize',20)
subplot(1,3,2)
autocorr(gr_qcon(end-nK/3+1:end),10)
set(gca,'FontSize',20)
subplot(1,3,3)
autocorr(gr_acon(end-nK/12+1:end),10)
set(gca,'FontSize',20)













