
vm_load_data2

tYY = zeros(996,5);

tYY(end-size(YCM(12:end,1),1)+1:end,1) = YCM(12:end,1);
tYY(end-size(YCQ(4:end,1),1)+1:end,2)  = YCQ(4:end,1);
tYY(:,3) = YCA;
tYY(:,4:5) = YF;

load recession.txt
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

mt = 1929+1/12:1/12:2012;

scrsz = get(0,'ScreenSize');

varname = {'Real Monthly Consumption Growth',...
           'Real Quarterly Consumption Growth',...
           'Real Annual Consumption Growth',...
           'Real Monthly Dividend Growth',...
           'Real Market Returns'};

vselect = [1 3 5 2 4];       
fselect = [0.9 1.1 1.3 0.9 0.9];

fig=figure('Position',[20,20,900,600],'Name',...
        'State','Color','w',...
        'Position',[1 scrsz(4)/15 scrsz(3)/1.1 scrsz(4)/1.1]); 
    
for jj=1:3
subplot(3,2,vselect(jj))    
plot(mt,tYY(:,jj),'Color',[0.1 0.1 0.1],'LineWidth',fselect(jj))
title(varname(jj),'FontSize',12)
hold on
for kk = 1:length(xx), bar(xx(kk),1.1*max(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.1*min(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end 
axis([mt(2) mt(end) 1.1*min(tYY(:,jj)) 1.1*max(tYY(:,jj))])
alpha(0.9)
end

for jj=4:5
subplot(3,2,vselect(jj))    
plot(mt,tYY(:,jj),'Color',[0.1 0.1 0.1],'LineWidth',1.1)
title(varname(jj),'FontSize',12)
hold on
for kk = 1:length(xx), bar(xx(kk),1.1*max(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.1*min(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end 
axis([mt(2) mt(end) 1.1*min(tYY(:,jj)) 1.1*max(tYY(:,jj))])
alpha(0.9)
end

fig2=figure('Position',[20,20,900,600],'Name',...
        'State','Color','w',...
        'Position',[1 scrsz(4)/15 scrsz(3)/1.5 scrsz(4)/1.1]); 
    
for jj=1:3
subplot(3,1,jj)    
plot(mt,tYY(:,jj),'Color',[0.1 0.1 0.1],'LineWidth',fselect(jj))
title(varname(jj),'FontSize',12)
hold on
for kk = 1:length(xx), bar(xx(kk),1.1*max(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.1*min(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end 
axis([mt(2) mt(end) 1.1*min(tYY(:,jj)) 1.1*max(tYY(:,jj))])
alpha(0.9)
end

fig3=figure('Position',[20,20,900,600],'Name',...
        'State','Color','w',...
        'Position',[1 scrsz(4)/15 scrsz(3)/1.5 scrsz(4)/1.1]); 
    
for jj=4:5
subplot(3,1,jj-3)    
plot(mt,tYY(:,jj),'Color',[0.1 0.1 0.1],'LineWidth',0.9)
title(varname(jj),'FontSize',12)
hold on
for kk = 1:length(xx), bar(xx(kk),1.1*max(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.1*min(tYY(:,jj)),ww(kk),'FaceColor',[0.7 0.7 0.7],'EdgeColor','w'), end 
axis([mt(2) mt(end) 1.1*min(tYY(:,jj)) 1.1*max(tYY(:,jj))])
alpha(0.9)
end


saveas(fig2,'LRRconsumption.bmp');
saveas(fig3,'LRRfinancial.bmp');