%% REAL PERSONAL CONSUMPTION EXPENDITURE
load 1959_MONTHLY.txt
load 1947_QUARTERLY.txt
load 1930_ANNUAL.txt

gr_mcon = X1959_MONTHLY;
gr_qcon = X1947_QUARTERLY;
gr_acon = X1930_ANNUAL;

y2_vec = kron((gr_qcon),ones(3,1));
y3_vec = kron((gr_acon),ones(12,1));

% stack financial variables: 1929:M1 - 2011:M12
%vm_generate_LRRdata
load YF.txt

% stack monthly consumption only: 1959:M1 - 2011:M12
clear YCM
YCM = [];
for gg=1:M
    YCM = [YCM gr_mcon(M+1-gg:end+1-gg)];
end
top = [];
for gg=1:M-1
    top = [top gr_mcon(M-gg)];
end
top = [top 0];
YCM = [top;YCM];
YCM = [zeros(M-1,M);YCM];

% stack quarterly consumption: 1947:Q1 - 2014:Q4 
YCQ = zeros(68*12,1);
YCQ(end-length(y2_vec)+1:end) = y2_vec;


that = nan(12,1);that(12) = 1;
iu = kron(ones(86,1),that);
iu(12) = nan;

% stack annual consumption: 1929 - 2014
YCA = zeros(86*12,1);
YCA(end-length(y3_vec)+1:end) = y3_vec;
YCA = YCA.*iu;

% selection matrix: MF
minM = 3;
mmatrix  = [zeros(minM-1,minM);ones(1,minM)];
mmatrix  = repmat(mmatrix,(length(gr_mcon)+1)/minM,1);

this = zeros(M,M);
for tt=1:M-1
    this(tt,tt+1:M) = 1;
end
this(M,:) = 1;
that = zeros(M,M); that(M,:) = 1;

mmatrix2  = repmat(this,672/M-1,1);
mmatrix2  = [that;mmatrix2];


% selection matrix: LF(M) 
lmatrix  = [zeros(M-1,2*M-1); ([[1:1:M] M-([1:1:M-1])])/M];

if M==3
    lmatrix = repmat(lmatrix,size(YCQ,1)/M,1);
elseif M==12
    lmatrix = repmat(lmatrix,size(YCA,1)/M,1);
end

information.YCM = YCM;
information.YCQ = YCQ;
information.YCA = YCA;
information.YF  = YF;
information.mmatrix = mmatrix;
information.mmatrix2 = mmatrix2;
information.lmatrix = lmatrix;
information.M   = M;
