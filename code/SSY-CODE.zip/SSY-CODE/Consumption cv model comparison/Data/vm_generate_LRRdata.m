% 1926:M1 - 2011:M12
load crsp_stock.txt

% value-weighted index including distributions
vwretd = crsp_stock(:,2);
% value-weighted index excluding distributions
vwretx = crsp_stock(:,3);

dT = size(crsp_stock,1);

price = zeros(dT,1);

% normalize price(0)=1
price(1) = 1+vwretx(1);
for t=2:dT
    price(t) = price(t-1)*(1+vwretx(t));
end

dividend  = zeros(dT,1);
dividend2 = zeros(dT,1);
dividend2(1) = (vwretd(1)-vwretx(1));
for t=1:dT
    dividend(t)  = price(t)*( (1+vwretd(t))/(1+vwretx(t))-1 );
    if t>1
        dividend2(t) = price(t-1)*(vwretd(t)-vwretx(t));
    end    
end


% load the one-month Treasury-bill return 1926:M1 - 2011:M12
load tbill.txt
tbill = ones(dT,1)+tbill(:,2);

prod_i = zeros(12,dT/12);

for tt=2:dT/12
    clear temp
    temp  = [];
    
    for jj=1:11
        temp  = [temp prod(tbill(12*(tt-1)-11+jj:12*(tt-1)))];
    end
    temp  = [temp tbill(12*(tt-1))*tbill(12*(tt-1)+1)];
    prod_i(:,tt) = temp';
end

clear temp
temp  = [];
    
for jj=1:11
    temp  = [temp prod(tbill(12*(dT/12)-11+jj:12*(dT/12)))];
end

prod_i = [prod_i [temp temp(end)]'];

prodi = reshape(prod_i,dT+12,1);
prodi = prodi(13:end);

prodd  = dividend.*prodi;
prodd2 = dividend2.*prodi;

sumdiv  = zeros(dT-11,1); % 1926:M12 - 2011:M12
sumdiv2 = zeros(dT-11,1); % 1926:M12 - 2011:M12

for t=12:dT 
    sumdiv(t)  = sum(prodd(t-11:t));
    sumdiv2(t) = sum(prodd2(t-11:t));
end

% load CPIAUCNS.txt 
load CPIAUCNS.txt
CPI = CPIAUCNS(1:end-3,2); %1926:M1 - 2011:M12
cpi = CPIAUCNS(1:end,2);   %1926:M1 - 2012:M3

% construct inflation 1927:M1 - 2011:M12
INF = log(CPI(2:end))-log(CPI(1:end-1));
INF = INF(12:end);

% construct real dividend and real price
rdivid = zeros(dT,1);
rprice = zeros(dT,1);
for t=1:dT
    rdivid(t) = sumdiv(t)*CPI(end)/CPI(t);
    rprice(t) = price(t)*CPI(end)/CPI(t);
end

rpdratio = zeros(dT,1);

for t=1:dT
    rpdratio(t) = log(rprice(t)./rdivid(t));
end



% construct real market returns 1927:M1 - 2011:M12
vwretx_ = vwretd(13:end);
rmkt_returns = log(1+vwretx_) - INF;

% construct real returns 1927:M1-2011:M12
rreturn = zeros(dT-12,1);

for t=1:dT-12
    rreturn(t) = (rprice(t+12)+rdivid(t+12))/rprice(t+11);
end

% truncate real dividend, real price, real mkt returns 1927:M1-2011:M12
rdivid = rdivid(13:end);
rprice = rprice(13:end);


% load CRSP Fama Risk Free Rates 1926:M1 - 2011:M12
% date bid_1 ave_1 bid_3 ave_3
% use ave_3
load risk_free.txt
% 1927:M1-2011:M12
rfree = log(1+risk_free(13:end,5)/100);

% create inf_{t,t-12} and inf_{t,t-3}: truncate to 1927:M1-2011:M12
inf12 = (log(CPI(13:end))-log(CPI(1:end-12)));
inf3  = log(cpi(4:end))-log(cpi(1:end-3));
inf3  = inf3(end-length(inf12)+1:end);

LHS   = rfree-4*inf3;
RHS   = [ones(length(LHS),1) rfree inf12];
bols  = regress(LHS,RHS);
exante_rfree = RHS*bols/12;

% % see if equivalent
% bols_test = regress(3*inf3,RHS); 

%% in annual frequency
a_rdivid  = zeros((dT-12)/12,1);
a_rprice  = zeros((dT-12)/12,1);
a_rreturn = zeros((dT-12)/12,1);
a_rmktrtn = zeros((dT-12)/12,1);
a_rfree   = zeros((dT-12)/12,1);
a_rpdratio= zeros((dT-12)/12,1);
for tt=1:(dT-12)/12
    a_rdivid(tt)  = sum(rdivid(12*(tt-1)+1:12*tt));
    a_rprice(tt)  = sum(rprice(12*(tt-1)+1:12*tt));
    a_rreturn(tt) = sum(rreturn(12*(tt-1)+1:12*tt));
    a_rmktrtn(tt) = sum(rmkt_returns(12*(tt-1)+1:12*tt));
    a_rfree(tt)   = sum(exante_rfree(12*(tt-1)+1:12*tt));
    a_rpdratio(tt)= mean(rpdratio(12*(tt-1)+1:12*tt));
end

% annual real dividend growth
a_rdividgr = log(a_rdivid(2:end))-log(a_rdivid(1:end-1));

% real dividend growth 1929:M1-2011:M12 
rdividgr = log(rdivid(2:end))-log(rdivid(1:end-1));
rdividgr = rdividgr(end-996+1:end);

% real stock mkt returns 1929:M1-2011:M12
rsmktrtn = rmkt_returns(end-996+1:end);
exante_rfree    = exante_rfree(end-996+1:end);

YF = [rdividgr rsmktrtn exante_rfree];
