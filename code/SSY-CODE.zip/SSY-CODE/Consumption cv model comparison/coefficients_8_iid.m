function [D,Z,PHI,SIG,RR] = coefficients_8_iid(para,M)

mu    = para(1);
sigma = para(2);

D    = mu;
Z    = 0;
PHI  = 0;
SIG  = sigma^2;
RR   = 0;