%==========================================================================
% This function is for defining the objective function to minimize:
% the negative of log posterior
%==========================================================================

function [retp1,retp2,At_draw]= objfcn(para,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YCM,YY,index,select)

parabd_ind1 = para > lubound(:,1);                  % lower bounds 
parabd_ind2 = para < lubound(:,2);                  % upper bounds 
parabd_ind1 = prod( parabd_ind1 + pmask );
parabd_ind2 = prod( parabd_ind2 + pmask );

if ( parabd_ind1 > 0 ) && ( parabd_ind2 > 0 )       % in bounds 

    % likelihood 
    modelpara = para.*pmaskinv + pfix.*pmask;
    [loglh,At_draw] = evalmod(modelpara,YCM,YY,index,select);     
    lnpY      = loglh;
    npara     = length(para);

    % Evaluate the Prior distribution 
    lnprior = 0;

    for i = 1:npara
    
        if pmask(i) == 1
    
            lnprior = lnprior;
    
        else
        
        if pshape(i) == 1;      % BETA Prior
            a = (1-pmean(i))*pmean(i)^2/pstdd(i)^2 - pmean(i);
            b = a*(1/pmean(i) -1);
            lnprior = lnprior + lpdfbeta(para(i), a, b);
            
        elseif pshape(i) == 2;  % GAMMA PRIOR 
            b = pstdd(i)^2/pmean(i);
            a = pmean(i)/b;
            lnprior = lnprior + lpdfgam(para(i), a, b);
      
        elseif pshape(i) == 3;  % GAUSSIAN PRIOR 
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + lpdfnor(para(i), a, b);

        elseif pshape(i) == 4;  % INVGAMMA PRIOR 
            
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + lpdfig(para(i), a, b);

        elseif pshape(i) == 5;  % uniform prior 
            a = pmean(i);
            b = pstdd(i);
            lnprior = lnprior + log(1/(b-a)*all(para(i)>a & para(i)<b));

        end
    
        end    
    
    end

    % minimize the negative of log posterior 
    % Bayesian
    retp1 = -real( lnpY(1) + lnprior );    
    retp2 = -real( lnpY(1));

else   % out of bounds 

    retp1   = 1E8;
    retp2   = 1E8;
    At_draw = [];
end

    
    
    