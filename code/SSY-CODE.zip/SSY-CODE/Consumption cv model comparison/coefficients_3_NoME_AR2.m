function [D,Z,PHI,SIG,RR] = coefficients_3_NoME_AR2(para,M)

mu    = para(1);
rho   = para(2);
rho2  = para(3);
xie   = para(4);
sigma = para(5);

D   = mu;
Z   = [ 0 1 1];
PHI = [ rho    rho2 0;
           1    0    0;
           0    0    0];
SIG  = diag([xie*sigma*sqrt((1-rho2)/((1+rho2)*((1-rho2)^2-rho^2))) 0 sigma]).^2;
RR   = 0;
