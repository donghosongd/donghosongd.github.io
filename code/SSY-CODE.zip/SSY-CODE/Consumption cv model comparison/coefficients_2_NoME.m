function [D,Z,PHI,SIG,RR] = coefficients_2_NoME(para,M)

mu    = para(1);
rho   = para(2);
xie   = para(3);
sigma = para(4);

D   = mu;
Z   = [ 0 1 1];
PHI = [ rho    0 0;
           1    0 0;
           0    0 0];
SIG  = diag([xie*sigma*sqrt(1-rho^2) 0 sigma]).^2;

RR   = 0;
