tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

select = 1;
load(['result_', num2str(select), '.mat'])

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));

% compute marginal data density
MDD
%% description
clc;   
vindex  = [para_index;ones(2,9)];
sum_vec = [[yy05' yy' yy95'];[yx05' yx' yx95'];[nan mdd nan]];
vartype = {'\mu','\rho','\rho_2','\varphi_x','\varphi_{x,2}','\sigma',...
           '\sigma_{eps}','\sigma_{eps}^{a}','\rho_{eps}','\rho_{eta}',...
           '\zeta_1','\zeta_2','\posterior','mdd'}';
vartype = vartype(vindex(:,select)==1);

disp('=========================================================================');
disp('                                                                         ');
disp(['                            Model Specification= ' num2str(select)       ]);
disp('                                                                         ');
disp('=========================================================================');
disp([' Variable Name                       5%         50%        95%         ']);
disp('=========================================================================');
for hh=1:length(vartype)
    fprintf('%-30s %10.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3));    
end
disp('========================================================================='); 









