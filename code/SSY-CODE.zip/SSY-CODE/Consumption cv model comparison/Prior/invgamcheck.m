function [g05 g20 g50 g80 g95]=invgamcheck(pmean,pstdd)


b = pstdd;
a = pmean;


wshock = gamrnd(a,1/b,100000,1);

[g95 g80 g50 g20 g05]=moment2(1./wshock);

end