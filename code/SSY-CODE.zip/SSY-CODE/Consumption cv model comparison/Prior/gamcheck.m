function [g05 g20 g50 g80 g95]=gamcheck(pmean,pstdd)


b = pstdd^2/pmean;
a = pmean/b;


wshock = gamrnd(a,b,100000,1);

[g95 g80 g50 g20 g05]=moment2(wshock);

end


