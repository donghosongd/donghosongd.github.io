%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: JANUARY, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================


close all
clear 
clc
tic

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

% select model: there are 9 models
for select=1:9

% load prior and selection matrix
%[prior,~]          = xlsread('prior.xls');
%[para_index,vname] = xlsread('selection.xls');

load prior.txt
load selection.txt
para_index = selection;

% load data
M          = 12;
vm_load_data
YY         = [0.0016;gr_mcon];
YCM(12,12) = 0.0016;
nT         = length(YY);
% set index
if select==1 || select==4 || select==5 || select==6
    index = repmat([zeros(11,1);1],672/12,1);
else
    index = 2*ones(672,1);
end

% bound
bound    = [[-0.002  0.002]; %1
            [-0.9999 0.9999];%2
            [-0.9999 0.9999];%3
            [1e-10   0.9999];%4
            [1e-10   1.9999];%5
            [1e-10   0.0500];%6
            [1e-10   0.0500];%7
            [1e-10   0.0500];%8
            [-0.9999 0.9999];%9
            [-0.9999 0.9999];%10
            [-10     10];    %11
            [-10     10]];   %12             

% re-define
bound    = bound(para_index(:,select)==1,:);
prior    = prior(para_index(:,select)==1,:);
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

% load proposal
load(['proposal_', num2str(select), '.mat'])

paraold  = paraest;
npara    = length(paraold);
sigscale = H;
fcn      = @(x1) objfcn_MH(x1,pshape,pmean,pstdd,pmask,pmaskinv,pfix,bound,YCM,YY,index,select);
%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 50000;
cc       = 1;  
%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-WITHIN-GIBBS ALGORITHM                             ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold, At_draw] = fcn(paraold);
    
%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------
        
% storages 
parasim  = zeros(nsim,npara);       % parameter draws
likesim  = zeros(nsim,1);           % likelihood
postsim  = zeros(nsim,1);           % posterior probability
rej      = zeros(nsim,1);           % rej = 1: rejected
statesim = zeros(nsim,nT);

% with-in block loop 
for j = 1:nsim
    % propose   
    genacc=0;
    while genacc<1
        paranew = mvnrnd(paraold, cc*sigscale,1)';
        paranew = paranew.*pmaskinv + pfix.*pmask;

        % parameter restrictions
        if select==3      % NoME_AR2
        genacc  = all(paranew < bound(:,2) & paranew > bound(:,1) & sum(paranew(2:3))<1);
        elseif select==6  % 2AR_ME
        genacc  = all(paranew < bound(:,2) & paranew > bound(:,1) & paranew(2)>paranew(6));        
        else              % all other specifications
        genacc  = all(paranew < bound(:,2) & paranew > bound(:,1));        
        end

    end

    % evaluate at the new candidate 
    [postnew, likenew] = fcn(paranew);    
    % evaluate at the old candidate              
    [postold, likeold] = fcn(paraold);          

    r = min([1 exp( postnew - postold)]);            

    if rand > r 
       % reject proposed jump             
       rej(j) = 1;
    else
       % accept proposed jump          
       paraold = paranew;
       postold = postnew;
       likeold = likenew;
    end

    % store simulated variables
    parasim(j,:) = paraold';
    likesim(j,:) = likeold;
    postsim(j,:) = postold;

    %% report 
    if mod(j,1000)==0        
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
    disp('                                                         ');        
    disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
    disp('                                                         ');
    disp(['  MODEL :   ',    num2str(select)]                 );
    disp('                                                         ');
    disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
    disp('                                                         ');
    savefilename = ['result_', num2str(select), '.mat'];
    save(savefilename);
    end
end       % with-in block  

end           % models
     
path=ls;
