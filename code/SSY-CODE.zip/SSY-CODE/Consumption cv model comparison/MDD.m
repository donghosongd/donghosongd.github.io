%==========================================================================
% Computation of the marginal likelihood based on 
% Random Walk Metropolis-Hastings output
%==========================================================================
parasim = parasim(ts:te,:);

%==========================================================================
% default parameters
%==========================================================================

block1   = 1;		% starting block
blockn   = 1;		% ending block

% for data density (modified harmonic mean)
densfac = median(postsim(ts:te));
hmax    = 20;

%==========================================================================
% means and standard deviations
%==========================================================================

% initialize output
ndraws     = 0;
drawmean   = 0;
drawsqmean = 0;
sumdrawsq  = 0;

% loop for block
for jblock = block1:blockn

     
    % number of simulations in each block
	nsimul = size(parasim,1);
    npara  = size(parasim,2);
	% collect simulations
	drawblock = parasim;
	drawdim   = size(drawblock,2);

	% compute sums of x(i) and x(i)^2 to be used to calculate means and s.d.
	drawmean   = drawmean + sum(drawblock,1);
	drawsqmean = drawsqmean + sum(drawblock.^2,1);
	sumdrawsq  = sumdrawsq + parasim'*parasim;
	ndraws     = ndraws + nsimul;

end

% compute means and standard deviations
drawmean   = drawmean/ndraws;
drawsqmean = drawsqmean/ndraws;
drawstdd   = sqrt(drawsqmean - drawmean.^2);
drawsig    = sumdrawsq/ndraws - drawmean'*drawmean;

[Up, Sp, Vp] = svd(drawsig);
sp = diag(Sp); kp = sum(sp>1e-12);
inv_drawsig = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
det_drawsig = prod(sp(1:kp));
            
drawsiginv = inv_drawsig;
drawsiglndet = log(det_drawsig);

%==========================================================================
% marginal data density:  modified harmonic mean by Geweke (1999)
%==========================================================================
disp('                                                                ');
disp('  Marginal Data Density: GEWEKE (1999)                          ');
disp('                                                                ');
p = (.1:.1:.9)';
%p = (.2:.1:.8)';

pcrit = chi2inv(p,ones(length(p),1)*npara);

ndraws  = 0;
suminvlike = zeros(length(p),1);
laginvlike = zeros(hmax,length(p));
gaminvlike = zeros(hmax,length(p));

% loop for block
for jblock=block1:blockn
    
    % number of simulations in each block
	[nsimul,npara] = size(parasim);				

	paradev  = parasim-repmat(drawmean,nsimul,1);
	quadpara = sum((paradev*drawsiginv).*paradev,2);

	% simulation loop
	for j=1:nsimul
		lnfpara = - 0.5*npara*log(2*pi) - 0.5*drawsiglndet - 0.5*quadpara(j) - log(p);        
		indpara = (quadpara(j)<pcrit);
		invlike = exp(lnfpara - postsim(j) + densfac).*indpara;

		laginvlike = [invlike' ; laginvlike(1:hmax-1,:)];
		gaminvlike = gaminvlike + laginvlike.*repmat(invlike',hmax,1);
		suminvlike = suminvlike + invlike;
	end	% simulation loop

	ndraws = ndraws + nsimul;

end	% loop for blocks

meaninvlike = suminvlike/ndraws;
gaminvlike  = gaminvlike/ndraws - repmat((meaninvlike.^2)',hmax,1);


% standard error
suminvlikeerror = gaminvlike(1,:);
for k=2:hmax
   suminvlikeerror = suminvlikeerror + 2*gaminvlike(k,:)*(1-(k-1)/hmax);
end

suminvlikeerror = 100*sqrt(suminvlikeerror/ndraws)./meaninvlike' ;

% marginalized data density
mdd = densfac-log(meaninvlike);
mdd = mean(mdd);

