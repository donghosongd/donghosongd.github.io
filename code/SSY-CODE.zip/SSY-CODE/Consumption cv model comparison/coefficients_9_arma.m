function [D,Z,PHI,SIG,RR] = coefficients_9_arma(para,M)

mu    = para(1);
rho   = para(2);
sigma = para(3);
zeta1 = para(4);
zeta2 = para(5);

D   = mu;
Z   = [1 0 0];
PHI = [ rho    1 0;
           0    0 1;
           0    0 0];
SIG  = [1      zeta1        zeta2;
       zeta1   zeta1^2      zeta1*zeta2;
       zeta2   zeta1*zeta2  zeta2^2]*sigma^2; 
RR   = 0;   
