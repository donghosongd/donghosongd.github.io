function [D,Z,PHI,SIG,RR] = coefficients_4_M_ME(para,M)

%% State-Space
% Y(t) = D + Z*S(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)
mu    = para(1);
rho   = para(2);
xie   = para(3);
sigma = para(4);
bvar1 = para(5);

D   = zeros(M,1);
PHI = zeros(4*M+1,4*M+1);
Z   = zeros(M,    4*M+1);
SIG = zeros(4*M+1,4*M+1);

order = [M+1 2*M+1 4*M+1];

% construct PHI & SIG
for jj=1:5*M+2
    if jj<=order(1)
        if jj==1
            PHI(jj,jj) = rho;
            SIG(jj,jj) = (xie*sigma)^2*(1-rho^2);
        else
            PHI(jj,jj-1) = 1;
        end
    elseif jj>order(1) && jj<=order(2)
        if jj==order(1)+1
            SIG(jj,jj) = sigma^2;
        elseif jj>(order(1)+1)
            PHI(jj,jj-1) = 1;        
        end    
    elseif jj>order(2) && jj<=order(3)
        if jj==order(2)+1
            SIG(jj,jj)   = bvar1^2;  
        elseif jj>(order(2)+1)
            PHI(jj,jj-1) = 1;        
        end
    end
end


Z(1:M,2:order(1)) = eye(order(1)-1);
Z(1:M,order(1)+1:order(2)) = eye(order(2)-order(1));

for kk=1:M
    for jj=order(2)+1:order(3)
        if jj==order(2)+kk
            Z(kk,jj) = 1;
        elseif jj==order(2)+kk+1
            Z(kk,jj) = -1;
        end
    end
end
Z(M,order(2)+1:order(2)+M-1)     = -ones(1,M-1)/M;
Z(M,order(2)+M)                  = (M-1)/M;
Z(M,order(2)+M+2:order(2)+2*M)   = ones(1,M-1)/M;
Z(M,order(2)+M+1)                = -(M-1)/M;

D(1:M) = mu*ones(M,1);

% construct RR
RR = zeros(M,M);


