function [D,Z,PHI,SIG,RR,GG,D1,Z1] = coefficient_original(para,M)

%% State-Space
% Y(t) = D + Z*S(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)

phi     = para(1);
rho     = para(2);
dpi     = para(3);
sigma   = para(4);
xix     = para(5);
xid     = para(6);
sig_mea = para(7);
sig_mem = para(8);

PHI = zeros(9*M  ,9*M);
Z   = zeros(2*M  ,9*M);
SIG = zeros(9*M  ,9*M);

order = [2*M 4*M-1 6*M-1 7*M 9*M];

% construct PHI & SIG
for jj=1:order(end)
    if jj<=order(1)
        if jj==1
            PHI(jj,jj) = rho;
            SIG(jj,jj) = (xix*sigma)^2*(1-rho^2);
        else
            PHI(jj,jj-1) = 1;
        end
    elseif jj>order(1) && jj<=order(2)
        if jj==order(1)+1
            SIG(jj,jj) = sigma^2;
        elseif jj>(order(1)+1)
            PHI(jj,jj-1) = 1;        
        end    
    elseif jj>order(2) && jj<=order(3)
        if jj==order(2)+1
            SIG(jj,jj)   = sig_mem^2;  
        elseif jj>(order(2)+1)
            PHI(jj,jj-1) = 1;        
        end     
    elseif jj>order(3) && jj<=order(4)
        if jj==order(3)+1
            SIG(jj,jj)   = sig_mea^2;  
        elseif jj>(order(3)+1)
            PHI(jj,jj-1) = 1;        
        end     
    elseif jj>order(4) && jj<=order(5)
        if jj==order(4)+1
            SIG(jj,jj) = (xid*sigma)^2;
        else
            PHI(jj,jj-1) = 1;
        end      
    end
end

% selection matrix: 5 shocks
GG = zeros(6*M-1,size(SIG,1));
for nn=1:4*M-1
    GG(nn,nn) = 1;    
end
for nn=1:2*M
   GG(4*M-1+nn,order(4)+nn) = 1;
end

Z(1:2*M-1,2:order(1)) = eye(order(1)-1);
Z(1:2*M-1,order(1)+1:order(2)) = eye(order(2)-order(1));

for kk=1:2*M-1
    for jj=order(2)+1:order(3)
        if jj==order(2)+kk
            Z(kk,jj) = 1;
        elseif jj==order(2)+kk+1
            Z(kk,jj) = -1;
        end
    end
end
Z(M,order(2)+1:order(2)+M-1)     = -ones(1,M-1)/M;
Z(M,order(2)+M)                  = (M-1)/M;
Z(M,order(2)+M+2:order(2)+2*M)   = ones(1,M-1)/M;
Z(M,order(2)+M+1)                = -(M-1)/M;
Z(M,order(3)+1:order(4))         = [1 zeros(1,M-1) -1];

% dividend process: annual dividend = annual consumption + annual \Delta s
Z(2*M,2:2*M)       = phi*([[1:1:M] M-([1:1:M-1])])/M;
Z(2*M,2*M+1:4*M-1) = dpi*([[1:1:M] M-([1:1:M-1])])/M;
Z(2*M,order(4)+1:order(4)+2*M-1) = ([[1:1:M] M-([1:1:M-1])])/M;

% measurement error free consumption and dividend growth
Z1 = zeros(2,size(GG,1));
Z1(1,2)     = 1;
Z1(1,2*M+1) = 1;
Z1(2,2)     = phi;
Z1(2,2*M+1) = dpi;
Z1(2,4*M)   = 1;
D1 = [0.0016;0.0011];

% construct RR
RR  = zeros(2*M,2*M);
D   = [0.0016*ones(2*M-1,1);0.0011*12];



