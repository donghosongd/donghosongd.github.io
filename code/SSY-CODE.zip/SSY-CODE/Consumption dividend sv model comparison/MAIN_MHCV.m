%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

M = 12;

% load data      
vm_load_data
% redefine data
YA = [kron(gr_acon,ones(12,1)) div_crsp(:,3)];
YM = zeros(size(YA,1),12);
YM(end-671:end,:) = YCM;

% set time and index
time  = 1930+1/12:1/12:2015;
index = repmat([zeros(11,1);1],length(time)/12,1);
cut   = find(time==1961);
index(1:cut) = 12*index(1:cut);
nT    = length(time);

% redefine data
YDATA = constructData(YM,YA,index,M);

% if post-war data, short = 1
short = 1;
% if optimization (i.e., no-smoothing required)
opt   = 1;
% model: 1 if original, 2 if cointegration
model = 1;

% load proposal
load(['proposal_', num2str(model), '.mat'])

% import prior specification, parameter bounds
if model==1
    prior_data_1   
    bound_1
elseif model==2
    prior_data_2   
    bound_2
end

if short==1
    paraold = paraest_short;    
elseif short==0
    paraold = paraest;
end
npara    = length(paraold);
sigscale = H;
fcn      = @(x1) objfcn(x1,zeros(nT,2),pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,index,short,model,opt);
%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 50000;
cc       = 1;  

%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-WITHIN-GIBBS ALGORITHM                             ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold] = fcn(paraold); 

%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

for iblock = 1:nblocks
        
    % storages 
    parasim  = zeros(nsim,npara);       % parameter draws
    likesim  = zeros(nsim,1);           % likelihood
    postsim  = zeros(nsim,1);           % posterior probability
    rej      = zeros(nsim,1);           % rej = 1: rejected
    
    % with-in block loop 
    for j = 1:nsim
        
        if j==2
        disp('                                                         ');
        disp('    ESTIMATION STARTS                                     ');
        disp('                                                         ');
        end
        
        % report 
        if mod(j,100)==0
        
        disp(['  MODEL:   ',              num2str(model)]             );
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
        disp('                                                         ');        
        disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');

        savefilename = ['result_cv_model_', num2str(model) '_short_' num2str(short), '.mat'];
        save(savefilename);
        end      
        
        % propose
        genacc=0;
        while genacc<1
            paranew = mvnrnd(paraold, cc*sigscale,1)';
            paranew = paranew.*pmaskinv + pfix.*pmask;
            genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));
        end
        
        % evaluate at the new candidate
        [postnew, likenew] = fcn(paranew);   
        postnew = -postnew;
        likenew = -likenew;
        
        r = min([1 exp( postnew - postold)]);            
        
        if rand > r 
           % reject proposed jump             
           rej(j) = 1;
        else
           % accept proposed jump          
           paraold = paranew;
           postold = postnew;
           likeold = likenew;
        end
        
        % store simulated variables
        parasim(j,:) = paraold';
        likesim(j,:) = likeold;
        postsim(j,:) = postold;
        
        
    end       % with-in block  

end           % block 

    
path=ls;
