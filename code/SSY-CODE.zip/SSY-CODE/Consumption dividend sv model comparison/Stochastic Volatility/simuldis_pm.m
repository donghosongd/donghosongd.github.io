function [wdraw,what_star,wplus]=simuldis_pm(y,Z,T,R,Qmat)
% ==================================================================
% SIMULDIS_PM.m 
% Same as SIMULDIS but simplified for SV model. Should run fatser. 
% Alejandro Justiniano and Giorgio Primiceri (c) October 2006
% =============================================================
nobs=rows(y);
[ny,nx]=size(R);
wplus=randn(nobs,nx)*Qmat;    %not time varying: otherwise (randn.*Qmat which doesn't work)
ny=size(T,1);
[yplus,stplus]=simssmodel(wplus,T,R,Z,zeros(ny,1),eye(ny));
[junk,vstar,finmat,kmat]=kfilter_mod_pm(y-yplus,Z,T,R,sqrt(2)*Qmat);
Ztr=Z'; 
Rtr=R';  
Ttr=T'; 
rstar=zeros(ny,1); 
what_star=zeros(nx,nobs); 

for ii=nobs:-1:1;
    Ltr=Ttr-Ztr*kmat(:,:,ii)';
    [rstar,what_star(:,ii)]=...
    smoothdis(rstar,2*Qmat,Rtr,Ztr,finmat(:,:,ii),Ltr,vstar(:,ii));
end
wdraw=wplus+(what_star'); [nobs,nz]=size(y);
