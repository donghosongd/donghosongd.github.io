%======================================================================
%       Prior: STOCHASTIC VOLATILITY IN MEASUREMENT EQUATION
%======================================================================

temp_nex=nv; 
initsdv=(1e-4)*eye(temp_nex); 
scale_svprop=(std(YY)); 
in_shat=(log(scale_svprop))';  
T_=T;
nx=nv;

Vlast=initsdv;
vshocks=randn(T_,nx)*initsdv;
Hlast=zeros(T_,nx);
zz=1;
Hlast(1,:)=(in_shat(:))';

for zz=2:T_
    Hlast(zz,:)=Hlast(zz-1,:)+vshocks(zz,:);
end

Qt=exp(Hlast);
sigt=Qt'; 

