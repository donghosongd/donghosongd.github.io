  function [colindic,Qind,u,Q]=selQ(Q) 
% function [colindic,Qind,u,Q]=selQ(Q); 
% 
% Given an r x c matrix Q
%
% Normalize (inside the code) Q such thate columns add up to 1 
% For each row i, select the column j 
% such that given a set of random draws u (rx1) from a uniform [0,1]
% u(i) <= Q(i,j) and u(i) > Q(i-1,j)
% 
% Output 
% =======
% indic     position indicator of the selected element in Q 
% Qind      matrix of dimension rxc such that the j=th column is equal to 1
%           in the it-th row and zero otherwise 
% u         vector of uniform draws 
% Q         renormalized Q probabilities 
%
% Alejandro Justinino  ajustiniano@imf.org 
% Created:          1/21/05 
% Last Modified:    2/3 /05  Removed  eps as a lower bound 
%                   4/10/07  Use to compute P(S) 
%
% Remarks:          Normalization done inside the code! 
%                   Lower bound in u is eps = 2.2204e-016
% To extract the associated multinomial probabilities 
% A=Q.*Qind; A( A~= 0 ) 
% Note: this will operate by columns and will NOT respect the time i.e. row
% 
% dimension !
% =================================================================
[r,c]=size(Q); 
Q=Q./repmat(sum(Q,2),1,c); 
Qcdf=cumsum(Q,2); 
Qind=zeros(r,c); 
u=unifrnd(0,100000,r,1)/100000; 
%u=unidrnd(100000,r,1)/100000;
umat=repmat(u,1,c); 
indic=  (umat <= Qcdf) & ( umat > [zeros(r,1) Qcdf(:,1:end-1)])  ; 
Qind(indic) =1; 
[colindic,junk]=find(Qind'==1); 