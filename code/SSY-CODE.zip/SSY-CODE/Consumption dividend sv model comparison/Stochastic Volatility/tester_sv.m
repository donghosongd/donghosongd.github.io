% -------------------------------------------------------------------------
% Tester file for step_sv.m
% 3/29/2012
% -------------------------------------------------------------------------
% to use step_sv.m USER MUST SPECIFY
% 1. prior information as an input (which is structure data type
% 2. initialize_KF_SV.m : m-file to give initialization of KF 
%    -> important since when prior.unitroot=1, we cannot use stationary
%    distribution as an initial value
% -------------------------------------------------------------------------
clc
clear all
close all
% -------------------------------------------------------------------------
% parameters for simulated data
% -------------------------------------------------------------------------
% MODEL
% e = exp(h)*eps
% h = rho*h(-1) + sig*eta
% -------------------------------------------------------------------------
nsimul = 1000; %number of gibbs iterations
   n = 1; % # of states
nobs = 200;
 RHO = 0.99*eye(n);
 SIG = 0.1^2*eye(n);

et = zeros(nobs,1);
ht = zeros(nobs,n);
for i=2:1:nobs
    ht(i,:) = (RHO*ht(i-1,:)' + chol(SIG)'*randn(n,1))';
    et(i,1) = diag(exp(ht(i,:)))*randn(n,1);
end
    
% -------------------------------------------------------------------------
% prior: USER MUST PROVIDE THIS
% -------------------------------------------------------------------------
% prior for RHO
% prior.R1 = [0.8; 0.8];
% prior.R2 = [0.2; 0.2];
prior.R1 = 0.95*ones(n,1); %mean
prior.R2 = 0.1*ones(n,1); %variance
% prior for SIG
% prior.T  = [2; 2];
% prior.V  = [0.1; 0.1];
prior.T  = 1*ones(n,1);
prior.V  = 0.001*ones(n,1);
% unit-root
prior.unitroot = 0;

% -------------------------------------------------------------------------
%  Gibbs
% -------------------------------------------------------------------------
% store matrices
 gbs_H = zeros(nsimul,nobs,n);
 gbs_R = zeros(nsimul,n);
 gbs_V = zeros(nsimul,n);

% initialize
Hlast = ones(nobs,n);
Rlast = diag(RHO);
Vlast = diag(SIG);

% gibbs
tic
for i=1:1:nsimul
    [Hlast,Rlast,Vlast,s,sigt]=step_sv(et,Hlast,Rlast,Vlast,prior);
    
    for j=1:1:n
        gbs_H(i,:,j) = Hlast(:,j)';
        gbs_R(i,:) = Rlast(:)';
        gbs_V(i,:) = Vlast(:)';
    end
    
end
toc

% moments
  m_H = squeeze(mean(gbs_H,1));
q20_H = squeeze(quantile(gbs_H,0.2,1));
q80_H = squeeze(quantile(gbs_H,0.8,1));
q05_H = squeeze(quantile(gbs_H,0.05,1));
q95_H = squeeze(quantile(gbs_H,0.95,1));

% plotting
if n==1
    ind = 1;
    plot(m_H','r');
    hold on
    plot(ht(:,ind),'g');
    plot(q05_H','b');
    plot(q95_H','b');
    hold off
else
    for ind=1:1:n
        subplot(n,1,ind)
        plot(m_H(:,ind),'r');
        hold on
        plot(ht(:,ind),'g');
        plot(q05_H(:,ind),'b');
        plot(q95_H(:,ind),'b');
        hold off
    end
end






