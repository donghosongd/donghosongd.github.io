function [shat, sig] = initialize_KF_SV(Rlast, Vlast)
% -------------------------------------------------------------------------
% Initialization of the KF in the step_sv
% -------------------------------------------------------------------------
% Rlast: rho of stochastic vol process (n by 1)
% Vlast: sig^2 of stochastic vol process (n by n)
% where n is number of stochastic vol processes
% -------------------------------------------------------------------------
% NOTE
% - works for independent stoachastic processes
% - works for NO LONG RUN MEAN
% -------------------------------------------------------------------------
% stationary case
sig  = diag(Vlast./(1-Rlast.^2));
shat = zeros(size(Rlast));

% nonstatinoary case ...
% n=size(Vlast,1);
% sig = zeros(n);
% shat = zeros(n,1);