%======================================================================
%       Prior: STOCHASTIC VOLATILITY IN TRANSITION EQUATION
%======================================================================

temp_nex0=1; 
initsdv0=(1e-1)*eye(temp_nex0); 
scale_svprop0=std(YY(:,2)); 
in_shat0=(log(scale_svprop0))';  
T_=T;
nx=1;

Vlast0=initsdv0;
vshocks0=randn(T_,nx)*initsdv0;
Hlast0=zeros(T_,nx);
zz=1;
Hlast0(1,:)=(in_shat0(:))';

for zz=2:T_
    Hlast0(zz,:)=Hlast0(zz-1,:)+vshocks0(zz,:);
end

Qt0=exp(Hlast0);
sigt0=Qt0'; 