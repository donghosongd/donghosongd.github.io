function [wdraw,what_star,wplus]=simuldis_sv(y,Z,T,R,Qmat)
% ==================================================================
% SIMULDIS_SV.m 
% Same as SIMULDIS but simplified for SV model. Should run fatser. 
% Alejandro Justiniano and Giorgio Primiceri (c) October 2006
% =============================================================
[nobs,nz]=size(y);
[ny,nx]=size(R);
for ii=1:nobs
wplus(ii,:)=randn(nx,1).*Qmat(:,ii);    %not time varying: otherwise (randn.*Qmat which doesn't work)
end
ny=size(T,1);
[yplus,stplus]=simssmodel(wplus,T,R,Z,zeros(ny,1),1e-5*eye(ny));
[junk,vstar,finmat,kmat]=kfilter_mod_sv(y-yplus,Z,T,R,sqrt(2)*(Qmat));
Ztr=Z'; 
Rtr=R';  
Ttr=T'; 
rstar=zeros(ny,1); 
what_star=zeros(nx,nobs); 

for ii=nobs:-1:1;
    Ltr=Ttr-Ztr*kmat(:,:,ii)';
    [rstar,what_star(:,ii)]=...
    smoothdis(rstar,2*diag(Qmat(:,ii)).^2,Rtr,Ztr,finmat(:,:,ii),Ltr,vstar(:,ii));
end
wdraw=wplus+(what_star'); 