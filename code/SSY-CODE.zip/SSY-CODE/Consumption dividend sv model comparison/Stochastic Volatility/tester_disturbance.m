% -------------------------------------------------------------------------
% Tester file for simul_distrubance_sv.m
% 4/01/2012
% -------------------------------------------------------------------------
clc
clear all

% -------------------------------------------------------------------------
% configuration
% -------------------------------------------------------------------------
% D = [0.5; 1];
% Z = eye(size(D,1));
D = 0.3;
Z = [1/2 1/2];
H = 0.1*eye(size(D,1));

T = [0.5 0.1; 0.4 0.2];
R = 1*eye(size(T,1));

% dimensions
nm = size(Z,1);
[ns, ne] = size(R);

nobs = 200;
 RHO = 0.95*eye(ne);
 SIG = 0.1*eye(ne);
 
% -------------------------------------------------------------------------
% SV
% -------------------------------------------------------------------------
% MODEL
% e = exp(h)*eps
% h = rho*h(-1) + sig*eta
% -------------------------------------------------------------------------
et = zeros(nobs,ne);
ht = zeros(nobs,ne);
for i=2:1:nobs
    ht(i,:) = (RHO*ht(i-1,:)' + chol(SIG)'*randn(ne,1))';
    et(i,:) = diag(exp(ht(i,:)))*randn(ne,1);
end
sigt = exp(ht);

% -------------------------------------------------------------------------
% SSF
% -------------------------------------------------------------------------
% MODEL
% y(t) = Z*s(t) + e(t),   var(e(t)) = H
% s(t) = T*s(t) + R*n(t), var(n(t)) = Q
% where ne is number of shock
% -------------------------------------------------------------------------
% shocks for SSF
nt = et'; %SV generated from the above
clear et
et = H*randn(nm, nobs);

% matrices
ysim  = zeros(nm, nobs);
ssim  = zeros(ns, nobs);

% simulate
ini_s = zeros(ns,1);
temp_s = ini_s;
for i=1:1:nobs
    
    temp_s = T*temp_s + R*nt(:,i);
    
    ysim(:,i) = D+ Z*temp_s + et(:,i);
    ssim(:,i) = temp_s;
    
end

ysim = ysim';
ssim = ssim';

% -------------------------------------------------------------------------
% disturbance sampler
% -------------------------------------------------------------------------
nsimul = 200;
stack_n = zeros(nobs, ne, nsimul); %transition shocks
stack_e = zeros(nobs, nm, nsimul); %measurement shocks

% run smoother nsimul times
for simul_ind = 1:1:nsimul
    [stack_n(:,:,simul_ind), stack_e(:,:,simul_ind)] = simul_disturbance_sv(ysim, T, R, D, Z, H, sigt);
end

smooth_n = mean(stack_n,3);
smooth_n20 = quantile(stack_n,0.2,3);
smooth_n80 = quantile(stack_n,0.8,3);

smooth_e = mean(stack_e,3);
smooth_e20 = quantile(stack_e,0.2,3);
smooth_e80 = quantile(stack_e,0.8,3);

% plot
figure(1)
subplot(2,1,1)
plot([nt(1,:)' smooth_n(:,1)])
hold on
plot(smooth_n20(:,1), 'r');
plot(smooth_n80(:,1), 'r');
hold off
legend('true', 'simulation smooth', '20% and 80% quantile');
title('nt: first element');
subplot(2,1,2)
plot([nt(2,:)' smooth_n(:,2)])
hold on
plot(smooth_n20(:,2), 'r');
plot(smooth_n80(:,2), 'r');
hold off
legend('true', 'simulation smooth', '20% and 80% quantile');
title('nt: second element');

% plot
figure(2)
subplot(2,1,1)
plot([et(1,:)' smooth_e(:,1)])
hold on
plot(smooth_e20(:,1), 'r');
plot(smooth_e80(:,1), 'r');
hold off
legend('true', 'simulation smooth');
title('et: first element');
subplot(2,1,2)
plot([et(2,:)' smooth_e(:,2)])
hold on
plot(smooth_e20(:,2), 'r');
plot(smooth_e80(:,2), 'r');
hold off
legend('true', 'simulation smooth');
title('et: second element');


