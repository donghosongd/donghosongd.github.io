function [H,V,C,F]=step_svglob_new_ar(e,Hlast,Vlast,F,C,priorV,priorT,theta_prior,Vtheta_prior,in_shat,scale_svprop)
% function r=step_sv(e,Hlast,Vlast,in_shat,priorV,priorT,a)
% This code makes a draw from the conditional posterior of 
% the volatility states and the variance of the innovations 
% to the log volatility
%     e = observed innovations of the model with stochastic volatility
%     Hlast = last draw of the time varying (log) standard deviations
%     Vlast = last draw of the variance of the innovations to
%             the log standard deviations (must be a matrix)
%     priorV = mode of the IW or IG prior for V (must be a matrix put something anyway)
%     priorT = degrees of freedom of the prior for V (0 if want flat prior)
%     in_shat = vector with guess 
%     ind_corr = indicator variable: ind_corr=0 if stochastic volatilities 
%                of different shocks are independent; ind_corr=1 otherwise.
%     scale_svprop = Proposal scalar for the initial state of the filter
% Notice that here the log volatilities are assumed to follow random walk processes.
% This can be easily changed.
% setting parameters for the mixture of normals to approximate the logX^2
% Create cks_mm cks_vv global cksmm cksvv ckspr 

    [T,n]=size(e);
    [cksmm cksvv ckspr]=cks_mats(T); 

    e=log(e.^2+.001);
    % drawing the new indicator variables for the mixture of normals
    s=zeros(T,n);
    for i=1:n
        Q=ckspr.*normpdf(repmat(e(:,i),1,7),2*repmat(Hlast(:,i),1,7)+cksmm, cksvv );     
        s(:,i)=selQ(Q); 
    end;
    v2=cksvv(1,:); 
    v2=v2.*v2; 
    m=cksmm(1,:); 

    % forward recursion 
    SHAT=zeros(T,n);
    SIG=zeros(T,n);
    sig=diag(scale_svprop);
    shat=in_shat(:);
    t=1; 
    for t=1:T
        [shat,sig]=kfilter_gio_ar(e(t,:)'-m(s(t,:))',2,F,C,shat,sig,diag(v2(s(t,:))),Vlast);        
        
        SHAT(t,:)=shat';
        SIG(t,:)=diag(sig)';
    end
    % first draws and backward recursion
    H=zeros(T,n);
    H(T,:)=mvnrnd(shat,sig,1);
    for t=T-1:-1:1
        [btTp,StTp]=kback_ar(SHAT(t,:),diag(SIG(t,:)),H(t+1,:),F,C,Vlast);                      
        H(t,:)=mvnrnd(btTp,StTp,1);
    end
    
    % transform H and draw parameters for the log volatility processes
    ytilde = H(2:end,:);
    xtilde = [ones(T-1,1) H(1:end-1,:)];
    
    theta_var   = inv(Vtheta_prior) + Vlast^(-1)*(xtilde'*xtilde);

    theta_var   = inv(theta_var);

    theta_mean  = inv(Vtheta_prior)*theta_prior + Vlast^(-1)*(xtilde'*ytilde);

    theta_mean  = theta_var*theta_mean;

    check = 0;
    while check < 1 
        post_Thetaa  = mvnrnd(theta_mean , theta_var,1);
        if abs(post_Thetaa(2)) < 1 && post_Thetaa(2)>0;
            check = 1;
        end
    end    
    
    C = post_Thetaa(1);
    F = post_Thetaa(2);
    
    d = (ytilde-xtilde*post_Thetaa')'*(ytilde-xtilde*post_Thetaa');
    V = iwishrnd(priorV+d, T-2+priorT);
    % draws for the variances of the innovations to log(se)
%     VH=diag(diag(d+priorV*priorT));
%     shock=mvnrnd(zeros(n,1),eye(n)/VH,T-2+priorT);
%     V=diag(1./diag(shock'*shock));


