  function [cksmm,cksvv,ckspr]=cks_mats(T)
% function [cksmm,cksvv,ckspr]=cks_mats(T);
% 
% Function creates the matrices cksmm, cksvv, ckspr 
% of T rows, wehere each row of 

% cksmm:   cotains the means of the 7 element mixture used
%           in approximating the SV model in Chib, Kim and Shephard 
% cksvv:   standard deviations of the 7 element mixture 
% 
% ckspr:   weights of the mixture 

% 7 mixtures: original
% pr=[.0073 .10556 .00002 .04395 .34001 .24566 .25750]';
% m =[-10.12999 -3.97281 -8.56686 2.77786 .61942 1.79518 -1.08819]'-1.2704;
% v2=sqrt( [5.79596 2.61369 5.1795 .16735 .64009 .34023 1.26261]' );

pr = [0.00609 0.04775 0.13057 0.20674 0.22715 0.18842 0.12047 0.05591 0.01575 0.00115]';
m  = [1.92677 1.34744 0.73504 0.02266 -0.85173 -1.97278 -3.46788 -5.55246 -8.68384 -14.65]';
v2 = sqrt([0.11265 0.17788 0.26768 0.40611 0.62699 0.98583 1.57469 2.54498 4.16591 7.33342])';



cksmm=repmat(m',T,1); 
cksvv=repmat(v2',T,1); 
ckspr=repmat(pr',T,1); 
