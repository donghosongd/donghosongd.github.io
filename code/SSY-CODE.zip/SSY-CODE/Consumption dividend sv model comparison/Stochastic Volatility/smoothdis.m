  function [rzero,what]=smoothdis(rone,Q,Rtr,Ztr,Fnvr,Ltr,v); 
% function [rzero,what]=smoothdis(rone,Q,Rtr,Ztr,Fnvr,Ltr,v); 
% 
% Disturbance smoother recursion for a model with no error in the obs. 
% equation using the formulas in Durbin and Koopman Ch. 4.2 
% rzero=Z'*F^(-1)*v + L'*rone
% what =Q*R'*rone 
% 
% Inputs 
% Rtr = R' 
% Ztr = Z'
% Ltr = L'
% Finvr = F^(-1) 
% 
% Alejandro Justiniano  ajustiniano@imf.org 
% Last Modified   2/3/2005 
% 
rzero=Ztr*Fnvr*v + Ltr*rone ; 
what=Q*Rtr*rzero; 