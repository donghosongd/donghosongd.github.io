function [smooth_n, smooth_e] = simul_disturbance_sv(YY, T, R, D, Z, H, sigt)
% ------------------------------------------------------------------------
% simulation smoother for disturbance
% by Durbin and Koopman (2002, Biometrica)
% ------------------------------------------------------------------------
% MODEL
% y(t) = D + Z*s(t) + e(t),     V( e(t) ) = H
% s(t) = T*s(t) + R*n(t),       V( n(t) ) = Q(t)
% NOTE THAT Q(t) IS DIAGONAL STOCHASTIC VOL
% NOTE THAT H is diagonal matrix
% ------------------------------------------------------------------------
% Input
% sigt: n(t) = sigt(t)*ee(t), sigt(t) = exp(h(t))
% ------------------------------------------------------------------------
% Original code (simuldis.m) by Justiniano and Primiceri is extended by Minchul
% Shin(Penn)
% Date: 2012/03/31
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% Housekeeping
% ------------------------------------------------------------------------
[nobs, nm] = size(YY);
[ns, ne] = size(R);

% demean
y = YY - repmat(D,1,nobs)';

% construct wplus
eplus = randn(nobs, nm)*sqrt(H');
nplus = randn(nobs, ne).*sigt;
% ------------------------------------------------------------------------
% Step 1: simulate ss model to get yplus
% ------------------------------------------------------------------------
% initial state for filter and y+
% initilaize forward filter (following JP) and simulation of y+
   x0 = zeros(ns,1);
   P0 = zeros(ns,ns);
Qsqrt = diag(mean(sigt));
for t = 1:1:200
    P0 = T*P0*T' + (R*Qsqrt)*(Qsqrt'*R');
end

% simulate SS model
% A0 = zeros(ns,1);
% P0sqrt = eye(ns);     % I don't know why.... Just following JP
P0sqrt = chol(P0)';
ini_s = x0 + P0sqrt*randn(ns,1);
[yplus, splus] = simul_SSmodel(T, R, Z, eplus', nplus', ini_s);
% plot(splus)
% ------------------------------------------------------------------------
% Step 2: forward filter
% ------------------------------------------------------------------------
[kf_Finv, kf_K, kf_nu, kf_L] = kalman_filter_ini_SV(x0,P0,zeros(nm,1),Z,T,R,2*H,2*(sigt).^2, y-yplus);
% ------------------------------------------------------------------------
% Step 3: backward recursion to get what_star = what-whatplus
% ------------------------------------------------------------------------
Ztr = Z';
Rtr = R';
what_star = zeros(nm+ne,nobs);
r1 = zeros(ns,1);
HH = 2*H; % times 2 for the same reason (we are doing y-yplus)
for t = nobs:-1:1
    
    QQ = 2*diag(sigt(t,:).^2); % Q is TV, times 2 because we are doing y-yplus
    r0 = Ztr*kf_Finv(:,:,t)*kf_nu(:,t) + kf_L(:,:,t)*r1;
    what_star(:,t) = [HH*kf_Finv(:,:,t) -HH*kf_K(:,:,t)'; zeros(ne,nm) QQ*Rtr]*[kf_nu(:,t);r0];
    
end

% ------------------------------------------------------------------------
% collect wtilde = what_star + what_plus (what = [e; n])
% ------------------------------------------------------------------------
smooth_e = (eplus' + what_star(1:nm,:))';
smooth_n = (nplus' + what_star(nm+1:end,:))';

% end of function
end


% ------------------------------------------------------------------------
% function to get simulated path of y
% ------------------------------------------------------------------------
function [ysim, ssim] = simul_SSmodel(T, R, Z, et, nt, ini_s)
% ------------------------------------------------------------------------
% MODEL
% y(t) = Z*s(t) + e(t)
% s(t) = T*s(t) + R*n(t)
% where ne is number of shock
% ------------------------------------------------------------------------
% IMPORTANT NOTE
% - Y(t) is demean process (D is not here)
% - We treat n(t), e(t) as an input (so that easy to incorporate time-varying vol)
% ------------------------------------------------------------------------
% INPUT
% shocks   : ne by nobs (n(t))
% T, R, Z  : system matrices
% ini_s    : initial states
% ------------------------------------------------------------------------
[nm, nobs] = size(et);
[ns, ne] = size(R);

% matrices
ysim  = zeros(nm, nobs);
ssim  = zeros(ns, nobs);

% simulate
temp_s = ini_s;
for i=1:1:nobs
    
    temp_s = T*temp_s + R*nt(:,i);
    
    ysim(:,i) = Z*temp_s + et(:,i);
    ssim(:,i) = temp_s;
    
end

ysim = ysim';
ssim = ssim';

end

% function for forward filter
function [kf_Finv, kf_K, kf_nu, kf_L, s_up, P_up, loglik] = kalman_filter_ini_SV(x0,P0,A,B,Phi,R,H,S2t, y)
% ----------------------------------------------------
% Kalman filter with x0 and P0 as an input for the function
% with stochastic volatility
% updated: 03/31/2012
% ----------------------------------------------------
% Model
% ----------------------------------------------------
%  y_{t} = A + B s_{t} + u
%  s_{t} = Phi s_{t-1} + R*ep
%  var(u) ~ H
%  var(ep) ~ S2
% ----------------------------------------------------
% housekeeping
[nobs, dim_y] = size(y);
dim_s = size(Phi,2);
 s_up = zeros(nobs,dim_s);
P_up = zeros(nobs, dim_s^2);
y_lik = zeros(nobs,1);

% additional lstore matrices
kf_Finv = zeros(dim_y, dim_y, nobs);
kf_nu   = zeros(dim_y, nobs);
kf_K    = zeros(dim_s, dim_y, nobs);
kf_L    = zeros(dim_s, dim_s, nobs);

% 1. initialization
temp_s = x0;
% temp_P = (eye(dim_s^2) - kron(Phi,Phi))^(-1) * reshape((R*S2*R'),[],1);
% temp_P = reshape(temp_P, dim_s, dim_s);
temp_P = P0;

for i=1:1:nobs
    
    % TV volatility
    S2 = diag(S2t(i,:));
    
    % 2. forecast
    s_fore = Phi*temp_s;
    P_fore = Phi*temp_P*Phi' + R*S2*R';
    
    P_fore = P_fore.*(abs(P_fore)>1e-20);
    
    P_fore = 1/2*(P_fore+P_fore');
    
    y_fore = A + B*s_fore;
    F_fore = B*P_fore*B' + H;
    F_fore = 1/2*(F_fore+F_fore');
    
    % 3. conditional likelihood
    pred_err = (y(i,:)'-y_fore);
    y_lik(i,1) = (2*pi)^(-dim_y/2) * det(F_fore)^(-1/2) * exp(-1/2*pred_err'*(F_fore\pred_err));
    
    % 4. update
    temp_s = s_fore + P_fore*B'*(F_fore\pred_err);
    temp_P = P_fore - P_fore*B'*(F_fore\B)*P_fore';
    
    temp_P = temp_P.*(abs(temp_P)>1e-20);
    
    temp_P = 1/2*(temp_P'+temp_P);
    s_up(i,:) = temp_s;
    P_up(i,:) = reshape((temp_P)', [],1);
    
    % some additional saves (based on Durbin and Koopman)
    kf_Finv(:,:,i) = inv(F_fore);
    kf_nu(:,i)     = pred_err;
    kf_K(:,:,i)    = (Phi*P_fore*B')/F_fore; %not Kalman Gain of my notation
    kf_L(:,:,i)    = Phi - kf_K(:,:,i)*B;
    
end
loglik = log(y_lik);
% loglik = sum(log(y_lik));

% end of function
end

