    
fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.25]);
subplot(2,2,1);
hold on
for kk = 1:length(xx), bar(xx(kk),1.5*max(lrr80),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.5*min(lrr20),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,lrr80',lrr20',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,lrr,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1)-1/12 time(end) min(1.05*min(lrr20)) max(1.05*max(lrr80)) ])
title('$$x_{t}$$')

subplot(2,2,2);
hold on
for kk = 1:length(xx), bar(xx(kk),1.5*max(lrs80),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.5*min(lrs20),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,lrs80',lrs20',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,lrs,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1)-1/12 time(end) min(1.05*min(lrs20)) max(1.05*max(lrs80)) ])
title('$$\eta_{d,t}$$')

subplot(2,2,3);
hold on
for kk = 1:length(xx), bar(xx(kk),2*max(vol180),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),2*min(vol120),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol180',vol120',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol1,'Color',[0.1,0.1,0.1],'LineWidth',2)
axis([time(1)-1/12 time(end) -2 2 ])
title('log$$\sigma_{c,t}$$')

subplot(2,2,4);
hold on
for kk = 1:length(xx), bar(xx(kk),2*max(vol280),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),2*min(vol220),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol280',vol220',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol2,'Color',[0.1,0.1,0.1],'LineWidth',2)
axis([time(1)-1/12 time(end) -2 2 ])
title('log$$\sigma_{d,t}$$')
    
fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.8]);
hold on
for kk = 1:length(xx), bar(xx(kk),1.5*max(lrr80),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.5*min(lrr20),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,lrr80',lrr20',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,lrr,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1)-1/12 time(end) min(1.05*min(lrr20)) max(1.05*max(lrr80)) ])

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.8]);
hold on
for kk = 1:length(xx), bar(xx(kk),1.5*max(lrs80),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),1.5*min(lrs20),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,lrs80',lrs20',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,lrs,'Color',[0.1,0.1,0.1],'LineWidth',3)
axis([time(1)-1/12 time(end) min(1.05*min(lrs20)) max(1.05*max(lrs80)) ])

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.8]);
hold on
for kk = 1:length(xx), bar(xx(kk),2*max(vol180),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),2*min(vol120),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol180',vol120',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol1,'Color',[0.1,0.1,0.1],'LineWidth',2)
axis([time(1)-1/12 time(end) min(1.05*min(vol120)) max(1.05*max(vol180)) ])

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.8]);
hold on
for kk = 1:length(xx), bar(xx(kk),2*max(vol280),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),2*min(vol220),ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol280',vol220',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
plot(time,vol2,'Color',[0.1,0.1,0.1],'LineWidth',2)
axis([time(1)-1/12 time(end) min(1.05*min(vol220)) max(1.05*max(vol280)) ])

