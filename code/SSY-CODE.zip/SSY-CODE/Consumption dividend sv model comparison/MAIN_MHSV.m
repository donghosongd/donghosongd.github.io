%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

M = 12;

% load data    
vm_load_data
% redefine data
YA = [kron(gr_acon,ones(12,1)) div_crsp(:,3)];
YM = zeros(size(YA,1),12);
YM(end-671:end,:) = YCM;

% set time and index
time  = 1930+1/12:1/12:2015;
index = repmat([zeros(11,1);1],length(time)/12,1);
cut   = find(time==1961);
index(1:cut) = 12*index(1:cut);
nT    = length(time);

% redefine data
YDATA = constructData(YM,YA,index,M);

% if post-war data, short = 1
short = 0;
% if optimization (i.e., no-smoothing required) then opt = 1
opt   = 0;
% model: 1 if original, 11 if original and div me, 2 if cointegration
model = 11;

% load proposal
load(['proposal_', num2str(model), '.mat'])

% import prior specification, parameter bounds
if model==1 || model==11
    prior_data_1   
    bound_1
elseif model==2
    prior_data_2   
    bound_2
end

paraold  = paraest;    
npara    = length(paraest);
sigscale = H; 
fcn      = @(x1,x2) objfcn(x1,x2,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,index,short,model,opt);
%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 50000;
cc       = 1;  

% prior for SV
Hprior.R1 = [0.80  0.80]; %mean
Hprior.R2 = [0.1   0.1 ]'; %variance
Hprior.T  = [1.5   1 ];
Hprior.V  = [.005  .002];
% unit-root
Hprior.unitroot = 0;
    
Rlast = [0.99 0.99]';
% prior for stochastic volatilities
in_shat       = zeros(2,1);  
Vlast         = [0.0035 0.04]';
Hlast         = zeros(nT,2);
Hlast(1,:)    =(in_shat(:))';
for zz=2:nT
    Hlast(zz,:)=(diag(Hprior.R1)*Hlast(zz-1,:)'+mvnrnd(zeros(2,1),diag(Vlast.*(1-Rlast.^2)),1)')';
end 
load Hlast.txt

if short==1
    nStart = find(time==1959+1/12);
    time   = time(nStart:end);
    nT     = length(time);
    Hlast  = Hlast(nStart:end,:);
end

%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  METROPOLIS-WITHIN-GIBBS ALGORITHM                             ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold, At_old] = fcn(paraold,Hlast); 

%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

for iblock = 1:nblocks
        
    % storages 
    parasim  = zeros(nsim,npara);       % parameter draws
    likesim  = zeros(nsim,1);           % likelihood
    postsim  = zeros(nsim,1);           % posterior probability
    rej      = zeros(nsim,1);           % rej = 1: rejected
    statesim = zeros(nsim,nT,3);
    hsim     = zeros(nsim,nT,2);
    hbsim    = zeros(nsim,2);
    hvsim    = zeros(nsim,2);
    hvsim2   = zeros(nsim,2);
    % with-in block loop 
    for j = 1:nsim
        
        if j==2
        disp('                                                         ');
        disp('    ESTIMATION STARTS                                     ');
        disp('                                                         ');
        end
        
        % report 
        if mod(j,50)==0
        
        disp(['  MODEL:   ',              num2str(model)]              );
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
        disp('                                                         ');        
        disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:end)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - VOL PER:   ',    num2str(median(hbsim(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  SUMMARY - VOL VAR:   ',    num2str(10000*median(hvsim2(1:j-1,:)))]     );
        disp('                                                         ');
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');

        savefilename = ['result_sv_model_', num2str(model) '_short_' num2str(short), '.mat'];
        save(savefilename);
        
        end      
        
        % propose
        genacc=0;
        while genacc<1
            paranew = mvnrnd(paraold, cc*sigscale,1)';
            paranew = paranew.*pmaskinv + pfix.*pmask;
            genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));
        end
        
        % evaluate at the new candidate
        [postnew, likenew, At_new] = fcn(paranew,Hlast);   
        % evaluate at the old candidate              
        [postold, likeold, At_old] = fcn(paraold,Hlast);    
       
        r = min([1 exp( postnew - postold)]);            
        
        if rand > r 
           % reject proposed jump             
           rej(j) = 1;
        else
           % accept proposed jump          
           paraold = paranew;
           postold = postnew;
           likeold = likenew;
           At_old  = At_new;
        end
        
        % store simulated variables
        statesim(j,:,:) = [At_old(:,1) At_old(:,2*12+1) At_old(:,4*12)]; 
        parasim(j,:) = paraold';
        likesim(j,:) = likeold;
        postsim(j,:) = postold;
                
        % construct normalized residuals
        if model==1 || model==11       
            e_vec11 = (At_old(:,1)-paraold(2)*At_old(:,2))./(sqrt(1-paraold(2)^2)*paraold(5)*paraold(4));
            e_vec12 = At_old(:,2*12+1)./paraold(4);
            e_vec2  = At_old(:,4*12)./(paraold(6)*paraold(4));            
        elseif model==2
            e_vec11 = (At_old(:,1)-paraold(2)*At_old(:,2))./(sqrt(1-paraold(2)^2)*paraold(5)*paraold(4));
            e_vec12 =  At_old(:,2*12+1)./paraold(4);
            e_vec2  = (At_old(:,4*12)-paraold(1)*At_old(:,2)-paraold(3)*At_old(:,4*12+1))./(paraold(6)*paraold(4));            
        end
        
        % order: LRR CONS DIVD      
        % LRR, CONS: common-SV
        e_vec1 = [e_vec11 e_vec12];
        [Hlast1,Rlast1,Vlast1] = step_sv_multivariate(e_vec1,Hlast(:,1),Rlast(1),Vlast(1),Hprior);  
        % DIV: single SV
        [Hlast2,Rlast2,Vlast2] = step_sv(e_vec2,Hlast(:,2),Rlast(2),Vlast(2),Hprior);
        Hlast = [Hlast1 Hlast2];
        Rlast = [Rlast1;Rlast2];
        Vlast = [Vlast1;Vlast2]; 
        
        % set upper bound: cannot allow too much time-variations
        for jj=1:2
            Hlast(:,jj) = Hlast(:,jj)-mean(Hlast(:,jj));
        end       

        hsim(j,:,1) = Hlast(:,1)'; hbsim(j,1) = Rlast(1); hvsim(j,1) = sqrt(Vlast(1)/(1-Rlast(1)^2)); hvsim2(j,1) = Vlast(1);
        hsim(j,:,2) = Hlast(:,2)'; hbsim(j,2) = Rlast(2); hvsim(j,2) = sqrt(Vlast(2)/(1-Rlast(2)^2)); hvsim2(j,2) = Vlast(2);   
                
    end       % with-in block  

end           % block 


%=========================================================================
%                    DISPLAY ESTIMATION RESULTS
%=========================================================================

     
path=ls;

elapsedtime=toc;