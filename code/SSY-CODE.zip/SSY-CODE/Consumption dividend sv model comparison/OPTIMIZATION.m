%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

M = 12;

% load data    
vm_load_data4
% redefine data
YA = [kron(gr_acon,ones(12,1)) div_crsp(:,3)];
YM = zeros(size(YA,1),12);
YM(end-671:end,:) = YCM;
% set time and index
time  = 1930+1/12:1/12:2015;
index = repmat([zeros(11,1);1],length(time)/12,1);
cut   = find(time==1961);
index(1:cut) = 12*index(1:cut);
nT    = length(time);

%model = 1; % original
model = 2; % cointegration
%model = 11; % original and dividends measurement errors

% redefine data
YDATA = constructData(YM,YA,index,M);

% if post-war data, short = 1
short = 0;

% if optimization
opt   = 1;

if model==1 || model==11

    lubound = [[-1000  1000];
               [-.9999 .99999];           
               [-100   100];           
               [.001  .005];           
               [1e-20   1];           
               [1e-20   100];           
               [1e-8    1];           
               [1e-8  .005 ]];    

    paraest = [ 1.6675
                0.9250
               -0.2385
                0.0019
                0.5991
               13.5008
                0.0013
                0.0017];

    load Hlast.txt
elseif model==2
    
    lubound = [[-1000 1000];
               [.9   .99999];           
               [.90  .99999];           
               [.001  .004];           
               [1e-20   1];           
               [1e-8  1000];           
               [1e-8  1];           
               [1e-8  1 ]];

    load Hlast2.txt
    Hlast = Hlast2;
    paraest = [-0.7267
                0.9455
                0.9944
                0.0018
                0.8992
              203.6186
                0.0110
                0.0017];
        
end

lb = lubound(:,1);
ub = lubound(:,2);

options = psoptimset('Display', 'iter',  'UseParallel', 'always', 'CompletePoll', 'on', 'Vectorized', 'off', 'MaxIter',300);

if short==1
    Hlast = Hlast(end-671:end,:);
    Hlast(:,1) = Hlast(:,1) - mean(Hlast(:,1));
    Hlast(:,2) = Hlast(:,2) - mean(Hlast(:,2));
end

if model==1 || model==11 
    fun = @(x) -evalmod(x,Hlast,YDATA,index,short,model,opt);
elseif model==2
    fun = @(x) -evalmod(x,Hlast,YDATA,index,short,model,opt);
end

[x,fval,exitflag,output] = patternsearch(fun,paraest,[],[],[],[],lb,ub,[],options);

[paraest x]