tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% if post-war data, short = 1
short = 0;
% model: 1 if original, 11 if original and div me, 2 if cointegration
model = 1;

load(['result_cv_model_', num2str(model) '_short_' num2str(short), '.mat']);

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[zx, zx05, zx95]=moment(likesim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));

% compute marginal data density
MDD
%% prior evaluation
nP = size(prior,1);
store  = zeros(nP,3);
storev = zeros(4,3);

for ii=1:nP
    a = prior(ii,2);
    b = prior(ii,3);
    
    if prior(ii,1) == 5; % uniform
        this = [a + (b-a)/20 a+(b-a)/2  b-(b-a)/20];  
    elseif prior(ii,1) == 4; % inverted gamma
        [g05, g20, g50, g80, g95]=invgamcheck(a,b);
        this = [g05 g50 g95]; 
    elseif prior(ii,1) == 3; % normal 
        temp = a + b*randn(10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];
    elseif prior(ii,1) == 2; % gamma
        [g05, g20, g50, g80, g95]=gamcheck(a,b);
        this = [g05 g50 g95];    
    elseif prior(ii,1) == 1 % beta 
        temp = betarnd(a,b,10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];    
    end
    store(ii,:) = this;
end


sum_vec1 = [store;nan(3,3)];

sum_vec2 = [[yy05' yy' yy95'];
           [nan mean(rej(1:j-1)) nan];[zx05' zx' zx95'];[yx05' yx' yx95']];
sum_vec  = [[sum_vec1 sum_vec2];[nan(1,3) nan mdd nan]];      
       
%% description
clc;
if model==2
vartype     = {'\phi_s','\rho','\rho_s','\sigma','\varphi_x','\varphi_s',...
               '\sigma_{A,\epsilon}','\sigma_{\epsilon}',...
               'rejection','\likelihood','\posterior','mdd'};
elseif model==1 || model==11
vartype     = {'\phi','\rho','\pi','\sigma','\varphi_x','\varphi_d',...
               '\sigma_{A,\epsilon}','\sigma_{\epsilon}',...
               'rejection','\likelihood','\posterior','mdd'};
end    
disp('==============================================================================================================');   
disp('                                                                                                             '); 
disp(['                                                              Model: ', num2str(model)                      ]); 
disp('                                                                                                             '); 
disp('                                                                                                             '); 
disp(['                                       Prior Distribution                    Posterior Draws: ', num2str(j)   ] );
disp('                                                                                                             ');
disp('==============================================================================================================');
disp([' Variable Name                       5%         50%        95%              5%        50%       95%         ']);
disp('==============================================================================================================');
for hh=1:length(vartype);
    fprintf('%-30s %10.4f %10.4f %10.4f %15.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3),sum_vec(hh,4),sum_vec(hh,5),sum_vec(hh,6));    
end
disp('==============================================================================================================');     
     


