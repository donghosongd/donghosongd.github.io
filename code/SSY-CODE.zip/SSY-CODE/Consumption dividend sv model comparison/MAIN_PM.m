%=========================================================================
%      DESCRIPTION: Metropolis-within-Gibbs Algorithm in the Estimation 
%
%      CODE: Dongho Song 
%
%      DATE: FEB, 2017
%========================================================================= 

%=========================================================================
%                             HOUSEKEEPING
%=========================================================================

tic
close all
clear all
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

M = 12;

% load data    
vm_load_data
% redefine data
YA = [kron(gr_acon,ones(12,1)) div_crsp(:,3)];
YM = zeros(size(YA,1),12);
YM(end-671:end,:) = YCM;

% set time and index
time  = 1930+1/12:1/12:2015;
index = repmat([zeros(11,1);1],length(time)/12,1);
cut   = find(time==1961);
index(1:cut) = 12*index(1:cut);
nT    = length(time);

% redefine data
YDATA = constructData(YM,YA,index,M);

% if post-war data, short = 1
short = 0;

% if optimization
opt   = 1;

% model: 1 if original, 11 if original and div me, 2 if cointegration
model = 11;

% import prior specification, parameter bounds
if model==1 || model==11
    prior_data_1   
    bound_1
elseif model==2
    prior_data_2   
    bound_2
end

%% Initial parameter values
if model==1 || model==11
    para = [1.6675
            0.9250
           -0.2385
            0.0019
            0.5991
           13.5008
            0.0013
            0.0017];        
elseif model==2
    para = [-1.2310
            0.9230
            0.9944
            0.0018
            0.6393
          133.8991
            0.0013
            0.0017];
end

%load paraest.csv; para = paraest;
npara = length(para);
H0    = 1e-4*eye(npara); 
H0(1,1) = 1; H0(6,6) = 10;

% set optimization routine environment 
nit  = 1000;        % maximum number of iteration 
crit = 1E-15;        % tolerance 

% constant volatility
Hlast = zeros(nT,2);
load Hlast.txt


%% use Sims's optimization procedure 
[ fh, xh, gh, H, itct, fcount, retcodeh ] ...
= csminwel( 'objfcn', para,  H0, [], crit, nit, Hlast, pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,index,short,model,opt);

paraest = real(xh);
paraest = paraest.*pmaskinv + pfix.*pmask;

savefilename = ['proposal_', num2str(model), '.mat'];
save(savefilename,'paraest','H','fh');


path=ls;

