function [loglh, At_draw, Yt_draw] = evalmod(para,Hlast,YDATA,index,short,model,opt)
   
time   = 1930+1/12:1/12:2015;
nStart = find(time==1959+1/12); 
if short==1
    YDATA = YDATA(nStart:end,:);
    index = index(nStart:end,:);
end

T = size(YDATA,1);
M = 12;    
% model-coefficients
if model==1
    % original
    [DD,ZZ,PHIF,SIG,RR,GG,D1,Z1] = coefficient_original(para,M);
elseif model==11
    [DD,ZZ,PHIF,SIG,RR,GG,D1,Z1] = coefficient_original(para,M);    
    RR(end,end) = 0.01^2; % set the size of the measurement error to 10% of stdev
elseif model==2
    % cointegration
    [DD,ZZ,PHIF,SIG,RR,GG,D1,Z1] = coefficient_cointegration(para,M);
    RR(end,end) = 0.01^2;
end
mZ   = size(ZZ,1);
mdim = size(PHIF,1);
SIGT = zeros(T,mdim);
for tt=1:T
    SIGT(tt,:)       = diag(SIG);
    SIGT(tt,1)       = SIG(1,1)*exp(2*Hlast(tt,1));
    SIGT(tt,2*M+1)   = SIG(2*M+1,2*M+1)*exp(2*Hlast(tt,1));
    SIGT(tt,7*M+1)   = SIG(7*M+1,7*M+1)*exp(2*Hlast(tt,2));
    if tt>217 && short==0
        SIGT(tt,6*M) = 0; % impose annual consumption measurement errors 1930-1948
    end
end

% initialization of the filter    
Pt = zeros(mdim,mdim);
for ii=1:50
   Pt = PHIF*Pt*PHIF' + SIG; 
end
At = zeros(mdim,1);    
At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);    
lh_mat = zeros(T,1);

% Filter loop 
for t = 1:T

    if index(t)==1     % we have both consumption (MF), dividend data (MF)
        MS            = zeros(M+1,mZ);
        MS(1:M,1:M)   = eye(M);
        MS(end,end)   = 1;     
        data = YDATA(t,1:M+1)';
    elseif index(t)==M % we have both consumption (AF), dividend data (MF)
        MS            = zeros(2,mZ);
        MS(1,1:2*M-1) = ([[1:1:M] M-([1:1:M-1])])/M;
        MS(2,end)     = 1;     
        data          = YDATA(t,1:2)';
    elseif index(t)==0 % we only have dividend data
        MS            = zeros(1,mZ);
        MS(1,end)     = 1;
        data          = YDATA(t,1);
    else
        MS            = [];
        data          = [];
    end

    At1  = At;
    Pt1  = Pt;

    % Forecasting   
    alphahat = PHIF * At1 ;
    Phat     = PHIF * Pt1 * PHIF' + diag(SIGT(t,:));
    Phat     = 0.5*(Phat+Phat');

    MD = MS*DD;
    MZ = MS*ZZ;
    MR = MS*RR*MS';        

    yhat = MD+MZ*alphahat;
    nut  = data - yhat;

    Ft = MZ*Phat*MZ' + MR;  
    Ft = 0.5*(Ft+Ft');

    invFt = eye(size(Ft,1))/Ft;
    detFt = det(Ft);       

    lh_mat(t) = -0.5*length(data)*log(2*pi)-0.5*log(detFt)-0.5*nut'*invFt*nut;

    % Updating 
    At = alphahat + (Phat*MZ')*invFt*nut;
    Pt = Phat - (Phat*MZ')*invFt*(Phat*MZ')';   

    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,mdim^2);

end


%% posterior maximization: we don't need smoother, opt == 1

if opt==0

    % let's not do the full matrix inversion. delete the measurement errors
    gdim    = size(GG,1);
    At_draw = zeros(T,gdim);
    Yt_draw = zeros(T,2);

    % transform variance-covariance matrix
    PtT          = GG*reshape(Pt_mat(T,:),mdim,mdim)*GG';
    [um, sm, ~]  = svd(PtT);
    Pmchol       = um*sqrt(sm);    
    At_draw(T,:) = (GG*At_mat(T,:)'+Pmchol*randn(gdim,1))';
    %Yt_draw(T,:) = D1 + Z1*At_draw(T,:)';

    % Kalman Smoother 
    for i = 1:T-1

        Att  = GG*At_mat(T-i,:)';
        Ptt  = GG*reshape(Pt_mat(T-i,:),mdim,mdim)*GG';

        Phat = (GG*PHIF*GG') * Ptt * (GG*PHIF*GG')' + GG*diag(SIGT(T-i,:))*GG';
        Phat = 0.5*(Phat+Phat');

        inv_Phat = eye(gdim)/Phat;
        inv_Phat = 0.5*(inv_Phat + inv_Phat');

        nut   = At_draw(T-i+1,:)'- (GG*PHIF*GG')*Att;

        Amean = Att + (Ptt*(GG*PHIF*GG')')*inv_Phat*nut;
        Pmean = Ptt - (Ptt*(GG*PHIF*GG')')*inv_Phat*(Ptt*(GG*PHIF*GG')')';   
        Pmean = 0.5*(Pmean+Pmean');

        % singular value decomposition
        [um, sm, ~] = svd(Pmean);
        Pmchol = um*sqrt(sm);
        At_draw(T-i,:)   = (Amean+Pmchol*randn(gdim,1))'; 
        %Yt_draw(T-i,:)   = D1 + Z1*At_draw(T-i,:)';
    end
 
else
        At_draw = At_mat;
        Yt_draw = [];
        
end

loglh = sum(lh_mat);

