load 1959_MONTHLY.txt
gr_mcon = X1959_MONTHLY;
gcon    = [0.0016;gr_mcon];

bench   = eye(12);
ratio_vec = zeros(12,1);
index1 = repmat(bench(:,1),672/12,1);
c_jan  = gcon(index1==1); 

for ii=1:12
index   = repmat(bench(:,ii),672/12,1);
c_rest  = gcon(index==1);
ratio_vec(ii)   = var(c_jan)/var(c_rest);
end

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);

fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
    'Position',[1 scrsz(4)/13 scrsz(3)/1.5 scrsz(4)/1.5]);  
h = bar([1:1:12],ratio_vec);
set(h,'FaceColor',[0.5 0.5 0.5],'EdgeColor',[0.4 0.4 0.4])
xlim([0.5 12.5])
ylabel('Variance Ratio')
xlabel('Month')
line([0.5 12.5],[1 1],'Color','k','linewidth',1.5,'linestyle','--')