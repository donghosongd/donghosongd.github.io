
subplot(1,3,1)
hold on;
plot(time,divgr(:,2),'b');
plot(time,information.YDAm,'Color',[0.9 0.9 0.2],'LineWidth',3);
h = legend('$$\Delta d_t^{o}$$','$$\Delta d_t^{A,o}$$');
set(h,'location','northeast','interpreter','latex','FontSize',20);
legend('boxoff')
axis([time(1) time(end) -1.5 2])
set(gca,'FontSize',20)

subplot(1,3,2)
hold on;
plot(time,information.YDM(:,1),'r');
plot(time,information.YDAm,'Color',[0.9 0.9 0.2],'LineWidth',3);
h = legend('$$\Delta d_t^{deseasonalized,o}$$','$$\Delta d_t^{A,o}$$');
set(h,'location','northeast','interpreter','latex','FontSize',20);
legend('boxoff')
axis([time(1) time(end) -1.5 2])
set(gca,'FontSize',20)

subplot(1,3,3)
hold on;
plot(time,divgr(:,1)*12,'Color',[0.1 0.6 0.1],'LineWidth',2);
plot(time,information.YDAm,'Color',[0.9 0.9 0.2],'LineWidth',3);
h = legend('$$12\Delta d_t^{SSY,o}$$','$$\Delta d_t^{A,o}$$');
set(h,'location','northeast','interpreter','latex','FontSize',20);
legend('boxoff')
axis([time(1) time(end) -1.5 2])
set(gca,'FontSize',20)