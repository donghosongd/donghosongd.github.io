[state,~] = xlsread('state.xls');

volc = state(:,5);
nT   = length(volc);
time = 1930+1/12:1/12:2015;

zzz  = nan(nT,3);
zzz(1:250,1)   = volc(1:250);
zzz(251:650,2) = volc(251:650);
zzz(651:end,3) = volc(651:end);

beta1 = [1:1:length(zzz(1:250,1))]'\(zzz(1:250,1)-mean(zzz(1:250,1)));
beta2 = [1:1:length(zzz(251:650,2))]'\(zzz(251:650,2)-mean(zzz(251:650,2)));
beta3 = [1:1:length(zzz(651:end,3))]'\(zzz(651:end,3)-mean(zzz(651:end,3)));

kkk = nan(nT,3);
kkk(1:250,1)   = mean(zzz(1:250,1))+beta1*[1:1:length(zzz(1:250,1))]';
kkk(251:650,2) = mean(zzz(251:650,2))+beta2*[1:1:length(zzz(251:650,2))]';
kkk(651:end,3) = mean(zzz(651:end,3))+beta3*[1:1:length(zzz(651:end,3))]';

this = zeros(nT,2);
this(1:250,1)   = zzz(1:250,1);
this(251:650,1) = zzz(251:650,2);
this(651:end,1) = zzz(651:end,3);

this(1:250,2)   = kkk(1:250,1);
this(251:650,2) = kkk(251:650,2);
this(651:end,2) = kkk(651:end,3);

load recession.txt
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
    'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2]);  
subplot(1,2,1)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
plot(time,this(:,1),'k','linewidth',2)
plot(time,this(:,2),'r','linewidth',2)
axis([time(1)-1/12 time(end) -1.25 1.25]);

subplot(1,2,2)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
plot(time,this(:,1)-this(:,2),'k','linewidth',2)
axis([time(1)-1/12 time(end) -1.25 1.25]);


that = this(:,1) - this(:,2);
aa = autocorr(that,2);
aa(2)










