[data,etc] = xlsread('consumption_dividend.xlsx');
[state,~] = xlsread('state.xls');

% (2) real con level, (5) real div level, (6) rcon growth, (7) lrr, (8)
% real div level shiller

dcraw       = log(data(:,5)) - log(data(:,2));
dcshiller   = log(data(:,8)) - log(data(:,2));

dcraw       = dcraw - mean(dcraw);
dcshiller   = dcshiller - mean(dcshiller);

con  = data(:,6);
lrr  = data(:,7);
dcgraw      = diff(dcraw);
dcgshiller  = diff(dcshiller);


time = 1959+1/12:1/12:2015;
nT   = length(time);


% aggregate
dcA  = zeros(nT,2);
lrrA = zeros(nT,1);
dcgA = zeros(nT/12-1,1);
dandcA = zeros(nT/12,2);

conL = log(data(:,2));
divL = log(data(:,5));

for ii=1:nT/12
   dandcA(ii,1) = sum(conL(12*(ii-1)+1:12*ii));
   dandcA(ii,2) = sum(divL(12*(ii-1)+1:12*ii)); 
end


for ii = 12:nT
   dcA(ii,1) = sum(dcraw(ii-11:ii));
   dcA(ii,2) = sum(dcshiller(ii-11:ii));
   lrrA(ii)= sum(lrr(ii-11:ii));
end


agg_coeff = ([[1:1:12] 12-[1:1:11]]/12);

for t=2:nT/12-1
    dcgA(t-1,1) = dcgraw(12*(t-2)+2:12*t)'*agg_coeff'; 
    dcgA(t-1,2) = dcgshiller(12*(t-2)+2:12*t)'*agg_coeff';     
end

load recession.txt
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);

fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
    'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.5]);  
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
h1 = plot(time,dcraw,'k','linewidth',1);
h2 = plot(time,dcshiller,'r','linewidth',2,'linestyle','-.');
kk = legend([h1,h2],'raw series','shiller-smoothed');
set(kk,'interpreter','latex','location','north','orientation','horizontal');
legend('boxoff');
axis([time(1) time(end) -1.5 1.5])


fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
    'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.5]);  
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
h1 = plot(time,dcA(:,1),'k','linewidth',2);
h2 = plot(time,dcA(:,2),'r','linewidth',3,'linestyle','-.');
kk = legend([h1,h2],'raw series','shiller-smoothed');
set(kk,'interpreter','latex','location','north','orientation','horizontal');
legend('boxoff');
axis([time(12) time(end) -5 5])


index = repmat([zeros(11,1);1],672/12,1);


fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
    'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.5]);  
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
h1 = plot(time(index==1),dcA(index==1,1),'k','linewidth',2);
h2 = plot(time(index==1),dcA(index==1,2),'r','linewidth',3,'linestyle','-.');
kk = legend([h1,h2],'raw series','shiller-smoothed');
set(kk,'interpreter','latex','location','north','orientation','horizontal');
legend('boxoff');
axis([time(12) time(end) -5 5])

























