%clc;clear;
load div_gr_smoothed_monthly.txt

divgr = div_gr_smoothed_monthly;
dT = size(divgr,1);
divgr_s = zeros(dT,1);

for tt=12:1032;
    divgr_s(tt) = mean(divgr(tt-11:tt,2));
end

time = 1929+1/12:1/12:2015;

dummy = repmat(eye(12),1032/12,1);

[bv,sebv,R2v,R2vadj,v,F] = olsgmm(divgr(:,2),dummy,0,0);

divgr_ds = divgr(:,2)-dummy*bv;

dummy_qf = repmat(eye(3),1032/3,1);

[bvq,sebvq,R2vq,R2vadjq,vq,Fq] = olsgmm(divgr(:,2),dummy_qf,0,0);

divgr_ds2 = divgr(:,2)-dummy_qf*bvq;

std(divgr_ds)./std(divgr(:,1));

std(divgr(:,2))./std(divgr(:,1));

nA = 24;
[aa,xa] = autocorr(divgr_ds,nA);
[bb,xb] = autocorr(divgr(:,2),nA);

ac = aa(2:end);
qa = zeros(nA/3,3);
for ii=1:nA/3
   qa(ii,1) = ac(3*(ii-1)+1);
   qa(ii,2) = ac(3*(ii-1)+2);
   qa(ii,3) = ac(3*(ii-1)+3);
end

% 
% 
% scrsz = get(0,'ScreenSize');
% set(0,'defaulttextinterpreter','latex')
% set(0,'DefaultAxesFontSize',22)
% set(0,'DefaultTextFontSize',22);
% set(0,'defaultaxesfontname','times')
% 
% fig = figure('Position',[20,20,900,600],'Name',...
%         '','Color','w',...
%         'Position',[1 scrsz(4)/13 scrsz(3)/1.5 scrsz(4)/1.25]);
% hold on
% plot(qa(:,1),'Color',[0.9 0.4 0.1],'Marker','o','LineWidth',4)
% plot(qa(:,2),'Color',[0.2 0.8 0.2],'Marker','s','LineWidth',4)
% plot(qa(:,3),'Color',[0.1 0.4 0.9],'Marker','d','LineWidth',4)
% plot(zeros(nA/3,1),'k--')
% h = legend('M1,M4,M7,M10','M2,M5,M8,M11','M3,M6,M9,M12');
% set(h,'location','northeastoutside');
% legend('boxoff')
%     
% fig = figure('Position',[20,20,900,600],'Name',...
%         '','Color','w',...
%         'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.25]);
% subplot(2,1,1)
% autocorr(divgr(:,2),nA+1);axis tight
% title('Raw Data')
% ylabel('');xlabel('')
% set(gca,'FontSize',20)
% subplot(2,1,2)
% autocorr(divgr_ds,nA+1);axis tight
% set(gca,'FontSize',20)
% title('De-Seasonalized Data')
% ylabel('');xlabel('')
% 
% % fig = figure('Position',[20,20,900,600],'Name',...
% %         '','Color','w',...
% %         'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.25]);
% % subplot(3,1,1)    
% % hold on
% % plot(time,divgr(:,1),'Color',[0.9 0.2 0.1],'LineWidth',2)
% % h = legend('$$\log({\sum_{j=0}^{11} D_{t-j}}/{\sum_{j=0}^{11} D_{t-j-1}})$$');
% % set(h,'location','eastoutside')
% % legend('boxoff')
% % axis tight
% % set(gca,'FontSize',20)
% % subplot(3,1,2)    
% % hold on
% % plot(time,divgr(:,2))
% % plot(time,divgr(:,1),'Color',[0.9 0.2 0.1],'LineWidth',2)
% % h = legend('$$\log(D_{t-j}/D_{t-j-1})$$','$$\log({\sum_{j=0}^{11} D_{t-j}}/{\sum_{j=0}^{11} D_{t-j-1}})$$');
% % set(h,'location','eastoutside')
% % legend('boxoff')
% % axis tight
% % set(gca,'FontSize',20)
% % subplot(3,1,3)    
% % hold on
% % plot(time,divgr(:,1),'Color',[0.9 0.2 0.1],'LineWidth',2)
% % plot(time,divgr_s,'Color',[0.1 0.2 0.9],'LineWidth',2,'LineStyle','--')
% % h = legend('$$\log({\sum_{j}^{11} D_{t-j}}/{\sum_{j}^{11} D_{t-j-1}})$$','$$\sum_{j=0}^{11}\log(D_{t-j}/D_{t-j-1})$$');
% % set(h,'location','eastoutside')
% % legend('boxoff')
% % axis tight
% % set(gca,'FontSize',20)
% % 
