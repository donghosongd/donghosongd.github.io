function YDATA = constructData(YM,YA,index,M)

nT    = size(index,1);
YDATA = zeros(nT,M+1);
for t = 1:nT
    if index(t)==1     % we have both consumption (MF), dividend data (MF)
        YDATA(t,1:M+1) = [YM(t,:) YA(t,2)];
    elseif index(t)==M % we have both consumption (AF), dividend data (MF)
        YDATA(t,1:2)   = YA(t,:);
    elseif index(t)==0 % we only have dividend data
        YDATA(t,1)     = YA(t,2);
    end
end