%==========================================================================
%                     IMPORT PRIOR SPECIFICATION
%==========================================================================

load prior_2.txt  
prior = prior_2;
% pshape: pdf type
%   1: BETA(mean,stdd)
%   2: GAMMA(mean,stdd)
%   3: NORMAL(mean,stdd)
%   4: INVGAMMA(s^2,nu)
%   5: UNIFORM(a,b)
%   0: no prior

pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value

% Fix non-volatility parameters
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;




