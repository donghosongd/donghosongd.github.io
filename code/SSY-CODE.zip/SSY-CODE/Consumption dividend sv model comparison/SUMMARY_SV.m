tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Posterior Mode',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);
path('Stochastic Volatility',path);

% if post-war data, short = 1
short = 0;
% model: 1 if original, 11 if original and div me, 2 if cointegration
model = 11;

load(['result_sv_model_', num2str(model) '_short_' num2str(short), '.mat']);

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[yz, yz05, yz95]=moment(hbsim(ts:te,1:2));
[yk, yk05, yk95]=moment(hvsim(ts:te,1:2));[vk, vk05, vk95]=moment(hvsim2(ts:te,1:2));
[zx, zx05, zx95]=moment(likesim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));


%% prior evaluation
nP = size(prior,1);
store  = zeros(nP,3);
storev = zeros(4,3);

for ii=1:nP
    a = prior(ii,2);
    b = prior(ii,3);
    
    if prior(ii,1) == 5; % uniform
        this = [a + (b-a)/20 a+(b-a)/2  b-(b-a)/20];  
    elseif prior(ii,1) == 4; % inverted gamma
        [g05, g20, g50, g80, g95]=invgamcheck(a,b);
        this = [g05 g50 g95]; 
    elseif prior(ii,1) == 3; % normal 
        temp = a + b*randn(10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];
    elseif prior(ii,1) == 2; % gamma
        [g05, g20, g50, g80, g95]=gamcheck(a,b);
        this = [g05 g50 g95];    
    elseif prior(ii,1) == 1 % beta 
        temp = betarnd(a,b,10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];    
    end
    store(ii,:) = this;
end

for ii=1:2    
    temp = Hprior.R1(ii) + sqrt(Hprior.R2(ii))*randn(10000,1);
    [m50, m05, m95] = moment(temp);
    if m95>1
        m95 = 0.9999;
    end
    this = [m05 m50 m95];
    storev(ii,:) = this;
    [g05, g20, g50, g80, g95]=invgamcheck(Hprior.T(ii),Hprior.V(ii));

    storev(ii+2,:) = [g05 g50 g95];
end

sum_vec1 = [store;storev; nan(3,3)];

sum_vec2 = [[yy05' yy' yy95'];[yz05' yz' yz95'];[vk05' vk' vk95'];
           [nan mean(rej(1:j-1)) nan];[zx05' zx' zx95'];[yx05' yx' yx95']];
sum_vec  = [sum_vec1 sum_vec2];       
       
%% description
clc;
if model==1 || model==11
vartype     = {'\phi','\rho','\pi','\sigma','\varphi_x','\varphi_d','\sigma_{A,\epsilon}','\sigma_{\epsilon}',...
               '\nu_{c}','\nu_{d}','\sigma_{\nu,c}^{2}','\sigma_{\nu,d}^{2}','rejection','\likelihood','\posterior'};
elseif model==2
vartype     = {'\phi_s','\rho','\rho_s','\sigma','\varphi_x','\varphi_s','\sigma_{A,\epsilon}','\sigma_{\epsilon}',...
               '\nu_{c}','\nu_{s}','\sigma_{\nu,c}^{2}','\sigma_{\nu,s}^{2}','rejection','\likelihood','\posterior'};    
end
disp('==============================================================================================================');   
disp('                                                                                                             '); 
disp(['                                                              Model: ', num2str(model)                      ]); 
disp('                                                                                                             '); 
disp('                                                                                                             '); 
disp('==============================================================================================================');
disp('                                                                                                             '); 
disp(['                                       Prior Distribution                    Posterior Draws: ', num2str(j)   ] );
disp('                                                                                                             ');
disp('==============================================================================================================');
disp([' Variable Name                       5%         50%        95%              5%        50%       95%         ']);
disp('==============================================================================================================');
for hh=1:length(vartype);
    fprintf('%-30s %10.4f %10.4f %10.4f %15.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3),sum_vec(hh,4),sum_vec(hh,5),sum_vec(hh,6));    
end
disp('==============================================================================================================');     
     


[lrr95,lrr80,lrr,lrr20,lrr05]      = moment2(statesim(ts:te,:,1));
[lrs95,lrs80,lrs,lrs20,lrs05]      = moment2(statesim(ts:te,:,3));
[vol195,vol180,vol1,vol120,vol105] = moment2(hsim(ts:te,:,1));
[vol295,vol280,vol2,vol220,vol205] = moment2(hsim(ts:te,:,2));

load recession.txt
if short==1
    time      = time(end-671:end);
    recession = recession(6:end,:);
elseif short==0    
    time = 1930+1/12:1/12:2015;
end
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);


%% figures
% compute recursive mean
rparasim = zeros(size(parasim));
rhbsim   = zeros(size(hbsim));
rhvsim   = zeros(size(hvsim));
rpostsim = zeros(size(postsim));
rlikesim = zeros(size(likesim));
for ii=1:size(parasim,2)
    for jj=ts:te
        rparasim(jj,ii) = mean(parasim(ts:jj,ii));
        rpostsim(jj,:)  = mean(postsim(ts:jj,:));
        rlikesim(jj,:)  = mean(likesim(ts:jj,:));
        rhbsim(jj,1)   = mean(hbsim(ts:jj,1));
        rhbsim(jj,2)   = mean(hbsim(ts:jj,2));
        rhvsim(jj,1)   = mean(hvsim2(ts:jj,1));
        rhvsim(jj,2)   = mean(hvsim2(ts:jj,2));
    end
end
    
scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1 scrsz(4)/1.25]);
subplot(3,4,1);
hold on
plot(parasim(ts:te,1))
plot(rparasim(ts:te,1),'r','LineWidth',2)
if model==1 | model==11
title('$$\phi$$','Interpreter','latex','FontSize',18)
elseif model==2
title('$$\phi_s$$','Interpreter','latex','FontSize',18)    
end
axis tight
subplot(3,4,2);
hold on
plot(parasim(ts:te,2))
plot(rparasim(ts:te,2),'r','LineWidth',2)
title('$$\rho$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,3);
hold on
plot(parasim(ts:te,3))
plot(rparasim(ts:te,3),'r','LineWidth',2)
if model==1 || model==11
title('$$\pi$$','Interpreter','latex','FontSize',18)
elseif model==2
title('$$\rho_s$$','Interpreter','latex','FontSize',18)    
end
axis tight
subplot(3,4,4);
hold on
plot(parasim(ts:te,4))
plot(rparasim(ts:te,4),'r','LineWidth',2)
title('$$\sigma$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,5);
hold on
plot(parasim(ts:te,5))
plot(rparasim(ts:te,5),'r','LineWidth',2)
title('$$\varphi_x$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,6);
hold on
plot(parasim(ts:te,6))
plot(rparasim(ts:te,6),'r','LineWidth',2)
title('$$\varphi_d$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,7);
hold on
plot(parasim(ts:te,7))
plot(rparasim(ts:te,7),'r','LineWidth',2)
title('$$\sigma_{A,\epsilon}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,8);
hold on
plot(parasim(ts:te,8))
plot(rparasim(ts:te,8),'r','LineWidth',2)
title('$$\sigma_{\epsilon}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,9);
hold on
plot(hbsim(ts:te,1))
plot(rhbsim(ts:te,1),'r','LineWidth',2)
title('$$\nu_c$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,10);
hold on
plot(hbsim(ts:te,2))
plot(rhbsim(ts:te,2),'r','LineWidth',2)
title('$$\nu_d$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,11);
hold on
plot(hvsim2(ts:te,2))
plot(rhvsim(ts:te,2),'r','LineWidth',2)
title('$$\sigma_{\nu,d}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,4,12);
hold on
plot(postsim(ts:te,:))
plot(rpostsim(ts:te,:),'r','LineWidth',2)
title('$$\log p(y|\theta)+\log p(\theta)$$','Interpreter','latex','FontSize',15)
axis tight

set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);
%FIGURE_STATE