clc;clear
%% load data
M = 12;
loaddata

load results

varphi_grid = 0.01:0.01:2.5;
rho_grid    = [-0.9:0.1:-0.3 -0.29:0.01:0.99 0.991:1e-3:0.999];

nV = length(varphi_grid);
nR = length(rho_grid);

store  = zeros(nR,nV);
store1 = zeros(nR,nV);
store2 = zeros(nR,nV);

para  = parameter(:,1);
para1 = parameter(:,2);
para2 = [0.0016 0 0.01 0.0033 0.0]';


for ii=1:nR
    ii
    for jj=1:nV
        % with measurement errors
        para(2)  = rho_grid(ii);
        para(3)  = varphi_grid(jj);
        loglh    = evalmod(para,YDATA(end-671:end,:),index(end-671:end,:),1,M);

        % without measurement errors
        para1(2) = rho_grid(ii);
        para1(3) = varphi_grid(jj);
        loglh1   = evalmod(para1,YDATA(end-671:end,:),index(end-671:end,:),2,M);
        
        para2(2) = rho_grid(ii);
        para2(3) = varphi_grid(jj);       
        loglh2   = evalmod(para2,YDATA(end-671:end,:),index(end-671:end,:),2,M);
        
        
        store(ii,jj)  = -loglh;
        store1(ii,jj) = -loglh1;
        store2(ii,jj) = -loglh2;
    end
end


for ii=1:nR
    for jj=1:nV
       if store(ii,jj)==max(max(store));
           answer01 = [ii,jj];
           answer02 = [rho_grid(ii) varphi_grid(jj)];
       end
       if store1(ii,jj)==max(max(store1));
           answer11 = [ii,jj];
           answer12 = [rho_grid(ii) varphi_grid(jj)];
       end
       if store2(ii,jj)==max(max(store2));
           answer21 = [ii,jj];
           answer22 = [rho_grid(ii) varphi_grid(jj)];
       end
    end
end

lh  = max(max(store));
lh1 = max(max(store1));
lh2 = max(max(store2));


FIGURE_SURFACE