function [loglh, At_mat] = evalmod(para,YDATA,index,select,M)

T   = size(YDATA,1);
% model-coefficients
[DD,ZZ,PHIF,SIG,RR] = coefficients(para,select,M);

mZ   = size(ZZ,1);
mdim = size(PHIF,1);

% initialization of the filter    
Pt = zeros(mdim,mdim);
for ii=1:50
   Pt = PHIF*Pt*PHIF' + SIG; 
end
At = zeros(mdim,1);    
At_mat = zeros(T,mdim);
Pt_mat = zeros(T,mdim^2);   
   
loglh  = 0;

% Filter loop 
for t = 1:T

    if index(t)==1     % we have consumption data (MF)
        MS            = zeros(M,mZ);
        MS(1:M,1:M)   = eye(M);
        MS(end,end)   = 1;     
        data          = YDATA(t,1:M)';
        pass          = 0;
    elseif index(t)==0 % we dont' have consumption data (MF)
        MS            = [];
        data          = [];
        pass          = 1;
    end
        
    At1  = At;
    Pt1  = Pt;

    % Forecasting   
    alphahat = PHIF * At1 ;
    Phat     = PHIF * Pt1 * PHIF' + SIG;
    Phat     = 0.5*(Phat+Phat');

    % we have data
    if pass == 0
        
        MD = MS*DD;
        MZ = MS*ZZ;
        MR = MS*RR*MS';        

        yhat = MD+MZ*alphahat;
        nut  = data - yhat;

        Ft = MZ*Phat*MZ' + MR;  
        Ft = 0.5*(Ft+Ft');

        invFt = eye(size(Ft,1))/Ft;
        detFt = det(Ft);       

        loglh = loglh -0.5*length(data)*log(2*pi)-0.5*log(detFt)-0.5*nut'*invFt*nut;

        % updating 
        At = alphahat + (Phat*MZ')*invFt*nut;
        Pt = Phat - (Phat*MZ')*invFt*(Phat*MZ')';   

    % we don't have data    
    elseif pass==1
            
        At = alphahat;
        Pt = Phat;
        
    end
        
    At_mat(t,:)  = At';
    Pt_mat(t,:)  = reshape(Pt,1,mdim^2);


end

loglh = -loglh;
