clc;clear;

load 1959_MONTHLY.txt
load 1947_QUARTERLY.txt
load 1930_ANNUAL.txt

gr_mcon = X1959_MONTHLY;
gr_qcon = X1947_QUARTERLY;
gr_acon = X1930_ANNUAL;


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.0]);

mtime = 1959+2/12:1/12:2015;
qtime = 1947+.5:.25:2015;
atime = 1930:1:2014;

nQ = find(qtime==1959);
nA = find(atime==1958);

[macf,mlag] = autocorr(gr_mcon);

[qacf1,qlag1] = autocorr(gr_qcon(nQ+1:end));
[qacf2,qlag2] = autocorr(gr_qcon);

[aacf1,alag1] = autocorr(gr_acon(nA+1:end));
[aacf2,alag2] = autocorr(gr_acon);


subplot(1,3,1)
b=bar(qlag1(2:4),[macf(2:4) macf(2:4)]);
set(b(1),'FaceColor',[0.1 0.1 0.1],'EdgeColor',[.1 .1 .1]);
set(b(2),'FaceColor',[1   1   1],'EdgeColor',[1 1 1]);
h = legend('1959-2014');
set(h,'location','southeast');
legend('boxoff');
line([0.5 3.5],[0 0],'Color',[0 0 0])
axis([0.5 3.5 -0.21 0.52])
xlabel('Lag')
title('Monthly')

subplot(1,3,2)
b=bar(qlag1(2:4),[qacf1(2:4) qacf2(2:4)]);
set(b(1),'FaceColor',[0.1 0.1 0.1],'EdgeColor',[.1 .1 .1]);
set(b(2),'FaceColor',[0.9 0.9 0.9],'EdgeColor',[.1 .1 .1]);
h = legend('1959-2014','1947-2014');
set(h,'location','southwest');
legend('boxoff');
axis([0.5 3.5 -0.21 0.52])
xlabel('Lag')
title('Quarterly')

subplot(1,3,3)
b=bar(alag1(2:4),[aacf1(2:4) aacf2(2:4)]);
set(b(1),'FaceColor',[0.1 0.1 0.1],'EdgeColor',[.1 .1 .1]);
set(b(2),'FaceColor',[0.9 0.9 0.9],'EdgeColor',[.1 .1 .1]);
h = legend('1959-2014','1930-2014');
set(h,'location','southwest');
legend('boxoff');
axis([0.5 3.5 -0.21 0.52])
xlabel('Lag')
title('Annual')

