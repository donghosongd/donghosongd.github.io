% load consumption data
load 1959_MONTHLY.txt
load 1947_QUARTERLY.txt
load 1930_ANNUAL.txt

gr_mcon = X1959_MONTHLY;
gr_qcon = X1947_QUARTERLY;
gr_acon = X1930_ANNUAL;

clear YCM
YCM = [];
for gg=1:M
    YCM = [YCM gr_mcon(M+1-gg:end+1-gg)];
end
top = [];
for gg=1:M-1
    top = [top gr_mcon(M-gg)];
end
top = [top 0];
YCM = [top;YCM];
YCM = [zeros(M-1,M);YCM];

% redefine data
if M==12
    YCA  = kron(gr_acon,ones(M,1));
    pick = 1960;
elseif M==3
    YCA  = kron(gr_qcon,ones(M,1));    
    pick = 1959+6/12; 
end

% set time and index
time         = 1930+1/12:1/12:2015;
indexM       = repmat([zeros(M-1,1);1],length(time)/M,1);
indexA       = repmat([zeros(M-1,1);M],length(time)/M,1);
cut          = find(time==pick);
indexM(1:cut) = M*indexM(1:cut);
nT           = length(time);

indexM(1:nT-size(YCA,1))  = 0;
indexA(1:nT-size(YCA,1)) = 0;

% store data
YA                          = zeros(nT,1);
YA(end-size(YCA,1)+1:end,:) = YCA;
YM                          = zeros(nT,M);
YM(end-size(YCM,1)+1:end,:) = YCM;

YD                          = zeros(nT,M);

for t = 1:nT
    if indexM(t)==1     % we have monthly consumption data 
        YD(t,1:M) = YM(t,:) ;
    elseif indexM(t)==M % we have low-frequency consumption data
        YD(t,1)   = YA(t,:);
    end
end

YDATA = YD;
index = indexM;

