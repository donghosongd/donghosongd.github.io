scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')  

fig1 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/20 scrsz(3)/4 scrsz(4)/2]);
contourf(varphi_grid(1:end),rho_grid,store(:,1:end));axis tight
ylabel('$$\rho$$','interpreter','latex','FontSize',40)
xlabel('$$\varphi_x$$','interpreter','latex','FontSize',40)
set(gca,'FontSize',30)
colormap gray
line([answer02(2) answer02(2)],[rho_grid(1) 1],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
line([varphi_grid(1) varphi_grid(end)],[answer02(1) answer02(1)],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
text(answer02(2)-.6,answer02(1)-0.075,['$$\log p(Y|\Theta)=$$ ' num2str(floor(lh)) ],'interpreter','latex','HorizontalAlignment','left','FontSize',25)
xlim([0 2.5])

fig2 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/20 scrsz(3)/4 scrsz(4)/2]);
contourf(varphi_grid(1:end),rho_grid,store1(:,1:end));axis tight
ylabel('$$\rho$$','interpreter','latex','FontSize',40)
xlabel('$$\varphi_x$$','interpreter','latex','FontSize',40)
set(gca,'FontSize',30)
colormap gray
line([answer12(2) answer12(2)],[rho_grid(1) 1],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
line([varphi_grid(1) varphi_grid(end)],[answer12(1) answer12(1)],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
text(answer12(2)-0.65,answer12(1)-0.075,['$$\log p(Y|\Theta)= $$ ' num2str(floor(lh1)) ],'interpreter','latex','HorizontalAlignment','left','FontSize',25)
xlim([0 2.5])

fig3 = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/20 scrsz(3)/4 scrsz(4)/2]);
contourf(varphi_grid(1:end),rho_grid,store2(:,1:end));axis tight
ylabel('$$\rho$$','interpreter','latex','FontSize',40)
xlabel('$$\varphi_x$$','interpreter','latex','FontSize',40)
set(gca,'FontSize',30)
colormap gray
line([answer22(2) answer22(2)],[rho_grid(1) 1],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
line([varphi_grid(1) varphi_grid(end)],[answer22(1) answer22(1)],'Color',[0.1 0.1 0.1],'LineStyle','--','LineWidth',2)
text(answer22(2)+0.02,answer22(1)-0.075,['$$\log p(Y|\Theta)= $$ ' num2str(floor(lh2)) ],'interpreter','latex','HorizontalAlignment','left','FontSize',25)
xlim([0 2.5])













