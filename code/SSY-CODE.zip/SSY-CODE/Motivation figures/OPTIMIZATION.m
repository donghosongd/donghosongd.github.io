clc;clear
%% load data
M = 12;
loaddata

%% parameters
% mu    = para(1);
% rho   = para(2);
% xie   = para(3);
% sigma = para(4);
% bvar1 = para(5);
bound     = [[-10    10];
             [-.9999 .9999];
             [0      2];
             [1e-10  10];
             [1e-10  10]]; 
         
parameter = zeros(5,2);

for select=1:2
    if select==1
        init = [0.0016 0.92 0.50 0.0018 0.0018]';
    elseif select==2
        init = [0.0016 -0.26 1.20 0.0033 0.000]';        
    end

    fcn  = @(x) evalmod(x,YDATA(end-671:end,:),index(end-671:end,:),select,M);
 
    para = fmincon(fcn,init,[],[],[],[],bound(:,1),bound(:,2));

    parameter(1:length(para),select) = para;
end

parameter(end,2) = 0;

save('results.mat','parameter')