% % de-trend PD data
% nPD  = length(PDdata2);
% beta = [ones(nPD,1) [1:1:nPD]']\PDdata2;
% PDdata2 = PDdata2 - [1:1:nPD]'*beta(2);

%% predictive regression
disp('                                                         ');
disp('    PREDICTABILITY REGRESSION                            ');
disp('                                                         ');
for jj=1:nsim
        % report 
        if mod(jj,500)==0      
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(jj)]                 );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-jj)]            );
        disp('                                                         ');  
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');
        end

        [Rsquare] = var_predictability([Dvec(jj,:)'  Pvec(jj,:)'],WW,1) ; 
        DR2VAR_model_2var(jj,:) = Rsquare(:,1);  
        
        [Rsquare] = var_predictability([Cvec(jj,:)' Pvec(jj,:)' Fvec(jj,:)'],WW,1) ; 
        CR2VAR_model_3var(jj,:) = Rsquare(:,1);  
        
        [Rsquare] = var_predictability([Dvec(jj,:)'  Rvec(jj,:)' Pvec(jj,:)'],WW,1) ; 
        DR2VAR_model_3var(jj,:) = Rsquare(:,1);  
        
        [Rsquare] = var_predictability([Cvec(jj,:)' Rvec(jj,:)'-Fvec(jj,:)' Pvec(jj,:)' Fvec(jj,:)'],WW,1) ; 
        CR2VAR_model_4var(jj,:) = Rsquare(:,1);  
        XR2VAR_model_4var(jj,:) = Rsquare(:,2);  
        
        [Rsquare] = var_predictability([Dvec(jj,:)' Cvec(jj,:)' Pvec(jj,:)' Fvec(jj,:)'],WW,1) ; 
        DR2VAR_model_4var(jj,:) = Rsquare(:,1);  
        
        [Rsquare] = var_predictability([Cvec(jj,:)' Rvec(jj,:)'-Fvec(jj,:)' Pvec(jj,:)' Fvec(jj,:)' Dvec(jj,:)'],WW,1) ; 
        DR2VAR_model_5var(jj,:) = Rsquare(:,5);  
        
        
        CXcrcorr_vec(jj,:) = crosscorr(Cvec(jj,:)',Rvec(jj,:)'-Fvec(jj,:)',3);
        CDcrcorr_vec(jj,:) = crosscorr(Cvec(jj,:)',Dvec(jj,:)',3);
        CFcrcorr_vec(jj,:) = crosscorr(Cvec(jj,:)',Fvec(jj,:)',3);
        CMcrcorr_vec(jj,:) = crosscorr(Cvec(jj,:)',Rvec(jj,:)',3);

        instrument = [Cvec(jj,:)' Rvec(jj,:)' Fvec(jj,:)' Pvec(jj,:)'];
        lag = 2;
        instrument = instrument(1:end-lag,:); 
        cT = size(instrument,1);
        zZ = [ones(cT,1) instrument];
        yY = Cvec(jj,lag+1:end)';
        xX = Fvec(jj,lag+1:end)';        
        xxhat = [ones(cT,1) zZ*(zZ\xX)];
        ols   = xxhat\yY;         
        ConFvec_af(jj,:) = ols(2);
        xX = Cvec(jj,lag+1:end)';
        yY = Fvec(jj,lag+1:end)';        
        xxhat = [ones(cT,1) zZ*(zZ\xX)];
        ols   = xxhat\yY;         
        FonCvec_af(jj,:) = 1/ols(2);


    for ww=1:WW        
        nt  = nT/12-2;
        YYA = zeros(nt-ww,1);
        YYB = zeros(nt-ww,1); 
        YYC = zeros(nt-ww,1);
        YY1 = zeros(nt-ww,1);
        YY2 = zeros(nt-ww,1);
        YY3 = zeros(nt-ww,1);
        YY4 = zeros(nt-ww,1);

        for tt=1:nt-ww
            YYA(tt)  = sum(GD(tt+1:tt+ww));
            YYB(tt)  = sum(RM(tt+1:tt+ww))-sum(RF(tt+1:tt+ww));      
            YYC(tt)  = sum(RD(tt+1:tt+ww));
            YY1(tt)  = sum(Cvec(jj,tt+1:tt+ww));
            YY2(tt)  = sum(Rvec(jj,tt+1:tt+ww))-sum(Fvec(jj,tt+1:tt+ww));
            YY3(tt)  = sum(Dvec(jj,tt+1:tt+ww));
            YY4(tt)  = sum(Rvec(jj,tt+1:tt+ww));
        end       
        ntt = size(YY1);
                
        cov_PC  = cov(YY1,Pvec(jj,1:ntt)');
        cov_PX  = cov(YY2,Pvec(jj,1:ntt)');
        cov_PCT = cov(YYA,PDdata2(1:ntt)');
        cov_PXT = cov(YYB,PDdata2(1:ntt)');
              
        COV_PC(jj,ww)  = cov_PC(1,2)^2;
        COV_PX(jj,ww)  = cov_PX(1,2)^2;
        COV_PCT(jj,ww) = cov_PCT(1,2)^2;
        COV_PXT(jj,ww) = cov_PXT(1,2)^2;
        
        VAR_P(jj,ww)  = var(Pvec(jj,1:ntt));
        VAR_C(jj,ww)  = var(YY1);
        VAR_X(jj,ww)  = var(YY2);
        VAR_PT(jj,ww) = var(PDdata2(1:ntt));
        VAR_CT(jj,ww) = var(YYA);
        VAR_XT(jj,ww) = var(YYB);     
        
        pR2_C(jj,ww) = cov_PC(1,2)^2./(var(YY1)*var(Pvec(jj,1:ntt)));
        pR2_R(jj,ww) = cov_PX(1,2)^2./(var(YY2)*var(Pvec(jj,1:ntt)));
        pR2_CT(jj,ww) = cov_PCT(1,2)^2./(var(YYA)*var(PDdata2(1:ntt)));
        pR2_RT(jj,ww) = cov_PXT(1,2)^2./(var(YYB)*var(PDdata2(1:ntt)));
        
        XX  = [ones(size(YY1,1),1) Pvec(jj,1:ntt)'];
        XXM = [ones(size(YY1,1),1) Dvec(jj,1:ntt)' Pvec(jj,1:ntt)' Fvec(jj,1:ntt)'];
        XXA = [ones(size(YY1,1),1) PDdata2(1:ntt)];
        XXAM = [ones(size(YY1,1),1) RD(1:ntt) PDdata2(1:ntt) RF(1:ntt)];
        
        [b1,bint1,r1,rint1,stats1] = regress(YY1,XX);
        [b2,bint2,r2,rint2,stats2] = regress(YY2,XX);
        [b3,bint3,r3,rint3,stats3] = regress(YY3,XX);
        
        [bA,bintA,rA,rintA,statsA] = regress(YYA,XXA);
        [bB,bintB,rB,rintB,statsB] = regress(YYB,XXA);
        [bC,bintC,rC,rintC,statsC] = regress(YYC,XXA);
        
        B_C(jj,ww) = b1(2);
        B_R(jj,ww) = b2(2);     
        B_D(jj,ww) = b3(2);
        
        R2_C(jj,ww)  = stats1(1)*100;
        R2_R(jj,ww)  = stats2(1)*100;  
        R2_D(jj,ww)  = stats3(1)*100;  
        
        R2_CT(jj,ww)  = statsA(1)*100;
        R2_RT(jj,ww)  = statsB(1)*100;  
        R2_DT(jj,ww)  = statsC(1)*100;  
     
        C_CR(jj,ww)  = corr(YY1,YY4);
        C_CX(jj,ww)  = corr(YY1,YY2);
        C_DR(jj,ww)  = corr(YY3,YY4);
        C_DX(jj,ww)  = corr(YY3,YY2);

    end

    CORR(jj,1) = corr(Cvec(jj,:)',Dvec(jj,:)');
    CORR(jj,2) = corr(Cvec(jj,:)',Rvec(jj,:)');

    autoC = autocorr(Cvec(jj,:));
    autoD = autocorr(Dvec(jj,:));
    autoR = autocorr(Rvec(jj,:));
    autoF = autocorr(Fvec(jj,:));
    autoP = autocorr(Pvec(jj,:));
    AUTO(jj,1) = autoC(2);
    AUTO(jj,2) = autoD(2);
    AUTO(jj,3) = autoR(2);
    AUTO(jj,4) = autoF(2);
    AUTO(jj,5) = autoP(2);

end

slope_ConF_mf = regress(YY(end-mT+1:end,1),[ones(mT,1) YY(end-mT+1:end,4)]);
ConFdata_mf = slope_ConF_mf(2);
slope_FonC_mf = regress(YY(end-mT+1:end,4),[ones(mT,1) YY(end-mT+1:end,1)]);
FonCdata_mf = 1/slope_FonC_mf(2);

instrument = [RM(1:AT,:) GD(1:AT,:) PDdata2(1:AT,:) RF(1:AT,:)];
lag = 2;
instrument = instrument(1:end-lag,:);
cT = size(instrument,1);
zz = [ones(cT,1) instrument];
yy = GD(lag+1:AT,:);
xx = RF(lag+1:AT,:);

xxhat = [ones(cT,1) zz*(zz\xx)];
ols   = xxhat\yy;

ConFdata_af = ols(2);

instrument = [RM(1:AT,:) GD(1:AT,:) PDdata2(1:AT,:) RF(1:AT,:)];
lag = 2;
instrument = instrument(1:end-lag,:);
cT = size(instrument,1);
zz = [ones(cT,1) instrument];
xx = GD(lag+1:AT,:);
yy = RF(lag+1:AT,:);

xxhat = [ones(cT,1) zz*(zz\xx)];
ols   = xxhat\yy;
FonCdata_af = 1./ols(2);

% slope_ConF_af = regress(GD,[ones(82,1) RF]);
% ConFdata_af = slope_ConF_af(2);
% slope_FonC_af = regress(RF,[ones(82,1) GD]);
% FonCdata_af = 1/slope_FonC_af(2);

[CFbetaM95,CFbetaM80,CFbetaM50,CFbetaM20,CFbetaM05] = moment2(ConFvec_mf);
[FCbetaM95,FCbetaM80,FCbetaM50,FCbetaM20,FCbetaM05] = moment2(FonCvec_mf);

[CFbetaA95,CFbetaA80,CFbetaA50,CFbetaA20,CFbetaA05] = moment2(ConFvec_af);
[FCbetaA95,FCbetaA80,FCbetaA50,FCbetaA20,FCbetaA05] = moment2(FonCvec_af);

sum_CFbetaM = [ConFdata_mf CFbetaM05 CFbetaM20 CFbetaM50 CFbetaM80 CFbetaM95];
sum_FCbetaM = [FonCdata_mf FCbetaM05 FCbetaM20 FCbetaM50 FCbetaM80 FCbetaM95];

sum_CFbetaA = [ConFdata_af CFbetaA05 CFbetaA20 CFbetaA50 CFbetaA80 CFbetaA95];
sum_FCbetaA = [FonCdata_af FCbetaA05 FCbetaA20 FCbetaA50 FCbetaA80 FCbetaA95];

[Rsquare] = var_predictability([RD PDdata2],WW,1) ; 
DR2VAR_data_2var(:) = 100*Rsquare(:,1);  

[Rsquare] = var_predictability([GD PDdata2 RF],WW,1) ; 
CR2VAR_data_3var(:) = 100*Rsquare(:,1);  
      
[Rsquare] = var_predictability([RD PDdata2 RM],WW,1) ; 
DR2VAR_data_3var(:) = 100*Rsquare(:,1);  

[Rsquare] = var_predictability([GD RM-RF PDdata2 RF],WW,1) ; 
CR2VAR_data_4var(:) = 100*Rsquare(:,1);  
XR2VAR_data_4var(:) = 100*Rsquare(:,2);  

[Rsquare] = var_predictability([GD RF PDdata2 RD],WW,1) ; 
DR2VAR_data_4var(:) = 100*Rsquare(:,4);

[Rsquare] = var_predictability([GD RM-RF PDdata2 RF RD],WW,1) ; 
DR2VAR_data_5var(:) = 100*Rsquare(:,5);


[CRS3V95,CRS3V80,CRS3V50,CRS3V20,CRS3V05] = moment2(100*CR2VAR_model_3var);
[CRS4V95,CRS4V80,CRS4V50,CRS4V20,CRS4V05] = moment2(100*CR2VAR_model_4var);
[DRS3V95,DRS3V80,DRS3V50,DRS3V20,DRS3V05] = moment2(100*DR2VAR_model_3var);
[XRS4V95,XRS4V80,XRS4V50,XRS4V20,XRS4V05] = moment2(100*XR2VAR_model_4var);
[DRS4V95,DRS4V80,DRS4V50,DRS4V20,DRS4V05] = moment2(100*DR2VAR_model_4var);
[DRS5V95,DRS5V80,DRS5V50,DRS5V20,DRS5V05] = moment2(100*DR2VAR_model_5var);

sum_CRS3V = [CR2VAR_data_3var' CRS3V05 CRS3V20 CRS3V50' CRS3V80 CRS3V95];
sum_CRS4V = [CR2VAR_data_4var' CRS4V05 CRS4V20 CRS4V50' CRS4V80 CRS4V95];
sum_DRS3V = [DR2VAR_data_3var' DRS3V05 DRS3V20 DRS3V50' DRS3V80 DRS3V95];
sum_XRS4V = [XR2VAR_data_4var' XRS4V05 XRS4V20 XRS4V50' XRS4V80 XRS4V95];
sum_DRS4V = [DR2VAR_data_4var' DRS4V05 DRS4V20 DRS4V50' DRS4V80 DRS4V95];
sum_DRS5V = [DR2VAR_data_5var' DRS5V05 DRS5V20 DRS5V50' DRS5V80 DRS5V95];


CXcrcorr_data = crosscorr(GD,RM-RF,3);
CDcrcorr_data = crosscorr(GD,RD,3);
CFcrcorr_data = crosscorr(GD,RF,3);
CMcrcorr_data = crosscorr(GD,RM,3);


[CXcrcr95,CXcrcr80,CXcrcr50,CXcrcr20,CXcrcr05] = moment2(CXcrcorr_vec);
[CDcrcr95,CDcrcr80,CDcrcr50,CDcrcr20,CDcrcr05] = moment2(CDcrcorr_vec);
[CFcrcr95,CFcrcr80,CFcrcr50,CFcrcr20,CFcrcr05] = moment2(CFcrcorr_vec);
[CMcrcr95,CMcrcr80,CMcrcr50,CMcrcr20,CMcrcr05] = moment2(CMcrcorr_vec);




[VP95,VP80,VP50,VP20,VP05] = moment2(100*VAR_P);
[VC95,VC80,VC50,VC20,VC05] = moment2(100*VAR_C);
[VX95,VX80,VX50,VX20,VX05] = moment2(100*VAR_X);

[CVC95,CVC80,CVC50,CVC20,CVC05] = moment2(10000*COV_PC);
[CVX95,CVX80,CVX50,CVX20,CVX05] = moment2(10000*COV_PX);

sum_DPC   = [10000*COV_PCT(1,:)' 100*VAR_PT(1,:)' 100*VAR_CT(1,:)' CVC05 CVC50' CVC95 VP05 VP50' VP95 VC05 VC50' VC95];
sum_DPX   = [10000*COV_PXT(1,:)' 100*VAR_PT(1,:)' 100*VAR_XT(1,:)' CVX05 CVX50' CVX95 VP05 VP50' VP95 VX05 VX50' VX95];


[csv1m95,csv1m80,csv1m50,csv1m20,csv1m05] = moment2(R2_C);
[csv2m95,csv2m80,csv2m50,csv2m20,csv2m05] = moment2(R2_R);
[csv3m95,csv3m80,csv3m50,csv3m20,csv3m05] = moment2(R2_D);

sum_CSV_1 = [R2_CT(end,:)' csv1m05 csv1m20 csv1m50' csv1m80 csv1m95];
sum_CSV_2 = [R2_RT(end,:)' csv2m05 csv2m20 csv2m50' csv2m80 csv2m95];
sum_CSV_3 = [R2_DT(end,:)' csv3m05 csv3m20 csv3m50' csv3m80 csv3m95];


[CC95,CC80,CC50,CC20,CC05] = moment2(std(Cvec')');
[RR95,RR80,RR50,RR20,RR05] = moment2(std(Rvec')');
[DD95,DD80,DD50,DD20,DD05] = moment2(std(Dvec')');
[FF95,FF80,FF50,FF20,FF05] = moment2(std(Fvec')');
[PP95,PP80,PP50,PP20,PP05] = moment2(std(Pvec')');

[mC95,mC80,mC50,mC20,mC05] = moment2(mean(Cvec')');
[mR95,mR80,mR50,mR20,mR05] = moment2(mean(Rvec')');
[mD95,mD80,mD50,mD20,mD05] = moment2(mean(Dvec')');
[mF95,mF80,mF50,mF20,mF05] = moment2(mean(Fvec')');
[mP95,mP80,mP50,mP20,mP05] = moment2(mean(Pvec')');

[mX95,mX80,mX50,mX20,mX05] = moment2(mean(RXvec')');

[aa95,aa80,aa50,aa20,aa05] = moment2(AUTO);
[co95,co80,co50,co20,co05] = moment2(CORR);

dautoG = autocorr(GD);
dautoD = autocorr(RD);
dautoR = autocorr(RM);
dautoF = autocorr(RF);
dautoP = autocorr(PDdata2);

sum_AT = [[dautoG(2);dautoD(2);dautoR(2);dautoF(2);dautoP(2)] aa05 aa20 aa50' aa80 aa95];


sum_CO = [[corr(GD,RD);corr(GD,RM)] co05 co20 co50' co80 co95];

sum_DYN05 = [100*mC05 100*CC05 aa05(1)...
             100*mD05 100*DD05 aa05(2) co05(1)...
             100*mR05 100*RR05 aa05(3) co05(2)...
             100*mF05 100*FF05 aa05(4)...
             mP05 PP05 aa05(5)]';
sum_DYN20 = [100*mC20 100*CC20 aa20(1)...
             100*mD20 100*DD20 aa20(2) co20(1)...
             100*mR20 100*RR20 aa20(3) co20(2)...
             100*mF20 100*FF20 aa20(4)...
             mP20 PP20 aa20(5)]';
sum_DYN50 = [100*mC50 100*CC50 aa50(1)...
             100*mD50 100*DD50 aa50(2) co50(1)...
             100*mR50 100*RR50 aa50(3) co50(2)...
             100*mF50 100*FF50 aa50(4)...
             mP50 PP50 aa50(5)]';        
sum_DYN80 = [100*mC80 100*CC80 aa80(1)...
             100*mD80 100*DD80 aa80(2) co80(1)...
             100*mR80 100*RR80 aa80(3) co80(2)...
             100*mF80 100*FF80 aa80(4)...
             mP80 PP80 aa80(5)]';
sum_DYN95 = [100*mC95 100*CC95 aa95(1)...
             100*mD95 100*DD95 aa95(2) co95(1)...
             100*mR95 100*RR95 aa95(3) co95(2)...
             100*mF95 100*FF95 aa95(4)...
             mP95 PP95 aa95(5)]';      

sum_DYN00 = [100*mean(GD) 100*std(GD) dautoG(2)...
             100*mean(RD) 100*std(RD) dautoD(2) corr(GD,RD)...
             100*mean(RM) 100*std(RM) dautoR(2) corr(GD,RM)...
             100*mean(RF) 100*std(RF) dautoF(2) ...
             mean(PDdata2) std(PDdata2) dautoP(2)]';


sum_DYN = [sum_DYN00 sum_DYN05 sum_DYN20 sum_DYN50 sum_DYN80 sum_DYN95]; 

sum_EXC = [mX05,mX20,mX50,mX80,mX95]*100;

clc

% compute correlation and confidence interval
CB_ZCM = zeros(WW,3);
CB_ZDM = zeros(WW,3);
CB_ZCX = zeros(WW,3);
CB_ZDX = zeros(WW,3);            

for ww=1:WW
    ZC  = zeros(nt-ww,1);
    ZD  = zeros(nt-ww,1);
    ZM  = zeros(nt-ww,1);
    ZX  = zeros(nt-ww,1);
    
for tt=1:nt-ww
    ZC(tt)  = sum(GD(tt:tt+ww));
    ZD(tt)  = sum(RD(tt:tt+ww));
    ZM(tt)  = sum(RM(tt:tt+ww));
    ZX(tt)  = sum(RM(tt:tt+ww))-sum(RF(tt:tt+ww));   
end
    [R,P,RLO,RUP] = corrcoef(ZC,ZM);    
    CB_ZCM(ww,:) = [RLO(1,2) R(1,2) RUP(1,2)];
    
    [R,P,RLO,RUP] = corrcoef(ZD,ZM);    
    CB_ZDM(ww,:) = [RLO(1,2) R(1,2) RUP(1,2)];   
    
    [R,P,RLO,RUP] = corrcoef(ZC,ZX);    
    CB_ZCX(ww,:) = [RLO(1,2) R(1,2) RUP(1,2)];
    
    [R,P,RLO,RUP] = corrcoef(ZD,ZX);    
    CB_ZDX(ww,:) = [RLO(1,2) R(1,2) RUP(1,2)];      
    
end 

[cm95,cm80,cm50,cm20,cm05] = moment2(C_CR);
[dm95,dm80,dm50,dm20,dm05] = moment2(C_DR);

sum_CM = [CB_ZCM cm05 cm20 cm50' cm80 cm95];
sum_DM = [CB_ZDM dm05 dm20 dm50' dm80 dm95];

[cx95,cx80,cx50,cx20,cx05] = moment2(C_CX);
[dx95,dx80,dx50,dx20,dx05] = moment2(C_DX);

sum_CX = [CB_ZCX cx05 cx20 cx50' cx80 cx95];
sum_DX = [CB_ZDX dx05 dx20 dx50' dx80 dx95];


vartype = {'mean con','std con','autocorr con',...
   'mean div','std div','autocorr div','corr(con,div)',...
   'mean rm','std rm','autocorr rm','corr(con,rm)',...
   'mean rf','std rf','autocorr rf',...
   'mean pd','std pd','autocorr pd'};

disp('========================================================================================'); 
disp('                                                                                        ');
disp('                       DYNAMICS OF GROWTH RATES AND PRICES                              ');
disp('                                                                                        ');
disp('========================================================================================');
disp([' Moment                    Data         5%        20%        50%        80%        95% ']);
disp('========================================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DYN(hh,1),...
        sum_DYN(hh,2),sum_DYN(hh,3),sum_DYN(hh,4),sum_DYN(hh,5),sum_DYN(hh,6));    
end
disp('========================================================================================');


disp('======================================================================='); 
disp('                                                                       ');
disp('                       DYNAMICS OF GROWTH RATES AND PRICES             ');
disp('                                                                       ');
disp('=======================================================================');
disp([' Moment                    Data         5%        50%        95%      ']);
disp('=======================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DYN(hh,1),...
        sum_DYN(hh,2),sum_DYN(hh,4),sum_DYN(hh,6));    
end
disp('=======================================================================');



vartype = {'equity premium'};

disp('========================================================================================'); 
disp('                                                                                        ');
disp('                       DYNAMICS OF GROWTH RATES AND PRICES                              ');
disp('                                                                                        ');
disp('========================================================================================');
disp([' Moment                                 5%        20%        50%        80%        95% ']);
disp('========================================================================================');
for hh=1:length(vartype);
    fprintf('%-32s %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_EXC(hh,1),...
        sum_EXC(hh,2),sum_EXC(hh,3),sum_EXC(hh,4),sum_EXC(hh,5));    
end
disp('========================================================================================');



vartype     = {'1yr','2yr','3yr','4yr','5yr','6yr','7yr','8yr','9yr','10yr'};

disp('================================================================================================='); 
disp('   Rsquare : SUM_{h=1}^{H}(Annual Consumption) = alpha + beta*REGRESSOR + error          ');
disp('                                                                                        ');
disp('                                 REGRESSOR: pd(t)                                       ');
disp('                                                                                        ');
disp('=================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('=================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CSV_1(hh,1),...
        sum_CSV_1(hh,2),sum_CSV_1(hh,3),sum_CSV_1(hh,4),sum_CSV_1(hh,5),sum_CSV_1(hh,6));    
end
disp('================================================================================================='); 
disp('  Rsquare : SUM_{h=1}^{H}(Annual Excess Returns) = alpha + beta*REGRESSOR + error        ');
disp('                                                                                        ');
disp('                                 REGRESSOR: pd(t)                                       ');
disp('                                                                                        ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CSV_2(hh,1),...
        sum_CSV_2(hh,2),sum_CSV_2(hh,3),sum_CSV_2(hh,4),sum_CSV_2(hh,5),sum_CSV_2(hh,6));    
end
disp('=================================================================================================='); 
disp('  Rsquare : SUM_{h=1}^{H}(Annual Dividend) = alpha + beta*REGRESSOR + error        ');
disp('                                                                                        ');
disp('                                 REGRESSOR: pd(t)                                       ');
disp('                                                                                        ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CSV_3(hh,1),...
        sum_CSV_3(hh,2),sum_CSV_3(hh,3),sum_CSV_3(hh,4),sum_CSV_3(hh,5),sum_CSV_3(hh,6));    
end
disp('=================================================================================================='); 





disp('==========================================================================================================================');
disp('                                         Predictability Rsquare Decompostion                                              '); 
disp('                                                                                                                          ');
disp('                                    Rsquare = cov(CON,REGRESSOR)^2/(var(CON)var(REGRESSOR))                               ');
disp('                                                                                                                          ');
disp('                      Rsquare : SUM_{h=1}^{H}(Annual Consumption) = alpha + beta*REGRESSOR + error                      ');
disp('                                                                                                                          ');
disp('                                             - numbers are multiplied by 100 -                                              ');
disp('                                                                                                                        ');
disp('                       Data                          Model                    Model                     Model            ');
disp('==========================================================================================================================');
disp(['             cov(P,C)^2 var(P) var(C)            cov(P,C)^2                   var(P)                    var(C)           ']);
disp('                                                                                                                         ');
disp([' Horizon                                   5%      50%      95%       5%       50%     95%       5%       50%      95% ']);
disp('==========================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-10s %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f\n',vartype{hh},sum_DPC(hh,1),...
        sum_DPC(hh,2),sum_DPC(hh,3),sum_DPC(hh,4),sum_DPC(hh,5),sum_DPC(hh,6),sum_DPC(hh,7),sum_DPC(hh,8),...
        sum_DPC(hh,9),sum_DPC(hh,10),sum_DPC(hh,11),sum_DPC(hh,12));   
end
disp('==========================================================================================================================');



disp('==========================================================================================================================');
disp('                                         Predictability Rsquare Decompostion                                              '); 
disp('                                                                                                                          ');
disp('                                    Rsquare = cov(EXR,REGRESSOR)^2/(var(EXR)var(REGRESSOR))                               ');
disp('                                                                                                                          ');
disp('                      Rsquare : SUM_{h=1}^{H}(Annual Excess Returns) = alpha + beta*REGRESSOR + error                     ');
disp('                                                                                                                          ');
disp('                                             - numbers are multiplied by 100 -                                              ');
disp('                                                                                                                        ');
disp('                       Data                          Model                    Model                     Model            ');
disp('==========================================================================================================================');
disp(['             cov(P,R)^2 var(P) var(R)            cov(P,R)^2                   var(P)                    var(R)           ']);
disp('                                                                                                                         ');
disp([' Horizon                                   5%      50%      95%       5%       50%     95%       5%       50%      95% ']);
disp('==========================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-10s %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f %8.2f\n',vartype{hh},sum_DPX(hh,1),...
        sum_DPX(hh,2),sum_DPX(hh,3),sum_DPX(hh,4),sum_DPX(hh,5),sum_DPX(hh,6),sum_DPX(hh,7),sum_DPX(hh,8),...
        sum_DPX(hh,9),sum_DPX(hh,10),sum_DPX(hh,11),sum_DPX(hh,12));   
end
disp('==========================================================================================================================');









disp('==================================================================================================================');
disp('                                                                                                                  '); 
disp('                                  CORRELATION: ANNUAL CONSUMPTION AND LOG MARKET RETURNS                         ');
disp('                                                                                                                 ');
disp('                                       Data                                       Model                          ');
disp('=================================================================================================================');
disp([' Horizon                   2.5%        50%       97.5%       5%        20%        50%        80%        95% ']);
disp('==================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CM(hh,1),...
        sum_CM(hh,2),sum_CM(hh,3),sum_CM(hh,4),sum_CM(hh,5),sum_CM(hh,6),sum_CM(hh,7),sum_CM(hh,8));   
end
disp('==================================================================================================================');

disp('==================================================================================================================');
disp('                                                                                                                  '); 
disp('                                  CORRELATION: ANNUAL CONSUMPTION AND EXCESS RETURNS                              ');
disp('                                                                                                                 ');
disp('                                       Data                                       Model                          ');
disp('=================================================================================================================');
disp([' Horizon                   2.5%        50%       97.5%       5%        20%        50%        80%        95% ']);
disp('==================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CX(hh,1),...
        sum_CX(hh,2),sum_CX(hh,3),sum_CX(hh,4),sum_CX(hh,5),sum_CX(hh,6),sum_CX(hh,7),sum_CX(hh,8));   
end
disp('=================================================================================================================');



disp('=================================================================================================================');
disp('                                                                                                                 '); 
disp('                                  CORRELATION: ANNUAL DIVIDEND AND LOG MARKET RETURNS                            ');
disp('                                                                                                                ');
disp('                                       Data                                       Model                          ');
disp('=================================================================================================================');
disp([' Horizon                   2.5%        50%       97.5%       5%        20%        50%        80%        95% ']);
disp('==================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DM(hh,1),...
        sum_DM(hh,2),sum_DM(hh,3),sum_DM(hh,4),sum_DM(hh,5),sum_DM(hh,6),sum_DM(hh,7),sum_DM(hh,8));   
end
disp('==================================================================================================================');

disp('==================================================================================================================');
disp('                                                                                                                  '); 
disp('                                  CORRELATION: ANNUAL DIVIDEND AND EXCESS RETURNS                                 ');
disp('                                                                                                                  ');
disp('                                       Data                                       Model                          ');
disp('=================================================================================================================');
disp([' Horizon                   2.5%        50%       97.5%       5%        20%        50%        80%        95% ']);
disp('==================================================================================================================');
for hh=1:length(vartype);
    fprintf('%-20s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DX(hh,1),...
        sum_DX(hh,2),sum_DX(hh,3),sum_DX(hh,4),sum_DX(hh,5),sum_DX(hh,6),sum_DX(hh,7),sum_DX(hh,8));   
end
disp('==================================================================================================================');


disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF CONSUMPTION GROWTH                    ');
disp('                                                                                                 ');
disp('                                               dC, p/d  rf                                       ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CRS3V(hh,1),...
        sum_CRS3V(hh,2),sum_CRS3V(hh,3),sum_CRS3V(hh,4),sum_CRS3V(hh,5),sum_CRS3V(hh,6));    
end
disp('=================================================================================================='); 



disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF DIVIDEND GROWTH                    ');
disp('                                                                                                 ');
disp('                                               dD, p/d  rf                                       ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DRS3V(hh,1),...
        sum_DRS3V(hh,2),sum_DRS3V(hh,3),sum_DRS3V(hh,4),sum_DRS3V(hh,5),sum_DRS3V(hh,6));    
end
disp('=================================================================================================='); 





disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF CONSUMPTION GROWTH                    ');
disp('                                                                                                 ');
disp('                                               dC, rm-rf  p/d  rf                                ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_CRS4V(hh,1),...
        sum_CRS4V(hh,2),sum_CRS4V(hh,3),sum_CRS4V(hh,4),sum_CRS4V(hh,5),sum_CRS4V(hh,6));    
end
disp('=================================================================================================='); 


disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF EXCESS RETURNS                       ');
disp('                                                                                                 ');
disp('                                               dC, rm-rf  p/d  rf                                ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_XRS4V(hh,1),...
        sum_XRS4V(hh,2),sum_XRS4V(hh,3),sum_XRS4V(hh,4),sum_XRS4V(hh,5),sum_XRS4V(hh,6));    
end
disp('=================================================================================================='); 


disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF DIVIDEND GROWTH                    ');
disp('                                                                                                 ');
disp('                                               dC, rm-rf  p/d  rd                                ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DRS4V(hh,1),...
        sum_DRS4V(hh,2),sum_DRS4V(hh,3),sum_DRS4V(hh,4),sum_DRS4V(hh,5),sum_DRS4V(hh,6));    
end
disp('=================================================================================================='); 


disp('================================================================================================='); 
disp('                             VAR IMPLIED PREDICTABILITY OF DIVIDEND GROWTH                    ');
disp('                                                                                                 ');
disp('                                               dC, rm-rf  p/d  rf  rd                             ');
disp('                                                                                                 ');
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
for hh=1:length(vartype);
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',vartype{hh},sum_DRS5V(hh,1),...
        sum_DRS5V(hh,2),sum_DRS5V(hh,3),sum_DRS5V(hh,4),sum_DRS5V(hh,5),sum_DRS5V(hh,6));    
end
disp('=================================================================================================='); 



varname = {'\psi'};
disp('================================================================================================='); 
disp('                             REGRESSION: Consumption on Risk Free Rate                           ');
disp('                                                                                                 ');
disp('                                    dC = constant + psi*rf + error                               ');
disp('                                                                                                 ');
disp('                                            Monthly Frequency                                    '); 
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',varname{1},sum_CFbetaM(1),...
        sum_CFbetaM(2),sum_CFbetaM(3),sum_CFbetaM(4),sum_CFbetaM(5),sum_CFbetaM(6));    
disp('=================================================================================================='); 
disp('                             REGRESSION: Risk Free Rate on Consumption                           ');
disp('                                                                                                 ');
disp('                                    rf = constant + (1/psi)*consumption + error                  ');
disp('                                                                                                 ');
disp('                                            Monthly Frequency                                    '); 
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',varname{1},sum_FCbetaM(1),...
        sum_FCbetaM(2),sum_FCbetaM(3),sum_FCbetaM(4),sum_FCbetaM(5),sum_FCbetaM(6));    
disp('==================================================================================================');
disp('                             REGRESSION: Consumption on Risk Free Rate                           ');
disp('                                                                                                 ');
disp('                                    dC = constant + psi*rf + error                               ');
disp('                                                                                                 ');
disp('                                            Annual Frequency                                    '); 
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',varname{1},sum_CFbetaA(1),...
        sum_CFbetaA(2),sum_CFbetaA(3),sum_CFbetaA(4),sum_CFbetaA(5),sum_CFbetaA(6));    
disp('=================================================================================================='); 
disp('                             REGRESSION: Risk Free Rate on Consumption                           ');
disp('                                                                                                 ');
disp('                                    rf = constant + (1/psi)*consumption + error                  ');
disp('                                                                                                 ');
disp('                                            Annual Frequency                                    '); 
disp('==================================================================================================');
disp([' Horizon                              data        5%        20%        50%        80%        95% ']);
disp('==================================================================================================');
    fprintf('%-31s %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f\n',varname{1},sum_FCbetaA(1),...
        sum_FCbetaA(2),sum_FCbetaA(3),sum_FCbetaA(4),sum_FCbetaA(5),sum_FCbetaA(6));    
disp('==================================================================================================');








