function [Rsquare] = var_predictability(YY,HH,p)

[nT, nv] = size(YY);

Y = YY;
for ii=1:nv
Y(:,ii) = YY(:,ii) - mean(YY(:,ii));
end


Spec = vgxset('n',nv,'nAR',p,'nMA',0,'nX',0);
[EstSpec EstStdErrors] = vgxvarx(Spec,Y);
%vgxdisp(EstSpec, EstStdErrors);

cons = EstSpec.a;
qq   = EstSpec.Q;
SIG  = zeros(nv*p,nv*p);
SIG(1:nv,1:nv) = qq;

PHI = [];
for ii=1:p
    PHI = [PHI EstSpec.AR{ii,1}];
end
PHI = [PHI; [eye(nv*(p-1)) zeros(nv*(p-1),nv)]]; 

mdim = size(PHI,1);

% unconditional variance
V0 = reshape(inv(eye(mdim^2)-kron(PHI,PHI))*reshape(SIG,mdim^2,1),mdim,mdim);

Rsquare = zeros(HH,nv);
pick    = zeros(nv,mdim); pick(:,1:nv) = eye(nv);

for kk=1:HH
    
    index = linspace(kk,1,kk);
    nI    = length(index);
    temp  = zeros(mdim,mdim); 
    tempP = zeros(mdim,mdim); 
    tempW = zeros(mdim,mdim);
    
    for ii=1:nI
        temp  = temp + index(ii)*PHI^(kk-index(ii))*V0;
        tempP = tempP + index(ii)*V0*(PHI^(kk-index(ii)))';
        tempW = tempW + inv(eye(mdim)-PHI)*(eye(mdim)-PHI^ii)*SIG*(eye(mdim)-PHI^ii)'*inv(eye(mdim)-PHI)';        
    end
    
    VK = temp + tempP - index(1)*V0;
    WK = tempW;    
    
    for gg = 1:nv
        Rsquare(kk,gg) = 1-(pick(gg,:)*WK*pick(gg,:)')/(pick(gg,:)*VK*pick(gg,:)');
    end       
end
        


