function [beta] = cochrane(RM,PDdata2,RD,rho)


r  = RM;
dp = -PDdata2;
dd = RD;

% Long horizon VAR

r15y = r(1:end-14);
dd15y = dd(1:end-14);
for j = 1:14; 
    r15y = r15y+(rho^j)*r(1+j:end-14+j); 
    dd15y = dd15y+(rho^j)*dd(1+j:end-14+j);
end; 
r15y = [ones(14,1)*NaN; r15y];
dd15y = [ones(14,1)*NaN; dd15y];

lhv = [r15y(16:end) dd15y(16:end) dp(16:end)*rho^15];
T = size(lhv,1);
rhv = [ones(T,1) dp(1:end-15)];
[bv,sebv,R2v,R2vadj,v,F] = olsgmm(lhv,rhv,15,0);

% disp('Long-horizon return regression coefficients');
% fprintf('             %6s %6s %6s \n','r','dd','dp');
% fprintf('Direct k=15  %6.2f %6.2f %6.2f \n',bv(2,:));

beta = zeros(3,3);
beta(1,:) = [bv(2,1) -bv(2,2) bv(2,3)];


lhv = [r(2:end) dd(2:end) dp(2:end)];
T = size(lhv,1);
rhv = [ones(T,1) dp(1:end-1)];
[bv,sebv,R2v,R2vadj,v,F] = olsgmm(lhv,rhv,0,0);
err = lhv - rhv*bv;
sbx = std(rhv*bv);
R2jc = sbx./mean(lhv);
A = [zeros(3,2) bv(2,:)'];

br = bv(2,1);
bd = bv(2,2);
phi = bv(2,3);
br15 = br*(1-(rho*phi)^15)/(1-rho*phi);
bd15 = bd*(1-(rho*phi)^15)/(1-rho*phi);
bdp15 = (rho*phi)^15;
brl = br/(1-rho*phi);
bdl = bd/(1-rho*phi);

% fprintf('VAR k=15     %6.2f %6.2f %6.2f \n',br15,bd15,bdp15);
% fprintf('VAR k=infty  %6.2f %6.2f %6.2f \n',brl,bdl,0);

beta(2,:) = [br15 -bd15 bdp15];
beta(3,:) = [brl  -bdl  0];


YY = [r dd dp];

% 
% %% variance decomposition
% 
% ygrid = 1:1:50;
% nY = length(ygrid);
% store = zeros(nY,3);
% for ii=1:nY
% store(ii,:)  = var_decompose(YY,ygrid(ii),rho);
% end




