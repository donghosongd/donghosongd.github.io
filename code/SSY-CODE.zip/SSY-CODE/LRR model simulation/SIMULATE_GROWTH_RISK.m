clc;clear;tic;

ssy = path;
path('Data',path);
path('Main Files',path);
path('SSY Solution x only',path);

load SSY2016data.mat

%% setting
mT   = 672; % number of monthly consumption data 1959-2014
AT   = 85;  % number of annual obs. 1930-2014
nsim = 400;
nT   = 1032+12;
WW   = 10;

%% load parameters
para = [1.5057
        9.9728
        0.9875
        3.3180
        0.2029
        4.9099
        0.0032
        1.4387
        0.0010
        0.0030
        0.9696
        0.0004
       -0.0436
        0.9898
        0.0110
        0.9961
        0.0040
        0.9542
        0.0461];

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);

% solution from the LRR model
[A0,A1,A0M,A1M,A0F,A1F,k1,k0,k1m,k0m] = LRR_solution(para);

agg_coeff = ([[1:1:12] 12-[1:1:11]]/12);

% store variables
hx_vec = zeros(nsim,nT);
hc_vec = zeros(nsim,nT);
hd_vec = zeros(nsim,nT);
mevec= zeros(nsim,nT);
xvec = zeros(nsim,nT); xlvec = zeros(nsim,nT); rxvec = zeros(nsim,nT);
nvec = zeros(nsim,nT);
uvec = zeros(nsim,nT);
cvec = zeros(nsim,nT); Cvec = zeros(nsim,nT/12-1);
dvec = zeros(nsim,nT); Dvec = zeros(nsim,nT/12-1); Edvec = zeros(nsim,nT/12-1);
rvec = zeros(nsim,nT); Rvec = zeros(nsim,nT/12-1); RXvec = zeros(nsim,nT/12-1);
fvec = zeros(nsim,nT); Fvec = zeros(nsim,nT/12-1);
pvec = zeros(nsim,nT); Pvec = zeros(nsim,nT/12-1);
B_C  = zeros(nsim,WW); B_R  = zeros(nsim,WW);
R2_C = zeros(nsim,WW); R2_R = zeros(nsim,WW);
R2_CT= zeros(nsim,WW); R2_RT= zeros(nsim,WW);
C_CR = zeros(nsim,WW); C_DR = zeros(nsim,WW); 
C_CX = zeros(nsim,WW); C_DX = zeros(nsim,WW); 
AUTO = zeros(nsim,5);
CORR = zeros(nsim,2);
COV_PC  = zeros(nsim,WW); COV_PX  = zeros(nsim,WW);
COV_PCT = zeros(nsim,WW); COV_PXT = zeros(nsim,WW);
pR2_C   = zeros(nsim,WW); pR2_R   = zeros(nsim,WW);
pR2_CT  = zeros(nsim,WW); pR2_RT  = zeros(nsim,WW);
VAR_P   = zeros(nsim,WW); VAR_C   = zeros(nsim,WW); VAR_X  = zeros(nsim,WW);
VAR_PT  = zeros(nsim,WW); VAR_CT  = zeros(nsim,WW); VAR_XT = zeros(nsim,WW);

CR2VAR_data_3var  = zeros(1,WW);
CR2VAR_model_3var = zeros(nsim,WW);
CR2VAR_data_4var  = zeros(1,WW);
CR2VAR_model_4var = zeros(nsim,WW);
XR2VAR_data_4var  = zeros(1,WW);
XR2VAR_model_4var = zeros(nsim,WW);
DR2VAR_data_2var  = zeros(1,WW);
DR2VAR_data_3var  = zeros(1,WW);
DR2VAR_data_4var  = zeros(1,WW);
DR2VAR_data_5var  = zeros(1,WW);
DR2VAR_model_2var = zeros(nsim,WW);
DR2VAR_model_3var = zeros(nsim,WW);
DR2VAR_model_4var = zeros(nsim,WW);
DR2VAR_model_5var = zeros(nsim,WW);

CXcrcorr_vec = zeros(nsim,7);
CDcrcorr_vec = zeros(nsim,7);
CFcrcorr_vec = zeros(nsim,7);
CMcrcorr_vec = zeros(nsim,7);

CXcrcorr_data = zeros(1,7);
CDcrcorr_data = zeros(1,7);
CFcrcorr_data = zeros(1,7);
CMcrcorr_data = zeros(1,7);

ConFvec_mf = zeros(nsim,1);
FonCvec_mf = zeros(nsim,1);

ConFvec_af = zeros(nsim,1);
FonCvec_af = zeros(nsim,1);

pdbeta_vec = zeros(nsim,5);
rfbeta_vec = zeros(nsim,4);


%% simulation
counter = 0;

disp('                                                         ');
disp('    GENERATE/SIMULATE DATA                               ');
disp('                                                         ');

for jj=1:nsim
        % report 
        if mod(jj,200)==0        
        disp('                                                         ');
        disp(['  POSTERIOR DRAWS:   ',     num2str(jj)]                 );
        disp('                                                         ');
        disp(['  REMAINING DRAWS:   ',     num2str(nsim-jj)]            );
        disp('                                                         ');  
        disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
        disp('                                                         ');
        end
         
     for tt=1:nT
        
       %% initialization
        if tt==1    
            xvec(jj,tt)   = mvnrnd(0,(xie*sigma)^2/(1-rho^2));
            nvec(jj,tt)   = mvnrnd(0,sigma^2);
            uvec(jj,tt)   = mvnrnd(0,xid^2*sigma^2);
                      
            cvec(jj,tt) = muc + nvec(jj,tt);
            dvec(jj,tt) = mud + uvec(jj,tt);
            fvec(jj,tt) = A0F + A1F*xvec(jj,tt) + mvnrnd(0,5e-4^2);
            pvec(jj,tt) = A0M + A1M*xvec(jj,tt) ;
            rvec(jj,tt) = k0m + k1m*pvec(jj,tt) - A0M + dvec(jj,tt);
            Edvec(jj,tt) = exp(dvec(jj,tt));
       
       %% periods greater than 1 
        else   
            xvec(jj,tt)   = rho  *xvec(jj,tt-1)   + mvnrnd(0,(xie*sigma)^2);
            hd_vec(jj,tt) = rhohD*hd_vec(jj,tt-1) + mvnrnd(0,sighD^2,1);
            nvec(jj,tt)   = mvnrnd(0,(sigma)^2);
            uvec(jj,tt)   = mvnrnd(0,(xid*sigma)^2);
            
            %% simulate macro-financial data
            cvec(jj,tt) = muc + xvec(jj,tt-1) + nvec(jj,tt);
            dvec(jj,tt) = mud + phi*xvec(jj,tt-1) + uvec(jj,tt);
            fvec(jj,tt) = A0F + A1F*xvec(jj,tt) + mvnrnd(0,5e-4^2);
            pvec(jj,tt) = A0M + A1M*xvec(jj,tt) ;
            rvec(jj,tt) = k0m + k1m*pvec(jj,tt) - pvec(jj,tt-1) + dvec(jj,tt);
            Edvec(jj,tt) = exp(dvec(jj,tt))*Edvec(jj,tt-1);
        end
     end
     
    %% aggregate to annual frequency
    for t=2:nT/12
        Cvec(jj,t-1) = cvec(jj,12*(t-2)+2:12*t)*agg_coeff';     
        Rvec(jj,t-1) = sum(rvec(jj,12*(t-1)+1:12*t));
        Dvec(jj,t-1) = dvec(jj,12*(t-2)+2:12*t)*agg_coeff';
        Fvec(jj,t-1) = 12*(fvec(jj,12*t));
        Pvec(jj,t-1) = pvec(jj,12*t) + log(Edvec(jj,12*t)) - log(sum(Edvec(jj,12*(t-1)+1:12*t)));
        RXvec(jj,t-1) = sum(rxvec(jj,12*(t-1)+1:12*t));
    end

    slope_ConF_mf =  regress(cvec(jj,end-mT+1:end)', [ones(mT,1) fvec(jj,end-mT+1:end)']);
    slope_FonC_mf =  regress(fvec(jj,end-mT+1:end)', [ones(mT,1) cvec(jj,end-mT+1:end)']);

    ConFvec_mf(jj,:) = slope_ConF_mf(2);
    FonCvec_mf(jj,:) = 1/slope_FonC_mf(2);

    instrument = [cvec(jj,end-mT+1:end)' rvec(jj,end-mT+1:end)' fvec(jj,end-mT+1:end)' pvec(jj,end-mT+1:end)'];
    lag = 2;
    instrument = instrument(1:end-lag,:); 
    cT = size(instrument,1);
    zZ = [ones(cT,1) instrument];
    yY = cvec(jj,end-mT+1+lag:end)';
    xX = fvec(jj,end-mT+1+lag:end)';        
    xxhat = [ones(cT,1) zZ*(zZ\xX)];
    ols   = xxhat\yY;         
    ConFvec_af(jj,:) = ols(2);

    xX = cvec(jj,end-mT+1+lag:end)';
    yY = fvec(jj,end-mT+1+lag:end)';        
    xxhat = [ones(cT,1) zZ*(zZ\xX)];
    ols   = xxhat\yY;         
    FonCvec_af(jj,:) = 1/ols(2);
        
end

PREDICTIVE_CHECKS




path=ssy;
























