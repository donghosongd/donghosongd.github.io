function [diff, k0m, k1m] = zm_bar(x,para,A0,A1,k0,k1)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));


PHI  = diag([rho rhoL]);
SIG  = diag([sigma xid*sigma]).^2;
SIGx = diag([xie*sigma sigL]).^2;
  
e1 = [1 0];
e2 = [0 1];

% theta
theta = (1-gamma)/(1-1/psi);

% log-linearize coefficients
k1m = exp(x)/(1+exp(x));
k0m = log(1+exp(x))-k1m*x;

% A coefficients
A1M = ((phi-1/psi)*e1 + e2*PHI)*inv(eye(2)-k1m*PHI);

temp0 = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 ) -gamma*muc + k0m + mud;

temp1 = gamma^2/2*sigma^2 + 0.5*(xid*sigma)^2 + 0.5*( (theta-1)*k1*A1+k1m*A1M+theta*e2 )*SIGx*( (theta-1)*k1*A1+k1m*A1M+theta*e2 )';

A0M = ( temp0 + temp1 )/(1-k1m);

diff = x - A0M;                        