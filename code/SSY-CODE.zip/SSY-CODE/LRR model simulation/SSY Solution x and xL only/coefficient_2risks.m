function [DD,ZZ,PHIF,SIG,RR] = coefficient_2risks(para)

rho   = para(4);
phi   = para(5);
xie   = para(6);
xid   = para(7);
sigma = para(8);
muc   = para(9);
mud   = para(10);
rhoL  = para(13);
sigL  = para(14);

[A0,A1,A0M,A1M,A0F,A1F,k1,k0,k1m,k0m] = LRR_solution(para);

DD = [muc;mud;mud+k0m+(k1m-1)*A0M;A0F];

ZZ = [0            0          1           0;
      0            0          phi         0;
      k1m*A1M(1) k1m*A1M(2) phi-A1M(1)  -A1M(2);
      0            0          A1F(1)     A1F(2)];
RR = diag([sigma xid*sigma xid*sigma 0.0005]).^2;

PHIF = zeros(4,4); PHIF(1:2,1:2) = diag([rho rhoL]);
PHIF(3:4,1:2) = eye(2);

SIG = zeros(4,4); SIG(1:2,1:2) = diag([xie*sigma sigL]).^2;













