clc;
scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',35)
set(0,'DefaultTextFontSize',35);

fig = figure('Position',[20,20,900,600],'Name','Univariate Consumption Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(R2_C)
scatter([1:1:10],R2_CT(end,:),135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
ylabel('$$R^{2}$$','Interpreter','latex')
axis([0.5 10.5 0 80])


fig = figure('Position',[20,20,900,600],'Name','Univariate Excess Return Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(R2_R)
scatter([1:1:10],R2_RT(end,:),135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
ylabel('$$R^{2}$$','Interpreter','latex')
axis([0.5 10.5 0 80])


fig = figure('Position',[20,20,900,600],'Name','Univariate Dividend Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(R2_D)
scatter([1:1:10],R2_DT(end,:),150,'rs','filled')
xlabel('Horizon')
ylabel('$$R^{2}$$')
axis([0.5 10.5 0 80])


fig = figure('Position',[20,20,900,600],'Name','VAR Consumption Growth Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(100*CR2VAR_model_4var)
scatter([1:1:10],CR2VAR_data_4var,135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
ylabel('$$R^{2}$$','Interpreter','latex')
axis([0.5 10.5 0 80])

fig = figure('Position',[20,20,900,600],'Name','VAR Excess Return Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(100*XR2VAR_model_4var)
scatter([1:1:10],XR2VAR_data_4var,135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
ylabel('$$R^{2}$$','Interpreter','latex')
axis([0.5 10.5 0 80])

fig = figure('Position',[20,20,900,600],'Name','VAR Dividend Predictability','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(100*DR2VAR_model_4var)
scatter([1:1:10],DR2VAR_data_4var,150,'rs','filled')
xlabel('Horizon')
ylabel('$$R^{2}$$')
axis([0.5 10.5 0 80])

fig = figure('Position',[20,20,900,600],'Name','Consumption Return Correlation','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(C_CR)
scatter([1:1:10],CB_ZCM(:,2)',135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
axis([0.5 10.5 -0.35 1.01])


fig = figure('Position',[20,20,900,600],'Name','Dividend Return Correlation','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
boxPlot(C_DR)
scatter([1:1:10],CB_ZDM(:,2)',135,'rs','filled')
xlabel('Horizon','Interpreter','latex')
axis([0.5 10.5 -0.35 1.01])







