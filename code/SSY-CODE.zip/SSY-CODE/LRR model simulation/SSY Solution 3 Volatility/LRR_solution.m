function [A0,A1,A2X,A2C,A2D,A0M,A1M,A2XM,A2CM,A2DM,A0F,A1F,A2XF,A2CF,A2DF,k1,k0,k1m,k0m] = LRR_solution(para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;
PHI_c   = [sigbarX;sigbar;sigbarD];
PHI_v   = diag([nuX nu nuD]);
PHI_w   = diag([sigwX sigw sigwD]);

e1 = [1 0 0];
e2 = [0 1 0];
eD = [0 dpi 1]; 
  
% theta
theta = (1-gamma)/(1-1/psi);

% specification
options = optimset('MaxIter', 1e20, 'MaxFunEvals', 1e20, 'TolFun',1e-20, 'Display', 'off');

%% solve for the mean of log(P/C) or z(t)
zcfcn   = @(x) z_bar(x,para);
zc0     = 6.5;
[zmean] = fsolve(zcfcn,zc0,options);
k1 = exp(zmean)/(1+exp(zmean));
if k1>0.9999
    k1=0.9999;
end
k0 = log(1+exp(zmean))-k1*zmean;

%% Z(t) = A0 + A1*x(t) + A2C*sig(t)^2 + A2X*sigx(t)^2
A1   = (1-1/psi)/(1-k1*rho);

A2   = theta/2*(k1*A1*e1 + (1-1/psi)*e2).^2*inv(eye(3)-k1*PHI_v);

A2X  = A2(1);
A2C  = A2(2);
A2D  = A2(3);

temp0 = log(delta) + k0 + (1-1/psi)*muc + k1*reshape(A2,1,[])*PHI_c;

temp1 = (k1*reshape(A2,1,[])*PHI_w)*(k1*reshape(A2,1,[])*PHI_w)';

A0 = ( temp0 + theta/2*temp1 )/(1-k1);


%% solve for the mean of log(P/D) or zm(t)
zmfcn   = @(x) zm_bar(x,para,A0,A1,A2,k0,k1);
zm0     = 6.5;
[zmean] = fsolve(zmfcn,zm0,options);
k1m = exp(zmean)/(1+exp(zmean));
if k1m>0.9999
    k1m=0.9999;
end
k0m = log(1+exp(zmean))-k1m*zmean;


A1M   = (phi-1/psi)/(1-k1m*rho);

A2M   = ((theta-1)*reshape(A2,1,[])*(k1*PHI_v-eye(3)) + 0.5*(  ((theta-1)*k1*A1+ k1m*A1M)*e1 + (eD-gamma*e2)).^2 )*inv(eye(3)-k1m*PHI_v);

A2XM  = A2M(1);
A2CM  = A2M(2);
A2DM  = A2M(3);

temp0 = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 + k1*reshape(A2,1,[])*PHI_c)-gamma*muc + k0m + mud + k1m*reshape(A2M,1,[])*PHI_c;

temp1 = ((theta-1)*k1*reshape(A2,1,[]) + k1m*reshape(A2M,1,[]) )*PHI_w;

A0M = ( temp0 + 1/2*(temp1*temp1') )/(1-k1m);


%% risk free rate

A0F = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 + k1*reshape(A2,1,[])*PHI_c)-gamma*muc + ...
      0.5*((theta-1)*k1*reshape(A2,1,[])*PHI_w)*((theta-1)*k1*reshape(A2,1,[])*PHI_w)';
A0F = -A0F;
A1F = 1/psi;
A2F = (theta-1)*reshape(A2,1,[])*(k1*PHI_v-eye(3))+0.5*((theta-1)*k1*reshape(A1,1,[])*e1-gamma*e2).^2;

A2F = -A2F;
A2XF = A2F(1);
A2CF = A2F(2);
A2DF = A2F(3);














