betaolssim    = zeros(nsim,3);
betavarsim    = zeros(nsim,3);
betavarINFsim = zeros(nsim,3);

for jj=1:nsim
    % report 
    if mod(jj,500)==0      
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(jj)]                 );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-jj)]            );
    disp('                                                         ');  
    disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
    disp('                                                         ');
    end
    
   RM_ = reshape(Rvec(jj,:),[],1);
   RD_ = reshape(Dvec(jj,:),[],1);
   PD_ = reshape(Pvec(jj,:),[],1);
    
   [beta] = cochrane(RM_,PD_,RD_,0.96);
   betaolssim(jj,:)  = beta(1,:);
   betavarsim(jj,:)  = beta(2,:);
   betavarINFsim(jj,:)  = beta(3,:);
   
end


[a1, b1, c1, d1, e1]=moment2(betaolssim);
[a2, b2, c2, d2, e2]=moment2(betavarsim);
[a3, b3, c3, d3, e3]=moment2(betavarINFsim);

[e1';e2';e3']
[c1;c2;c3]
[a1';a2';a3']
[beta] = cochrane(RM,PDdata2,RD,0.96);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',35)
set(0,'DefaultTextFontSize',25);


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/2 scrsz(4)/1.3]);  
hold on
boxPlot(betaolssim)
scatter([1:1:3],beta(1,:),150,'rs','filled')
plot([0:1:4],ones(1,5),'k--')
plot([0:1:4],0*ones(1,5),'k--')
axis([0.5 3.5 -0.5 1.5])
set(gca,'Xtick',1:3,'XTickLabel',{'R', 'D', 'DP'})    

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/2 scrsz(4)/1.3]);  
hold on
boxPlot(betavarsim)
scatter([1:1:3],beta(2,:),150,'rs','filled')
plot([0:1:4],ones(1,5),'k--')
plot([0:1:4],0*ones(1,5),'k--')
axis([0.5 3.5 -0.5 1.5])
set(gca,'Xtick',1:3,'XTickLabel',{'R', 'D', 'DP'})    


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/2 scrsz(4)/1.3]);  
hold on
boxPlot(betavarINFsim)
scatter([1:1:3],beta(3,:),150,'rs','filled')
plot([0:1:4],ones(1,5),'k--')
plot([0:1:4],0*ones(1,5),'k--')
axis([0.5 3.5 -0.5 1.5])
set(gca,'Xtick',1:3,'XTickLabel',{'R', 'D', 'DP'})    

