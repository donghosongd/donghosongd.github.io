function [A0,A1,A0M,A1M,A0F,A1F,k1,k0,k1m,k0m] = LRR_solution(para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

PHI_c   = [sigbar;sigbarD];
PHI_v   = diag([nu nuD]);
PHI_w   = diag([sigw sigwD]);

 
% theta
theta = (1-gamma)/(1-1/psi);

% specification
options = optimset('MaxIter', 1e20, 'MaxFunEvals', 1e20, 'TolFun',1e-20, 'Display', 'off');

%% solve for the mean of log(P/C) or z(t)
zcfcn   = @(x) z_bar(x,para);
zc0     = 6.5;
[zmean] = fsolve(zcfcn,zc0,options);
k1 = exp(zmean)/(1+exp(zmean));
if k1>0.9999
    k1=0.9999;
end
k0 = log(1+exp(zmean))-k1*zmean;

%% Z(t) = A0 + A1*x(t) 
A1 = rhoL/(1-k1*rhoL);

A0 = (log(delta) + k0 + (1-1/psi)*muc + theta/2*( (1-1/psi)^2*sigma^2 + (1+k1*A1)^2*sigL^2 ))/(1-k1);

%% solve for the mean of log(P/D) or zm(t)
zmfcn   = @(x) zm_bar(x,para,A0,A1,k0,k1);
zm0     = 6.5;
[zmean] = fsolve(zmfcn,zm0,options);
k1m = exp(zmean)/(1+exp(zmean));
if k1m>0.9999
    k1m=0.9999;
end
k0m = log(1+exp(zmean))-k1m*zmean;


A1M   = rhoL/(1-k1*rhoL);

temp0 = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 ) -gamma*muc + k0m + mud;

temp1 = gamma^2/2*sigma^2 + 0.5*(xid*sigma)^2 + 0.5*(theta + (theta-1)*k1*A1+k1m*A1M )^2*(sigL)^2;

A0M = ( temp0 + temp1 )/(1-k1m);


%% risk free rate

A0F = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 ) -gamma*muc + 0.5*(theta+(theta-1)*k1*A1)^2*(sigL)^2 + gamma^2/2*sigma^2;
A0F = -A0F;
A1F = -rhoL;














