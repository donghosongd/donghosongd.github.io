clc;clear;tic;

ssy = path;
path('Data',path);
path('Main Files',path);
path('SSY Solution Benchmark',path);

load SSY2016data.mat
%% setting
nt   = 85;  % number of annual obs. 1930-2014
WW   = 10; 

% STORE
R2_CONSUMPTION  = zeros(WW,3);
R2_DIVIDEND     = zeros(WW,3);
R2_EXCESSRTRN   = zeros(WW,3);

for ww=1:WW       
    YYA = zeros(nt-ww,1);
    YYB = zeros(nt-ww,1); 
    YYC = zeros(nt-ww,1);

    for tt=1:nt-ww
        YYA(tt)  = sum(GD(tt+1:tt+ww));
        YYB(tt)  = sum(RM(tt+1:tt+ww))-sum(RF(tt+1:tt+ww));      
        YYC(tt)  = sum(RD(tt+1:tt+ww));
    end 
    ntt = size(YYA,1);

    XXA  = [ones(ntt,1) PDdata2(1:ntt)];
    XXB  = [ones(ntt,1) GD(1:ntt) PDdata2(1:ntt) RF(1:ntt)];
    XXC  = [ones(ntt,1) GD(1:ntt) PDdata2(1:ntt) RM(1:ntt) RF(1:ntt)];

    [bA1,bintA1,rA1,rintA1,statsA1] = regress(YYA,XXA);
    [bA2,bintA2,rA2,rintA2,statsA2] = regress(YYA,XXB);
    [bA3,bintA3,rA3,rintA3,statsA3] = regress(YYA,XXC);
    
    [bB1,bintB1,rB1,rintB1,statsB1] = regress(YYB,XXA);
    [bB2,bintB2,rB2,rintB2,statsB2] = regress(YYB,XXB);
    [bB3,bintB3,rB3,rintB3,statsB3] = regress(YYB,XXC);
    
    [bC1,bintC1,rC1,rintC1,statsC1] = regress(YYC,XXA);
    [bC2,bintC2,rC2,rintC2,statsC2] = regress(YYC,XXB);
    [bC3,bintC3,rC3,rintC3,statsC3] = regress(YYC,XXC);
    
    R2_CONSUMPTION(ww,1) = statsA1(1)*100;
    R2_CONSUMPTION(ww,2) = statsA2(1)*100;
    R2_CONSUMPTION(ww,3) = statsA3(1)*100;
    
    R2_DIVIDEND(ww,1)    = statsC1(1)*100;
    R2_DIVIDEND(ww,2)    = statsC2(1)*100;
    R2_DIVIDEND(ww,3)    = statsC3(1)*100;
    
    R2_EXCESSRTRN(ww,1)  = statsB1(1)*100;
    R2_EXCESSRTRN(ww,2)  = statsB2(1)*100;
    R2_EXCESSRTRN(ww,3)  = statsB3(1)*100;
end

VAR2R2_CONSUMPTION = 100*var_predictability([GD(1:nt) PDdata2(1:nt)],WW,1) ; 
VAR3R2_CONSUMPTION = 100*var_predictability([GD(1:nt) PDdata2(1:nt) RF(1:nt)],WW,1) ; 
VAR4R2_CONSUMPTION = 100*var_predictability([GD(1:nt) RM(1:nt)-RF(1:nt) PDdata2(1:nt) RD(1:nt)],WW,1) ; 


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

fig = figure('Position',[20,20,900,600],'Name','','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/3 scrsz(4)/2]);  
hold on
k1=plot(R2_CONSUMPTION(:,1),'Color',[0.1 0.1 0.1],'linewidth',2,'marker','s','markersize',6,'MarkerFaceColor',[0.1 0.1 0.1],'MarkerEdgeColor',[0.1 0.1 0.1]);
k2=plot(VAR2R2_CONSUMPTION(:,1),'Color',[0.6 0.6 0.6],'linewidth',2,'marker','o','markersize',8,'MarkerFaceColor',[0.9 0.9 0.9],'MarkerEdgeColor',[0.6 0.6 0.6]);
kk = legend([k1,k2],'univariate, in-sample $$R^2$$','VAR(1), population $$R^2$$');
set(kk,'interpreter','latex','location','northeast');
legend('boxoff');
set(gca,'Xtick',1:10,'XTickLabel',{'','2y','','4y','','6y','','8y','','10y'})
axis tight  
ylabel('$$R^2$$ (percent)')
ylim([0 60])  
title('$$\Delta c,pd$$');

fig = figure('Position',[20,20,900,600],'Name','','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/3 scrsz(4)/2]);  
hold on
k1=plot(R2_CONSUMPTION(:,2),'Color',[0.1 0.1 0.1],'linewidth',2,'marker','s','markersize',6,'MarkerFaceColor',[0.1 0.1 0.1],'MarkerEdgeColor',[0.1 0.1 0.1]);
k2=plot(VAR3R2_CONSUMPTION(:,1),'Color',[0.6 0.6 0.6],'linewidth',2,'marker','o','markersize',8,'MarkerFaceColor',[0.9 0.9 0.9],'MarkerEdgeColor',[0.6 0.6 0.6]);
kk = legend([k1,k2],'direct regression, in-sample $$R^2$$','VAR(1), population $$R^2$$');
set(kk,'interpreter','latex','location','northeast');
legend('boxoff');
set(gca,'Xtick',1:10,'XTickLabel',{'','2y','','4y','','6y','','8y','','10y'})
axis tight  
ylabel('$$R^2$$ (percent)')
ylim([0 60]) 
title('$$\Delta c,pd,r_f$$');


fig = figure('Position',[20,20,900,600],'Name','','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/3 scrsz(4)/2]);  
hold on
k1=plot(R2_CONSUMPTION(:,3),'Color',[0.1 0.1 0.1],'linewidth',2,'marker','s','markersize',6,'MarkerFaceColor',[0.1 0.1 0.1],'MarkerEdgeColor',[0.1 0.1 0.1]);
k2=plot(VAR4R2_CONSUMPTION(:,1),'Color',[0.6 0.6 0.6],'linewidth',2,'marker','o','markersize',8,'MarkerFaceColor',[0.9 0.9 0.9],'MarkerEdgeColor',[0.6 0.6 0.6]);
kk = legend([k1,k2],'direct regression, in-sample $$R^2$$','VAR(1), population $$R^2$$');
set(kk,'interpreter','latex','location','northeast');
legend('boxoff');
set(gca,'Xtick',1:10,'XTickLabel',{'','2y','','4y','','6y','','8y','','10y'})
axis tight  
ylabel('$$R^2$$ (percent)')
ylim([0 60])
title('$$\Delta c,pd,r_m,r_f$$');