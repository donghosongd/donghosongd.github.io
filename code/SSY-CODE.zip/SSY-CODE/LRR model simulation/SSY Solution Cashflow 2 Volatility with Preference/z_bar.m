function [diff, k0, k1] = z_bar(x,para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);


% log-linearize coefficients
k1 = exp(x)/(1+exp(x));
k0 = log(1+exp(x))-k1*x;

% A coefficients
A1   = (1-1/psi)/(1-k1*rho);
A1L  = rhoL/(1-k1*rhoL);

A2C  = 0.5*theta*( (k1*A1*xie)^2 + (1-1/psi)^2 )/ (1-k1*nu);
A2D  = 0;

temp = log(delta) + k0 + (1-1/psi)*muc + k1*A2C*sigbar + 0.5*theta*(k1*A1L+1)^2*sigL^2 + 0.5*theta*(k1*A2C*sigw)^2;
A0   = temp/(1-k1);
                            
diff = x - A0  - A2C*(sigma^2)  - A2D*(xid*sigma)^2;
