function [A0,A1,A1L,A2C,A2D,A0M,A1M,A1LM,A2CM,A2DM,A0F,A1F,A1LF,A2CF,A2DF,k1,k0,k1m,k0m] = LRR_solution(para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0011;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);

% specification
options = optimset('MaxIter', 1e20, 'MaxFunEvals', 1e20, 'TolFun',1e-20, 'Display', 'off');

%% solve for the mean of log(P/C) or z(t)
zcfcn   = @(x) z_bar(x,para);
zc0     = 6.5;
[zmean] = fsolve(zcfcn,zc0,options);
k1 = exp(zmean)/(1+exp(zmean));
if k1>0.9999
    k1=0.9999;
end
k0 = log(1+exp(zmean))-k1*zmean;

%% Z(t) = A0 + A1*x(t) + A2C*sig(t)^2 + A2X*sigx(t)^2
A1   = (1-1/psi)/(1-k1*rho);
A1L  = rhoL/(1-k1*rhoL);

A2C  = 0.5*theta*( (k1*A1*xie)^2 + (1-1/psi)^2 )/ (1-k1*nu);
A2D  = 0;

temp = log(delta) + k0 + (1-1/psi)*muc + k1*A2C*sigbar + 0.5*theta*(k1*A1L+1)^2*sigL^2 + 0.5*theta*(k1*A2C*sigw)^2;
A0   = temp/(1-k1);

%% solve for the mean of log(P/D) or zm(t)
zmfcn   = @(x) zm_bar(x,para,A0,A1,A1L,A2C,k0,k1);
zm0     = 6.5;
[zmean] = fsolve(zmfcn,zm0,options);
k1m = exp(zmean)/(1+exp(zmean));
if k1m>0.9999
    k1m=0.9999;
end
k0m = log(1+exp(zmean))-k1m*zmean;

A1M   = (phi-1/psi)/(1-k1m*rho);
A1LM  = rhoL/(1-k1m*rhoL);

A2CM  = ( (theta-1)*A2C*(k1*nu-1) + 0.5*( (theta-1)*k1*A1 + k1m*A1M )^2*xie^2 + 0.5*(dpi-gamma)^2 )/(1-k1m*nu);
A2DM  = 0.5/(1-k1m*nuD);

temp0 = theta*log(delta) + (theta-1)*(k0 + (k1-1)*A0 + k1*A2C*sigbar) -gamma*muc + k0m + mud + k1m*A2CM*sigbar + k1m*A2DM*sigbarD; 

temp1 = 0.5*((theta-1)*k1*A1L + k1m*A1LM + theta)^2*sigL^2 + 0.5*( k1m*A2CM + (theta-1)*k1*A2C )^2*sigw^2 + 0.5*(k1m*A2DM*sigwD)^2;

A0M = ( temp0 + temp1 )/(1-k1m);

%% risk free rate

A0F = -theta*log(delta) - (theta-1)*(k0 + (k1-1)*A0 + k1*A2C*sigbar) + gamma*muc + ...
      - 0.5*( (theta-1)*k1*A1L+theta)^2*sigL^2 - 0.5*(theta-1)^2*(k1*A2C*sigw)^2;
A1F = 1/psi;
A1LF = -rhoL;
A2CF = -(theta-1)*A2C*(k1*nu-1) - 0.5*(theta-1)^2*(k1*A1*xie)^2 - 0.5*gamma^2;
A2DF = 0;













