
scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',35)
set(0,'DefaultTextFontSize',35);

pick = [1 3 5 10];
select = repmat([zeros(9,1);1],nsim/10,1);

ii = 1;
fig = figure('Position',[20,20,900,600],'Name','UNIV:1-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(R2_C(select==1,pick(ii)),R2_R(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([R2_CT(1,pick(ii)),R2_CT(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[R2_RT(1,pick(ii)),R2_RT(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  

ii = 2;
fig = figure('Position',[20,20,900,600],'Name','UNIV:3-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(R2_C(select==1,pick(ii)),R2_R(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([R2_CT(1,pick(ii)),R2_CT(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[R2_RT(1,pick(ii)),R2_RT(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  


ii = 3;
fig = figure('Position',[20,20,900,600],'Name','UNIV:5-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(R2_C(select==1,pick(ii)),R2_R(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([R2_CT(1,pick(ii)),R2_CT(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[R2_RT(1,pick(ii)),R2_RT(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  


ii = 4;
fig = figure('Position',[20,20,900,600],'Name','UNIV:10-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(R2_C(select==1,pick(ii)),R2_R(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([R2_CT(1,pick(ii)),R2_CT(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[R2_RT(1,pick(ii)),R2_RT(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  


ii = 1;
fig = figure('Position',[20,20,900,600],'Name','VAR:1-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(100*CR2VAR_model_4var(select==1,pick(ii)),100*XR2VAR_model_4var(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([CR2VAR_data_4var(1,pick(ii)),CR2VAR_data_4var(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[XR2VAR_data_4var(1,pick(ii)),XR2VAR_data_4var(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  


ii = 2;
fig = figure('Position',[20,20,900,600],'Name','VAR:3-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(100*CR2VAR_model_4var(select==1,pick(ii)),100*XR2VAR_model_4var(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([CR2VAR_data_4var(1,pick(ii)),CR2VAR_data_4var(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[XR2VAR_data_4var(1,pick(ii)),XR2VAR_data_4var(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  


ii = 3;
fig = figure('Position',[20,20,900,600],'Name','VAR:5-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(100*CR2VAR_model_4var(select==1,pick(ii)),100*XR2VAR_model_4var(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([CR2VAR_data_4var(1,pick(ii)),CR2VAR_data_4var(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[XR2VAR_data_4var(1,pick(ii)),XR2VAR_data_4var(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  

ii = 4;
fig = figure('Position',[20,20,900,600],'Name','VAR:10-year','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.8 scrsz(4)/1.25]);  
hold on
s=scatter(100*CR2VAR_model_4var(select==1,pick(ii)),100*XR2VAR_model_4var(select==1,pick(ii)));
s.MarkerEdgeColor = [0.4 0.4 0.4];
s.MarkerFaceColor = [0.9 0.9 0.9];
line([CR2VAR_data_4var(1,pick(ii)),CR2VAR_data_4var(1,pick(ii))],[0 100],'Color',[0.9 0.2 0.1],'linewidth',3)
line([0 100],[XR2VAR_data_4var(1,pick(ii)),XR2VAR_data_4var(1,pick(ii))],'Color',[0.9 0.2 0.1],'linewidth',3)
xlabel('Consumption Growth $$R^2$$','Interpreter','latex','fontsize',35)
ylabel('Excess Returns $$R^2$$','Interpreter','latex','fontsize',35)
axis([0 80 0 80])
set(gca,'XTick',0:20:80)
set(gca,'XTickLabel',{'0','20','40','60','80'})  
set(gca,'yTick',0:20:80)
set(gca,'yTickLabel',{'0','20','40','60','80'})  








