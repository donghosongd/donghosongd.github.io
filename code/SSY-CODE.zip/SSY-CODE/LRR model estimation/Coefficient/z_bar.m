function [diff, k0, k1] = z_bar(x,para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0010;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);

% x process
PHI    = [rho  0    0   0;
           0   0    0   0;
           0   0    0   0;
           0   0    0  rhoL];

SIG    = [phiL^2*sigL^2 0 0 phiL*sigL^2;
                0       0 0     0      ;
                0       0 0     0      ;
           phiL*sigL^2  0 0     sigL^2 ];     
% v process
PHI_V0 = [sigbarX;
          sigbar;
          sigbarD ;
             0   ];
PHI_V1 = [nuX  0  0  0;
           0  nu  0  0;
           0   0 nuD 0;
           0   0  0  0];
       
SIG_V  = diag([sigwX sigw sigwD 0]).^2;

% div process
PSI = [phi  0   0    0];
GAM = [0   dpi  1    0];

mu     = [muc;mud];
e1     = [1 0 0 0];
e2     = [0 1 0 0];
e3     = [0 0 1 0];
e4     = [0 0 0 1];

% mean[z(t)] = mean[A0 + A1*x(t) + A2*sig(t)^2];
% z_bar      = A0 + A2*sigma^2;

k1 = exp(x)/(1+exp(x));
k0 = log(1+exp(x))-k1*x;

%% Z(t) = A0 + A1*X(t) + A2*SIG(t)^2 
A1  = ( (1-1/psi)*e1 + e4*PHI )/(eye(4)-k1*PHI);
A2  = 0.5*theta*(k1*A1+(1-1/psi)*e2+e4).^2/(eye(4)-k1*PHI_V1);
A0  = ( log(delta)+k0+mu(1)*(1-1/psi)+k1*A2*PHI_V0+0.5*theta*(k1*A2*SIG_V*A2'*k1)+... 
        0.5*theta*(k1*A1+(1-1/psi)*e2+e4)*SIG*(k1*A1+(1-1/psi)*e2+e4)')/(1-k1);
  
diff = x - (A0 + A2(1)*(xie*sigma)^2 + A2(2)*(sigma)^2 + A2(3)*(xid*sigma)^2);


