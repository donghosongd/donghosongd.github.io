function [DD,ZZ,PHI,SIG,ZV,RR,V0,NU,VV,SIG0] = statespace_simple(para)

%% State-Space
% Y(t) = D + Z*S(t) + Zv*Sv(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)
% Sv(t) = [exp(2h(t));exp(2h(t-1)];

% fixed parameters
delta = 0.999;
mu    = 0.0016;
mud   = 0.0010;
% estimated parameters
psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xix   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmeA= para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% coefficients for particles
NU = diag([rhohX rhoh rhohD]);
VV = diag([sighX sigh sighD]);
V0 = [(xix*sigma)^2; sigma^2; (xid*sigma)^2];

[A0,A1,A1L,A2X,A2C,A2D,A0M,A1M,A1LM,A2XM,A2CM,A2DM,A0F,A1F,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m] = solution(para);

% coefficients for market returns
mur  = k0m+A0M*(k1m-1)+mud ;
mur1 = k1m*A1M;
mur2 = phi-A1M;
mur3 = dpi;
mur4 = 1;
mur5 = k1m*A1LM;
mur6 = -A1LM;
murXp = k1m*A2XM;
murX = -A2XM;
murCp = k1m*A2CM;
murC = -A2CM;
murDp = k1m*A2DM;
murD = -A2DM;


PHI = [rho   0    0     0    0    0;
        1    0    0     0    0    0;
        0    0    0     0    0    0;
        0    0    0     0    0    0;
        0    0    0     0   rhoL  0;
        0    0    0     0    1    0];

CHOL = [xix*sigma  0    0    0    phiL*sigL   0;
           0       0    0    0        0       0;
           0       0  sigma  0        0       0;
           0       0    0  xid*sigma  0       0;
           0       0    0    0       sigL     0;
           0       0    0    0        0       0];
SIG  = CHOL*CHOL';

SIG0 = [   (phiL*sigL)^2   0    0    0    phiL*sigL^2 0;
                 0         0    0    0        0       0;
                 0         0    0    0        0       0;
                 0         0    0    0        0       0;
             phiL*sigL^2   0    0    0      sigL^2    0;
                 0         0    0    0        0       0];


%       x_{t+1}  x_{t}  eta_{c,t+1}  eta_{d,t+1}   x_{l,t+1}   x_{l,t}
ZZ = [     0      1         1          0                0        0;
           0     phi       dpi         1                0        0;
          mur1   mur2      mur3       mur4             mur5     mur6;
           0     A1F        0          0                0       A1LF];

% construct Zv: 3 VOL (t+1 and t each): 6
% order = [sigx(t)^2 sig(t)^2 sigd(t)^2] 
ZV = zeros(4,6);
ZV(3,:) = [murXp murX murCp murC murDp murD];
ZV(4,:) = [0     A2XF   0   A2CF   0     0];

% construct DD
DD = [mu mud mur A0F]';

% construct RR
RR = diag([0.0001 0.0001 0.0065 0.0005]).^2;


