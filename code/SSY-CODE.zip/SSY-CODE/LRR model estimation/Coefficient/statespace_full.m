function [D,Z,PHI,SIG,ZV,RR,D0,Z0,ZV0,R0,V0,NU,VV] = statespace_full(para,M)

%% State-Space
% Y(t) = D + Z*S(t) + Zv*Sv(t) + Q(t) , Q(t) ~ N(0,RR)
% S(t) = PHI*S(t-1) + V(t) , V(t) ~ N(0,SIG)
% Sv(t) = [exp(2h(t));exp(2h(t-1)];

% fixed parameters
delta = 0.999;
mu    = 0.0016;
mud   = 0.0010;
% estimated parameters
psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xix   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmeA= para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% coefficients for particles
NU = diag([rhohX rhoh rhohD]);
VV = diag([sighX sigh sighD]);
V0 = [(xix*sigma)^2; sigma^2; (xid*sigma)^2];

%[A0,A1,A1L,A2X,A2C,A2D,A0M,A1M,A1LM,A2XM,A2CM,A2DM,A0F,A1F,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m] = solution(para);
[A0,A1,A1L,A2X,A2C,A2D,A0M,A1M,A1LM,A2XM,A2CM,A2DM,A0F,A1F,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m] = solution_fn(para);

% coefficients for market returns
mur  = k0m+A0M*(k1m-1)+mud ;
mur1 = k1m*A1M;
mur2 = phi-A1M;
mur3 = dpi;
mur4 = 1;
mur5 = k1m*A1LM;
mur6 = -A1LM;
murXp = k1m*A2XM;
murX = -A2XM;
murCp = k1m*A2CM;
murC = -A2CM;
murDp = k1m*A2DM;
murD = -A2DM;

D   = zeros(2*M+2,1);
PHI = zeros(9*M+1,9*M+1);
Z   = zeros(2*M+2,9*M+1);
SIG = zeros(9*M+1,9*M+1);

order = [2*M 4*M-1 6*M-1 7*M 9*M-1 9*M+1];

% construct PHI & SIG
for jj=1:order(end)
    if jj<=order(1)
        if jj==1
            PHI(jj,jj) = rho;
            SIG(jj,jj) = (xix*sigma)^2 + (phiL*sigL)^2;
        else
            PHI(jj,jj-1) = 1;
        end
    elseif jj>order(1) && jj<=order(2)
        if jj==order(1)+1
            SIG(jj,jj) = sigma^2;
        elseif jj>(order(1)+1)
            PHI(jj,jj-1) = 1;        
        end    
    elseif jj>order(2) && jj<=order(3)
        if jj==order(2)+1
            SIG(jj,jj)   = sigme^2;  
        elseif jj>(order(2)+1)
            PHI(jj,jj-1) = 1;        
        end    
    elseif jj>order(3) && jj<=order(4)
        if jj==order(3)+1
            SIG(jj,jj)   = sigmeA^2;  
        elseif jj>(order(3)+1)
            PHI(jj,jj-1) = 1;        
        end     
    elseif jj>order(4) && jj<=order(5)
        if jj==order(4)+1
            SIG(jj,jj)   = (xid*sigma)^2;
        else
            PHI(jj,jj-1) = 1;
        end   
    elseif jj>order(5) && jj<=order(6)
        if jj==order(5)+1
            SIG(jj,jj) = (sigL)^2;
            SIG(1, jj) = phiL*sigL^2;
            SIG(jj, 1) = phiL*sigL^2;
            PHI(jj,jj) = rhoL;
        else
            PHI(jj,jj-1) = 1;
        end        
    end
end

% consumption
Z(1:2*M-1,2:order(1)) = eye(order(1)-1);
Z(1:2*M-1,order(1)+1:order(2)) = eye(order(2)-order(1));

for kk=1:2*M-1
    for jj=order(2)+1:order(3)
        if jj==order(2)+kk
            Z(kk,jj) = 1;
        elseif jj==order(2)+kk+1
            Z(kk,jj) = -1;
        end
    end
end
Z(M,order(2)+1:order(2)+M-1)     = -ones(1,M-1)/M;
Z(M,order(2)+M)                  = (M-1)/M;
Z(M,order(2)+M+2:order(2)+2*M)   = ones(1,M-1)/M;
Z(M,order(2)+M+1)                = -(M-1)/M;
Z(M,order(3)+1:order(4))         = [1 zeros(1,M-1) -1];

% dividend
Z(2*M,2:2*M)       = phi*([[1:1:M] M-([1:1:M-1])])/M;
Z(2*M,2*M+1:4*M-1) = dpi*([[1:1:M] M-([1:1:M-1])])/M;
Z(2*M,7*M+1:end-2) = ([[1:1:M] M-([1:1:M-1])])/M;
% market return
Z(2*M+1,1:2) = [mur1 mur2];
Z(2*M+1,order(1)+1) = mur3;
Z(2*M+1,order(4)+1) = mur4;
Z(2*M+1,order(5)+1) = mur5;
Z(2*M+1,order(6))   = mur6;
% risk-free rate
Z(2*M+2,2)        = A1F;
Z(2*M+2,order(6)) = A1LF;

% construct Zv: 3 VOL (t+1 and t each): 6
% order = [sigx(t)^2 sig(t)^2 sigd(t)^2] 
ZV = zeros(2*M+2,6);
ZV(end-1,:) = [murXp murX murCp murC murDp murD];
ZV(end,:)   = [0     A2XF   0   A2CF   0     0];

Z0 = zeros(4,9*M+1);
Z0(1,2)     = 1;
Z0(1,2*M+1) = 1;
Z0(2,2)     = phi;
Z0(2,2*M+1) = dpi;
Z0(2,7*M+1) = 1;
Z0(3,1:2) = [mur1 mur2];
Z0(3,order(1)+1) = mur3;
Z0(3,order(4)+1) = mur4;
Z0(3,order(5)+1) = mur5;
Z0(3,order(6))   = mur6;
Z0(4,2)        = A1F;
Z0(4,order(6)) = A1LF;
% Z0(5,1)        = A1M;
% Z0(5,order(5)+1) = A1LM;

ZV0 = zeros(4,6);
ZV0(3,:) = [murXp murX murCp murC murDp murD];
ZV0(4,:) = [0     A2XF   0   A2CF   0     0];
%ZV0(5,:)   = [A2XM   0   A2CM   0    A2DM   0];


% construct D
D(1:2*M-1) = mu*ones(2*M-1,1);
D(2*M)     = mud*M;
D(2*M+1)   = mur;
D(2*M+2)   = A0F;

%D0 = [mu mud mur A0F A0M]';
D0 = [mu mud mur A0F]';

% construct RR
RR = zeros(2*M+2,2*M+2);
RR(2*M,2*M)     = 0.01^2;   % dividend growth
%RR(end-1,end-1) = 0.0005^2; % market return: 
RR(end,end)     = 0.0001^2; % risk-free rate

R0 = diag([0 0.005 0.0005 0.0005]).^2;


