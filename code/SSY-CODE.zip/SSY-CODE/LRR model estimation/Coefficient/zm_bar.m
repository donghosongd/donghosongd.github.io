function [diff, k0m, k1m] = zm_bar(x,para,k0,k1,A0,A1,A2)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0010;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);

% x process
PHI    = [rho  0    0   0;
           0   0    0   0;
           0   0    0   0;
           0   0    0  rhoL];

SIG    = [phiL^2*sigL^2 0 0 phiL*sigL^2;
                0       0 0     0      ;
                0       0 0     0      ;
           phiL*sigL^2  0 0     sigL^2 ];     
% v process
PHI_V0 = [sigbarX;
          sigbar;
          sigbarD ;
             0   ];
PHI_V1 = [nuX  0  0  0;
           0  nu  0  0;
           0   0 nuD 0;
           0   0  0  0];
       
SIG_V  = diag([sigwX sigw sigwD 0]).^2;

% div process
PSI = [phi  0   0    0];
GAM = [0   dpi  1    0];

mu     = [muc;mud];
e1     = [1 0 0 0];
e2     = [0 1 0 0];
e3     = [0 0 1 0];
e4     = [0 0 0 1];

% mean[zm(t)] = mean[A0M + A1M*x(t) + A2CM*sig(t)^2 + A2XM*sigx(t)^2 + A2DM*sigd(t)^2 ];

k1m = exp(x)/(1+exp(x));
k0m = log(1+exp(x))-k1m*x;

A1M  = (PSI-1/psi*e1+e4*PHI)/(eye(4)-k1m*PHI);
A2M  = ((theta-1)*A2*(k1*PHI_V1-eye(4))+0.5*( (theta-1)*k1*A1+k1m*A1M + GAM - gamma*e2 + theta*e4).^2 )/(eye(4)-k1m*PHI_V1);
A0M  = (theta*log(delta)+(theta-1)*(k0+(k1-1)*A0+k1*A2*PHI_V0)-gamma*mu(1)+k0m+mu(2)+k1m*A2M*PHI_V0+...       
       0.5*((theta-1)*k1*A2 +k1m*A2M)*SIG_V*((theta-1)*k1*A2 +k1m*A2M)' + ...
       0.5*((theta-1)*k1*A1 +k1m*A1M + GAM-gamma*e2+theta*e4)*SIG*((theta-1)*k1*A1 +k1m*A1M + GAM-gamma*e2+theta*e4)')/(1-k1m);



diff = x - (A0M + A2M(1)*(xie*sigma)^2 + A2M(2)*(sigma)^2 + A2M(3)*(xid*sigma)^2);



