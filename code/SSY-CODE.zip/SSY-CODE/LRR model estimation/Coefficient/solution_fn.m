function [A0,A1X,A1L,A2X,A2C,A2D,A0M,A1XM,A1LM,A2XM,A2CM,A2DM,A0F,A1XF,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m,rp0V,rp0L,rp2C,rp2X] = solution_fn(para)

delta = 0.999;
muc   = 0.0016;
mud   = 0.0010;

psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% theta
theta = (1-gamma)/(1-1/psi);

% specification
options = optimset('MaxIter', 1e20, 'MaxFunEvals', 1e20, 'TolFun',1e-20, 'Display', 'off');

% x process
PHI    = [rho  0    0   0;
           0   0    0   0;
           0   0    0   0;
           0   0    0  rhoL];

SIG    = [phiL^2*sigL^2 0 0 phiL*sigL^2;
                0       0 0     0      ;
                0       0 0     0      ;
           phiL*sigL^2  0 0     sigL^2 ];     
% v process
PHI_V0 = [sigbarX;
          sigbar;
          sigbarD ;
             0   ];
PHI_V1 = [nuX  0  0  0;
           0  nu  0  0;
           0   0 nuD 0;
           0   0  0  0];
       
SIG_V  = diag([sigwX sigw sigwD 0]).^2;

% div process
PSI = [phi  0   0    0];
GAM = [0   dpi  1    0];

mu     = [muc;mud];
e1     = [1 0 0 0];
e2     = [0 1 0 0];
e3     = [0 0 1 0];
e4     = [0 0 0 1];

%% solve for the mean of log(P/C) or z(t)
% Z(t) = A0 + A1*X(t) + A2*V(t) 
zcfcn   = @(x) z_bar(x,para);
zc0     = 6.5;
[zmean] = fsolve(zcfcn,zc0,options);
k1 = exp(zmean)/(1+exp(zmean));
if k1>0.9999
    k1=0.9999;
end
k0 = log(1+exp(zmean))-k1*zmean;

A1  = ( (1-1/psi)*e1 + e4*PHI )/(eye(4)-k1*PHI);
A2  = 0.5*theta*(k1*A1+(1-1/psi)*e2+e4).^2/(eye(4)-k1*PHI_V1);
A0  = ( log(delta)+k0+mu(1)*(1-1/psi)+k1*A2*PHI_V0+0.5*theta*(k1*A2*SIG_V*A2'*k1)+... 
        0.5*theta*(k1*A1+(1-1/psi)*e2+e4)*SIG*(k1*A1+(1-1/psi)*e2+e4)')/(1-k1);
        
%% solve for the mean of log(P/D) or zm(t)
zmfcn    = @(x) zm_bar(x,para,k0,k1,A0,A1,A2);
zm0      = 7;
[zmmean] = fsolve(zmfcn,zm0,options);
% plug-in mean value
k1m = exp(zmmean)/(1+exp(zmmean));
if k1m>0.9999
    k1m=0.9999;
end
k0m = log(1+exp(zmmean))-k1m*zmmean;

A1M  = (PSI-1/psi*e1+e4*PHI)/(eye(4)-k1m*PHI);
A2M  = ((theta-1)*A2*(k1*PHI_V1-eye(4))+0.5*( (theta-1)*k1*A1+k1m*A1M + GAM - gamma*e2 + theta*e4).^2 )/(eye(4)-k1m*PHI_V1);
A0M  = (theta*log(delta)+(theta-1)*(k0+(k1-1)*A0+k1*A2*PHI_V0)-gamma*mu(1)+k0m+mu(2)+k1m*A2M*PHI_V0+...       
       0.5*((theta-1)*k1*A2 +k1m*A2M)*SIG_V*((theta-1)*k1*A2 +k1m*A2M)' + ...
       0.5*((theta-1)*k1*A1 +k1m*A1M + GAM-gamma*e2+theta*e4)*SIG*((theta-1)*k1*A1 +k1m*A1M + GAM-gamma*e2+theta*e4)')/(1-k1m);

%% solve for risk-free rate

A0F  = -theta*log(delta)-(theta-1)*(k0+(k1-1)*A0+k1*A2*PHI_V0)+gamma*mu(1)+...
       -0.5*(theta-1)^2*(k1*A2*SIG_V*A2'*k1) + ...
       -0.5*((theta-1)*k1*A1-gamma*e2+theta*e4)*SIG*((theta-1)*k1*A1-gamma*e2+theta*e4)';
A1F  = 1/psi*e1 - e4*PHI;
A2F  = -(theta-1)*A2*(k1*PHI_V1-eye(4))-0.5*( (theta-1)*k1*A1 - gamma*e2 + theta*e4 ).^2;
   
   
%% re-define coefficients
A1X  = A1(1);
A1L  = A1(4);
A2C  = A2(2);
A2X  = A2(1);
A2D  = 0;

A1XM = A1M(1);
A1LM = A1M(4);
A2CM = A2M(2);
A2XM = A2M(1);
A2DM = A2M(3);

A1XF = A1F(1);
A1LF = A1F(4);
A2CF = A2F(2);
A2XF = A2F(1);   
A2DF = 0;   
   
   
% risk premium: rp0V rp0L rp2C rp2X
rp0V = -(theta-1)*k1*A2C*k1m*A2CM*sigw^2  -(theta-1)*k1*A2X*k1m*A2XM*sigwX^2 ;
rp0L = - ((theta-1)*k1*A1L+theta)*k1m*A1LM*sigL^2 ;
rp2C = - dpi*(theta*(1-1/psi)-1) ;
rp2X = - (theta-1)*k1*A1X*k1m*A1XM  ;   
   
   
   
   
   
   

















