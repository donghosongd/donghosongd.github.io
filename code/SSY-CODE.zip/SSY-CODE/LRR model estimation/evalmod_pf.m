function [loglh, At_mat, Hlast,Neff] = evalmod_pf(para,YDATA,index,nP)
    

T = size(YDATA,1);
M = 12;    
% model-coefficients
[DD,ZZ,PHIF,SIG,ZV,RR,~,~,~,~,V0,NU,VV] = statespace_full(para,M);
mZ   = size(ZZ,1);
mdim = size(PHIF,1);


sigL = para(12);
phiL = para(13);

% initialization of the filter  
[state,At,Pt] = initialization(PHIF,SIG,NU,VV,nP);  
At_vec        = At';
Pt_vec        = reshape(Pt,mdim,mdim,nP);
    
At_mat        = zeros(T,mdim);  
lh_mat        = zeros(T,1);
Neff          = zeros(T,1);
Hlast         = zeros(T,3);

% Filter loop 
for t = 1:T

    %% run Particle filter: nP-by-3
    statehat    = state*NU + (VV*randn(3,nP))';

    %% run Kalman filter | particles
    At_vec_new  = zeros(nP,mdim);
    Pt_vec_new  = zeros(mdim,mdim,nP); 
    loglh_vec   = zeros(nP,1);
        
    if index(t)==1     % we have consumption (MF), dividend (MF), market return (MF), risk-free (MF)
        MS            = zeros(M+3,mZ);
        MS(1:M,1:M)   = eye(M);
        MS(end-2:end,end-2:end) = eye(3);       
        data = YDATA(t,1:M+3)';
    elseif index(t)==M % we have consumption (AF), dividend data (MF), market return (MF), risk-free (MF)
        MS            = zeros(4,mZ);
        MS(1,1:2*M-1) = ([[1:1:M] M-([1:1:M-1])])/M;
        MS(end-2:end,end-2:end) = eye(3); 
        data          = YDATA(t,1:4)';
    elseif index(t)==0 % we dont have consumption data
        MS            = zeros(3,mZ);
        MS(end-2:end,end-2:end) = eye(3); 
        data          = YDATA(t,1:3);
    else
        MS            = [];
        data          = [];
    end

    if t>217
        SIG(6*M,6*M) = 0;
    end
   
    MD = MS*DD;
    MZ = MS*ZZ;
    MV = MS*ZV;    
    MR = MS*RR*MS';    

    %parfor jjj=1:nP
    for jjj=1:nP

        At = At_vec(jjj,:)'; 
        Pt = squeeze(Pt_vec(:,:,jjj));

        sxplus = V0(1)*exp(2*statehat(jjj,1));
        sxnow  = V0(1)*exp(2*state(jjj,1));
        scplus = V0(2)*exp(2*statehat(jjj,2));
        scnow  = V0(2)*exp(2*state(jjj,2));
        sdplus = V0(3)*exp(2*statehat(jjj,3));
        sdnow  = V0(3)*exp(2*state(jjj,3));
     
        vstate = [sxplus;sxnow;scplus;scnow;sdplus;sdnow];  
     
        SIGF              = SIG;
        SIGF(1,1)         = sxnow + (phiL*sigL)^2;
        SIGF(2*M+1,2*M+1) = scnow;
        SIGF(7*M+1,7*M+1) = sdnow;
        SIGF(1,9*M)       = phiL*sigL^2;
        SIGF(9*M,1)       = phiL*sigL^2;

        % forecasting
        At1 = At;
        Pt1 = Pt;

        alphahat = PHIF * At1;
        Phat     = PHIF * Pt1 * PHIF' + SIGF;
        Phat     = 0.5*(Phat+Phat');

        yhat = MD+MZ*alphahat+MV*vstate;
        nut  = reshape(data,[],1) - yhat; 

        Ft = MZ*Phat*MZ' + MR;  
        Ft = 0.5*(Ft+Ft');  

        invFt = eye(size(Ft,1))/Ft;
        loglh = -0.5*length(data)*log(2*pi)-0.5*log(det(Ft))-0.5*nut'*invFt*nut;   
        loglh = real(loglh);

        % Updating 
        AtN = alphahat + (Phat*MZ')*invFt*nut;
        PtN = Phat - (Phat*MZ')*invFt*(Phat*MZ')';            
        PtN = 0.5*(PtN+PtN');   

        At_vec_new(jjj,:)   = AtN;
        Pt_vec_new(:,:,jjj) = PtN;
        loglh_vec(jjj,:)    = loglh;
    end 

    %% resample particles  
    dMaxWeight = max(loglh_vec);
	vWeights   = exp(loglh_vec - dMaxWeight);
    vWeights   = reshape(vWeights/sum(vWeights),1,[]);
    Neff(t)    = 1/sum(vWeights.^2);
    
    %% resample
    vIndex     = residualResampling(vWeights);    
    state      = statehat(vIndex,:);  
    At_vec     = At_vec_new(vIndex,:);
    Pt_vec     = Pt_vec_new(:,:,vIndex);
    LH_vec     = loglh_vec(vIndex,:);    
        
    At_mat(t,:) = mean(At_vec);
    Hlast(t,:)  = mean(state);
    lh_mat(t)   = median(LH_vec);
end

loglh = sum(lh_mat);

% it is very difficult to impose h_t to be mean zero when the persistence approaches 1 
if max(abs(mean(Hlast(:,1))))>0.1
    loglh = -1e+10;
end
    
