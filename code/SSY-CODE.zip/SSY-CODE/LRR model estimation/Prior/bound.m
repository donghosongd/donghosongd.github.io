%=========================================================================
%            LOWER AND UPPER BOUND FOR PARAMETER VALUES
%=========================================================================
bdelta = [1e-4 0.999999];
bpsi   = [1.025 3.45];
bgamma = [5   15.78];
brho   = [-0.9999 0.9950];
brhoT  = [-0.9999 0.9935];
brhoL  = [-0.9999 0.9915];
brhoC  = [ 0.90   0.999];
brhoD  = [ 0.90   0.985];
bphi   = [-10    10];
bphiT   = [0.75    8.46];
bxie   = [1e-20  1];
bxid   = [1  10];
bsigma = [1e-20  10];
bsigmaC = [1e-20  0.0050];
bsigmaX = [0.0021  0.0045];
bsigmaV = [.04  0.20];
bmu    = [-10 10];
bpi    = [-10 10];
bphil  = [-10 0.0001];

%=========================================================================
%            PARAMETER SELECTION ACCORDING TO MODEL
%=========================================================================

lubound  = [bpsi;bgamma;brhoT;bpi;bxie;bxid;bsigmaC;bpi;...
            bsigma;bsigma;brhoL;bsigma;bphil;
            brhoC;bsigma;brho;bsigmaX;brho;bsigmaV];