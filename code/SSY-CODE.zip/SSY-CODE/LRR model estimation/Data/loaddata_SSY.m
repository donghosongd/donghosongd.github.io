% consumption growth
load 1959_MONTHLY.txt
load 1947_QUARTERLY.txt
load 1930_ANNUAL.txt

gr_mcon = X1959_MONTHLY;
gr_qcon = X1947_QUARTERLY;
gr_acon = X1930_ANNUAL;

% dividend growth
load div_crsp_shiller_interpolated_annualized_1930_2014.txt
% (1) original crsp, (2) shiller (annual) interpolation, (3) shiller (quarterly)
% interpolation
div_crsp = div_crsp_shiller_interpolated_annualized_1930_2014;


% other financial variables
load YF.txt

% stack monthly consumption only: 1959:M1 - 2014:M12
clear YCM
YCM = [];
for gg=1:M
    YCM = [YCM gr_mcon(M+1-gg:end+1-gg)];
end
top = [];
for gg=1:M-1
    top = [top gr_mcon(M-gg)];
end
top = [top 0];
YCM = [top;YCM];
YCM = [zeros(M-1,M);YCM];

% redefine data
YA = [kron(gr_acon,ones(12,1)) div_crsp(:,3)];
YM = zeros(size(YA,1),12);
YM(end-671:end,:) = YCM;

% set time and index
time  = 1930+1/12:1/12:2015;
index = repmat([zeros(11,1);1],length(time)/12,1);
cut   = find(time==1961);
index(1:cut) = 12*index(1:cut);
nT    = length(time);

% redefine data
YF    = YF(end-1020+1:end,:);
YDATA = constructData(YM,YA,YF,index,M);
