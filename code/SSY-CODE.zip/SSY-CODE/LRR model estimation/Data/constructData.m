function YDATA = constructData(YM,YA,YF,index,M)

nT    = size(index,1);
YDATA = zeros(nT,M+3);
for t = 1:nT
    if index(t)==1     % we have both consumption (MF), dividend data (MF)
        YDATA(t,1:M+3) = [YM(t,:) YA(t,2) YF(t,2:3)];
    elseif index(t)==M % we have both consumption (AF), dividend data (MF)
        YDATA(t,1:4)   = [YA(t,:) YF(t,2:3)];
    elseif index(t)==0 % we only have dividend data
        YDATA(t,1:3)   = [YA(t,2) YF(t,2:3)];
    end
end