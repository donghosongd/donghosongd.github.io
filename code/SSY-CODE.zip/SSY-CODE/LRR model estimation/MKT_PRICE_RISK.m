tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Coefficient',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

select = 3;

if select ==3
    load ssy_april2017
elseif select == 2
    load result_cashflowonly
elseif select == 1
    load result_cashflowonly_short
end

nsim   = size(parasim,1);
lambda = zeros(nsim,5);
kappa  = zeros(nsim,2);

for ii=1:nsim

    if mod(ii,1000)==0 
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(ii)]                 );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-ii)]            );
    disp('                                                         ');    
    end
    
    para  = parasim(ii,:)';     
   
    delta = 0.999;
    muc   = 0.0016;
    mud   = 0.0010;

    psi   = 1.9655;
    gamma = 8.8948;
    rho   = para(3);
    phi   = para(4);
    xie   = para(5)*sqrt(1-rho^2);
    xid   = para(6);
    sigma = para(7);
    dpi   = para(8);
    sigme = para(9);
    sigmA = para(10);
    rhoL  = 0.9593;
    sigL  = 0.0004;
    phiL  = 0;
    rhoh  = para(14);
    sigh  = abs(sqrt(para(15)));
    rhohX = para(16);
    sighX = abs(sqrt(para(17)));
    rhohD = para(18);
    sighD = abs(sqrt(para(19)));
    % Taylor approximation: VOL parameters
    nu      = rhoh;
    sigbar  = (1-nu)*sigma^2;
    sigw    = 2*sigma^2*sigh;

    nuX     = rhohX;
    sigbarX = (1-nuX)*(xie*sigma)^2;
    sigwX   = 2*(xie*sigma)^2*sighX;

    nuD     = rhohD;
    sigbarD = (1-nuD)*(xid*sigma)^2;
    sigwD   = 2*(xid*sigma)^2*sighD;

    theta = (1-gamma)/(1-1/psi);
    [A0,A1,A1L,A2X,A2C,A2D,A0M,A1M,A1LM,A2XM,A2CM,A2DM,A0F,A1F,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m] = solution_fn(para);

    lambda(ii,1)  = gamma*sigma; 
    lambda(ii,2)  = (gamma-1/psi)*k1/(1-k1*rho)*(xie*sigma);
    lambda(ii,3)  = -(theta-k1*rhoL)/(1-k1*rhoL)*sigL;
    lambda(ii,4)  = 0.5*theta*(gamma-1/psi)*(1-1/psi)*k1/(1-k1*rhohX)*(k1/(1-k1*rho))^2*sigwX;
    lambda(ii,5)  = 0.5*theta*(gamma-1/psi)*(1-1/psi)*k1/(1-k1*rhoh)*sigw;   
    kappa(ii,:)   = [k0 k1];
end

if select ==3
    save('result_mktprice.mat','lambda','parasim','kappa')
elseif select == 2
    save('result_mktprice_cashflow.mat','lambda','parasim','kappa')
elseif select == 1
    save('result_mktprice_cashflow_short.mat','lambda','parasim','kappa')
end



