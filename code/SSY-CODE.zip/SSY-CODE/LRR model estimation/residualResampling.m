function vIndex = residualResampling(vWeights)

% Use Matlab's random number generator to generate the uniform r.v.'s
iN = size(vWeights,2);
% residual number of particles to sample
iN_residuals = iN - sum(floor(iN.*vWeights));
vU = rand(1,iN_residuals);

% Call the mex code to run in C
vIndex = residualResampling_C(vWeights, vU);
