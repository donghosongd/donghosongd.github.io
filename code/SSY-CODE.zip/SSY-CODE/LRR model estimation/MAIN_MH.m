tic
close all
clear
clc

ls = path;
path('Data',path);
path('Coefficient',path);
path('Prior',path);
path('Gauss Code',path);
path('Moment',path);
path('Sims Code',path);

% model frequency is monthly, use annual data (temporal-aggregation )
M = 12; 

% load data    
loaddata_SSY

% prior
load prior_pf.txt
prior    = prior_pf;
pshape   = prior(:,1);  
pmean    = prior(:,2); 
pstdd    = prior(:,3);
pmask    = prior(:,4); % 1: fixed, 0: not fixed
pfix     = prior(:,5); % if fixed, pfix is a degenerate prior value
pmaskinv = 1 - pmask;
pshape   = pshape.*pmaskinv;

% bound
bound

% proposal distribution
load proposal
nP          = 5000; 
% set details
opt         = 0;
load para.txt
paraold     = para; 
npara       = length(paraold);
sigscale    = H; 
fcn         = @(x1) objfcn_pf(x1,pshape,pmean,pstdd,pmask,pmaskinv,pfix,lubound,YDATA,index,nP,opt);

%=========================================================================
%                            CONFIGURE
%=========================================================================

nblocks  = 1;
nsim     = 50000;
cc       = 0.1;  
%=========================================================================
%                    METROPOLIS-HASTINGS ALGORITHM
%=========================================================================
disp('                                                                ');
disp('  RANDOM WALK METROPOLIS-HASTINGS ALGORITHM                     ');
disp('                                                                ');
 
%--------------------------------------------------------------------------     
%           initial draw for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

[postold, likeold, At_old, H_old] = fcn(paraold); 

%--------------------------------------------------------------------------     
%           block loop for Random Walk Metropolis Algorithm
%--------------------------------------------------------------------------

% storages 
parasim  = zeros(nsim,npara);       % parameter draws
likesim  = zeros(nsim,1);           % likelihood
postsim  = zeros(nsim,1);           % posterior probability
rej      = zeros(nsim,1);           % rej = 1: rejected
statesim = zeros(nsim,nT,4);
volsim   = zeros(nsim,nT,3);

for j = 1:nsim

    if j==2
    disp('                                                         ');
    disp('    ESTIMATION STARTS                                     ');
    disp('                                                         ');
    end

    % report 
    if mod(j,100)==0 
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(j)]                  );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-j)]             );
    disp('                                                         ');        
    disp(['  REJECTION RATE:   ',      num2str(mean(rej(1:j)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,1:9)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - PARA:   ',    num2str(median(parasim(1:j-1,10:end)))]     );
    disp('                                                         ');
    disp(['  SUMMARY - POSTERIOR:   ',    num2str(median(postsim(1:j-1,:)))]     );
    disp('                                                         ');
    disp(['  TIME ELAPSED:   ',    num2str(toc)]                 );
    disp('                                                         ');

    save results_pf
    end      

    % propose
    genacc=0;
    while genacc<1
        paranew = mvnrnd(paraold, cc*sigscale,1)';
        paranew = paranew.*pmaskinv + pfix.*pmask;        
        genacc  = all(paranew < lubound(:,2) & paranew > lubound(:,1));
    end
    
    % evaluate at the new candidate
    [postnew, likenew, At_new, H_new] = fcn(paranew);    
        
    r = min([1 exp( postnew - postold)]);            

    if rand > r 
       % reject proposed jump             
       rej(j) = 1;
    else
       % accept proposed jump          
       paraold = paranew;
       postold = postnew;
       likeold = likenew;
       At_old  = At_new;
       H_old   = H_new;
    end

    % store simulated variables
    statesim(j,:,:) = [At_old(:,1) At_old(:,2*12+1) At_old(:,7*12+1) At_old(:,9*12+1)]; 
    volsim(j,:,:)   = H_old;
    parasim(j,:)    = paraold';
    likesim(j,:)    = likeold;
    postsim(j,:)    = postold;

end       % with-in model  

     
path=ls;


