function [mLogVols,At,Pt] = initialization(PHIF,SIG,NU,VV,nP)

%mLogVols = (5*VV*randn(size(VV,1),nP))';
mLogVols = repmat(reshape(linspace(-1,2,nP),[],1),1,3);
    
nS = size(PHIF,1);

% Pt = dlyap(PHIF,SIG);
% At = mvnrnd(zeros(nS,1),Pt,nP)';
% Pt = repmat(reshape(Pt,nS^2,1),1,nP);


% initialize KF
Pt = zeros(nS,nS);
for ii=1:50
    Pt = PHIF*Pt*PHIF'+SIG;
end

% store KF
[u, s, ~] = svd(Pt);
Pchol = u*sqrt(s);
At = repmat(Pchol*randn(nS,1),1,nP);
Pt = repmat(reshape(Pt,nS^2,1),1,nP);

