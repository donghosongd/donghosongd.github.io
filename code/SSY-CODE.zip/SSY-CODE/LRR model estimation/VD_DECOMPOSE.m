tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Coefficient',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

load results
ts  = floor(0.25*j);
te  = floor(j-1);

te2 = floor((te-ts)/10);

nsim = size(parasim,1);
nT   = 1020;

R_series = zeros(nsim,nT,6);
F_series = zeros(nsim,nT,6);
R_decomp = zeros(nsim,nT,5);
F_decomp = zeros(nsim,nT,5);
P_decomp = zeros(nsim,nT,5);

counter = 0;

for kk = 1:te2
    k = ts+10*kk;
        % report 
        counter = counter +1;     
        if counter==10
        disp('                                                         ');
        disp(['POSTERIOR DRAWS:   ',  num2str(floor(100*(kk)./(te2)))] );
        disp('                                                         ');      
        counter = 0;
        end
        
for t=1:nT
    
para  = parasim(k,:);  

delta = 0.999;
muc   = 0.0016;
mud   = 0.0010;
psi   = para(1);
gamma = para(2);
rho   = para(3);
phi   = para(4);
xie   = para(5)*sqrt(1-rho^2);
xid   = para(6);
sigma = para(7);
dpi   = para(8);
sigme = para(9);
sigmA = para(10);
rhoL  = para(11);
sigL  = para(12);
phiL  = para(13);
rhoh  = para(14);
sigh  = abs(sqrt(para(15)));
rhohX = para(16);
sighX = abs(sqrt(para(17)));
rhohD = para(18);
sighD = abs(sqrt(para(19)));

% Taylor approximation: VOL parameters
nu      = rhoh;
sigbar  = (1-nu)*sigma^2;
sigw    = 2*sigma^2*sigh;

nuX     = rhohX;
sigbarX = (1-nuX)*(xie*sigma)^2;
sigwX   = 2*(xie*sigma)^2*sighX;

nuD     = rhohD;
sigbarD = (1-nuD)*(xid*sigma)^2;
sigwD   = 2*(xid*sigma)^2*sighD;

% state-space representation    
[DD,ZZ,PHI,SIG,ZV,RR,V0,NU,VV,SIG0] = statespace_simple(para);

% change definition: add pd ratio
nv = 5;
RR = zeros(nv,nv);

mdim = size(PHI,1);

[A0,A1X,A1L,A2X,A2C,A2D,A0M,A1XM,A1LM,A2XM,A2CM,A2DM,A0F,A1XF,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m,rp0V,rp0L,rp2C,rp2X] = solution_fn(para);

TT = [[ZZ ZV];[0 A1XM 0 0 0 A1LM 0 A2XM 0 A2CM 0 A2DM]];

% 1  2   3   4    5   6
% xp xn eta etad xlp xln
% state vector
logvolp = squeeze(volsim(k,t,:));
if t>1
    state   = [squeeze(statesim(k,t,1)) squeeze(statesim(k,t-1,1)) squeeze(statesim(k,t,2)) squeeze(statesim(k,t,3)) squeeze(statesim(k,t,4)) squeeze(statesim(k,t-1,4))]; 
    logvoln = squeeze(volsim(k,t-1,:));
else
    state   = [squeeze(statesim(k,t,1)) squeeze(statesim(k,t,1)) squeeze(statesim(k,t,2)) squeeze(statesim(k,t,3)) squeeze(statesim(k,t,4)) squeeze(statesim(k,t,4))]; 
    logvoln = [0 0 0];
end
% vol vector
vstate = [(xie*sigma)^2*exp(2*logvolp(1));...
          (xie*sigma)^2*exp(2*logvoln(1));...
          (sigma)^2*exp(2*logvolp(2));...
          (sigma)^2*exp(2*logvoln(2));...
          (xid*sigma)^2*exp(2*logvolp(3));...
          (xid*sigma)^2*exp(2*logvoln(3))]';
state_x  = [0 0 state(3:end)];      
state_l  = [state(1:4) 0 0 ];
vstate_x = [0 0 vstate(3:end)]';
vstate_c = [vstate(1:2) 0 0 vstate(5:6)]';
vstate_d = [vstate(1:4) 0 0]';

R_series(k,t,6) = DD(3) + ZZ(3,:)*state'   + ZV(3,:)*vstate';
R_series(k,t,1) = DD(3) + ZZ(3,:)*state_x' + ZV(3,:)*vstate';
R_series(k,t,2) = DD(3) + ZZ(3,:)*state_l' + ZV(3,:)*vstate';
R_series(k,t,3) = DD(3) + ZZ(3,:)*state'   + ZV(3,:)*vstate_x;
R_series(k,t,4) = DD(3) + ZZ(3,:)*state'   + ZV(3,:)*vstate_c;
R_series(k,t,5) = DD(3) + ZZ(3,:)*state'   + ZV(3,:)*vstate_d;

F_series(k,t,6) = DD(4) + ZZ(4,:)*state'   + ZV(4,:)*vstate';
F_series(k,t,1) = DD(4) + ZZ(4,:)*state_x' + ZV(4,:)*vstate';
F_series(k,t,2) = DD(4) + ZZ(4,:)*state_l' + ZV(4,:)*vstate';
F_series(k,t,3) = DD(4) + ZZ(4,:)*state'   + ZV(4,:)*vstate_x;
F_series(k,t,4) = DD(4) + ZZ(4,:)*state'   + ZV(4,:)*vstate_c;
F_series(k,t,5) = DD(4) + ZZ(4,:)*state'   + ZV(4,:)*vstate_d;

PHIF          = zeros(12,12);
PHIF(1:6,1:6) = PHI;
PHIF(7,7)     = rhohX;
PHIF(8,7)     = 1;
PHIF(9,9)     = rhoh;
PHIF(10,9)    = 1;
PHIF(11,11)   = rhohD;
PHIF(12,11)   = 1;

SIGF = diag([vstate(2) 0 vstate(4) vstate(6) sigL^2 0 sigwX^2 0 sigw^2 0 sigwD^2 0]);  

varT = dlyap(PHIF,SIGF);
varY = TT*varT*TT' ;%+ RR;
       
TTx = [zeros(nv,2) TT(:,3:end)];
TTl = [TT(:,1:4)  zeros(nv,2) TT(:, 7:12)];
TTh = [TT(:,1:6)  zeros(nv,2) TT(:, 9:12)];
TTc = [TT(:,1:8)  zeros(nv,2) TT(:,11:12)];
TTd = [TT(:,1:10) zeros(nv,2)];

varYx = TTx*varT*TTx';%+RR;
varYl = TTl*varT*TTl';%+RR;
varYh = TTh*varT*TTh';%+RR;
varYc = TTc*varT*TTc';%+RR;
varYd = TTd*varT*TTd';%+RR;

R_decomp(kk,t,1) = 100*(1-varYx(3,3)./varY(3,3));
R_decomp(kk,t,2) = 100*(1-varYl(3,3)./varY(3,3));
R_decomp(kk,t,3) = 100*(1-varYh(3,3)./varY(3,3));
R_decomp(kk,t,4) = 100*(1-varYc(3,3)./varY(3,3));
R_decomp(kk,t,5) = 100*(1-varYd(3,3)./varY(3,3));

F_decomp(kk,t,1) = 100*(1-varYx(4,4)./varY(4,4));
F_decomp(kk,t,2) = 100*(1-varYl(4,4)./varY(4,4));
F_decomp(kk,t,3) = 100*(1-varYh(4,4)./varY(4,4));
F_decomp(kk,t,4) = 100*(1-varYc(4,4)./varY(4,4));
F_decomp(kk,t,5) = 100*(1-varYd(4,4)./varY(4,4));

P_decomp(kk,t,1) = 100*(1-varYx(5,5)./varY(5,5));
P_decomp(kk,t,2) = 100*(1-varYl(5,5)./varY(5,5));
P_decomp(kk,t,3) = 100*(1-varYh(5,5)./varY(5,5));
P_decomp(kk,t,4) = 100*(1-varYc(5,5)./varY(5,5));
P_decomp(kk,t,5) = 100*(1-varYd(5,5)./varY(5,5));

end
end

[rdc95,rdc80,rdc,rdc20,rdc05] = moment2(R_decomp(1:te2,:,:));
[fdc95,fdc80,fdc,fdc20,fdc05] = moment2(F_decomp(1:te2,:,:));
[pdc95,pdc80,pdc,pdc20,pdc05] = moment2(P_decomp(1:te2,:,:));


load recession.txt
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);
time = 1930:1/12:2015-1/12;

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);


fig3 = figure('Position',[20,20,900,600],'Name','Risk-Free Rate',...
    'Color','w','Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.4]);
subplot(1,3,1)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,fdc95(:,1)',fdc05(:,1)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,fdc(:,1),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$x_{t}$$','Interpreter','latex','FontSize',25)
subplot(1,3,2)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,fdc95(:,2)',fdc05(:,2)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,fdc(:,2),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$x_{\lambda,t}$$','Interpreter','latex','FontSize',25)
subplot(1,3,3)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,fdc95(:,3)',fdc05(:,3)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,fdc(:,3),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$\sigma_{x,t}^2$$','Interpreter','latex','FontSize',25)






fig3 = figure('Position',[20,20,900,600],'Name','PD Ratio',...
    'Color','w','Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.4]);
subplot(1,3,1)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,pdc95(:,1)',pdc05(:,1)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,pdc(:,1),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$x_{t}$$','Interpreter','latex','FontSize',25)
subplot(1,3,2)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,pdc95(:,2)',pdc05(:,2)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,pdc(:,2),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$x_{\lambda,t}$$','Interpreter','latex','FontSize',25)
subplot(1,3,3)
hold on
for kk = 1:length(xx), bar(xx(kk),100,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk), 0,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,pdc95(:,3)',pdc05(:,3)',[0.5 0.5 0.5],[0.5 0.5 0.5]);
hold on
plot(time,pdc(:,3),'Color',[0.1,0.1,0.1],'LineWidth',1.4)
axis([time(1) time(end) 0  100])
title('$$\sigma_{x,t}^2$$','Interpreter','latex','FontSize',25)








