tic
close all
clear 
clc

ls = path;
path('Data',path);
path('Coefficient',path);
path('Prior',path);
path('Moment',path);
path('Sims Code',path);

load results_pf

% [YY,~] = xlsread('data_filtered.xls');
% time   = YY(:,1);
% YY     = YY(:,2:end);

ts = floor(0.15*j);
te = floor(j-1);

[yy, yy05, yy95]=moment(parasim(ts:te,:));
[zx, zx05, zx95]=moment(likesim(ts:te,:));
[yx, yx05, yx95]=moment(postsim(ts:te,:));


%% prior evaluation
nP     = size(prior,1);
store  = zeros(nP,3);

for ii=1:nP
    a = prior(ii,2);
    b = prior(ii,3);
    
    if prior(ii,1) == 5; % uniform
        this = [a + (b-a)/20 a+(b-a)/2  b-(b-a)/20];  
    elseif prior(ii,1) == 4; % inverted gamma
        [g05, g20, g50, g80, g95]=invgamcheck(a,b);
        this = [g05 g50 g95]; 
    elseif prior(ii,1) == 3; % normal 
        temp = a + b*randn(10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];
    elseif prior(ii,1) == 2; % gamma
        [g05, g20, g50, g80, g95]=gamcheck(a,b);
        this = [g05 g50 g95];    
    elseif prior(ii,1) == 1 % beta 
        temp = betarnd(a,b,10000,1);
        [m50, m05, m95] = moment(temp);
        this = [m05 m50 m95];    
    end
    store(ii,:) = this;
end

sum_vec1 = [store;nan(3,3)];

sum_vec2 = [[yy05' yy' yy95'];
           [nan mean(rej(1:j-1)) nan];[zx05' zx' zx95'];[yx05' yx' yx95']];
sum_vec  = [sum_vec1 sum_vec2];       
       
%% description
vartype     = {'\psi','\gamma','\rho','\phi','\varphi_{x}'...
               '\varphi_{d}','\sigma','\pi',...
               '\sigma_{e}','\sigma_{e}^{a}','\rho_{\lambda}','\sigma_{\lambda}','\phi_{\lambda}',...
               '\rho_{hC}','\sigma_{hC}','\rho_{hX}','\sigma_{hX}','\rho_{hD}','\sigma_{hD}',...
               'rejection','\likelihood','\posterior'};
disp('==============================================================================================================');   
disp('                                                                                                             '); 
disp(['                                       Prior Distribution                    Posterior Draws: ', num2str(j)   ] );
disp('                                                                                                             ');
disp('==============================================================================================================');
disp([' Variable Name                       5%         50%        95%              5%        50%       95%         ']);
disp('==============================================================================================================');
for hh=1:length(vartype);
    fprintf('%-30s %10.4f %10.4f %10.4f %15.4f %10.4f %10.4f\n',vartype{hh},sum_vec(hh,1),...
        sum_vec(hh,2),sum_vec(hh,3),sum_vec(hh,4),sum_vec(hh,5),sum_vec(hh,6));    
end
disp('==============================================================================================================');     
      

%% figures
% compute recursive mean
rparasim = zeros(size(parasim));
rpostsim = zeros(size(postsim));
for ii=1:size(parasim,2)
    for jj=ts:te
        rparasim(jj,ii) = mean(parasim(ts:jj,ii));
    end
end
    for jj=ts:te
        rpostsim(jj,:) = mean(postsim(ts:jj,:));
    end




scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',13)
set(0,'DefaultTextFontSize',13);

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1 scrsz(4)/1.2]);
subplot(3,5,1);
hold on
plot(parasim(ts:te,1))
plot(rparasim(ts:te,1),'r','LineWidth',2)
title('$$\psi$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,2);
hold on
plot(parasim(ts:te,2))
plot(rparasim(ts:te,2),'r','LineWidth',2)
title('$$\gamma$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,3);
hold on
plot(parasim(ts:te,3))
plot(rparasim(ts:te,3),'r','LineWidth',2)
title('$$\rho$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,4);
hold on
plot(parasim(ts:te,4))
plot(rparasim(ts:te,4),'r','LineWidth',2)
title('$$\phi$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,5);
hold on
plot(parasim(ts:te,5))
plot(rparasim(ts:te,5),'r','LineWidth',2)
title('$$\varphi_{x}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,6);
hold on
plot(parasim(ts:te,6))
plot(rparasim(ts:te,6),'r','LineWidth',2)
title('$$\varphi_{d}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,7);
hold on
plot(parasim(ts:te,7))
plot(rparasim(ts:te,7),'r','LineWidth',2)
title('$$\sigma$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,8)
hold on
plot(parasim(ts:te,8))
plot(rparasim(ts:te,8),'r','LineWidth',2)
title('$$\pi$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,9);
hold on
plot(parasim(ts:te,9))
plot(rparasim(ts:te,9),'r','LineWidth',2)
title('$$\sigma_{\varepsilon}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,10);
hold on
plot(parasim(ts:te,10))
plot(rparasim(ts:te,10),'r','LineWidth',2)
title('$$\sigma_{\varepsilon}^{a}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,11);
hold on
plot(parasim(ts:te,11))
plot(rparasim(ts:te,11),'r','LineWidth',2)
title('$$\rho_{\lambda}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,12);
hold on
plot(parasim(ts:te,12))
plot(rparasim(ts:te,12),'r','LineWidth',2)
title('$$\sigma_{\lambda}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,13);
hold on
plot(parasim(ts:te,13))
plot(rparasim(ts:te,13),'r','LineWidth',2)
title('$$\phi_{\lambda}$$','Interpreter','latex','FontSize',18)
axis tight
subplot(3,5,[14 15]);
hold on
plot(postsim(ts:te,:))
plot(rpostsim(ts:te,:),'r','LineWidth',2)
title('$$\log p(y|\theta)+\log p(\theta)$$','Interpreter','latex','FontSize',15)
axis tight



% FIGURE_STATE
