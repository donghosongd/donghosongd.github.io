vol05 = squeeze(quantile(volsim(ts:te,:,:),0.05));
vol20 = squeeze(quantile(volsim(ts:te,:,:),0.2));
vol50 = squeeze(quantile(volsim(ts:te,:,:),0.5));
vol80 = squeeze(quantile(volsim(ts:te,:,:),0.8));
vol95 = squeeze(quantile(volsim(ts:te,:,:),0.95));

state05 = squeeze(quantile(statesim(ts:te,:,:),0.05));
state50 = squeeze(quantile(statesim(ts:te,:,:),0.5));
state95 = squeeze(quantile(statesim(ts:te,:,:),0.95));

para = yy';
[A0,A1X,A1L,A2X,A2C,A2D,A0M,A1XM,A1LM,A2XM,A2CM,A2DM,A0F,A1XF,A1LF,A2XF,A2CF,A2DF,k1,k0,k1m,k0m,rp0V,rp0L,rp2C,rp2X] = solution_fn(para);

pdratio = A0M -log(12) + A1XM*state50(:,1) + A1LM*state50(:,4) + A2XM*(yy(5)*yy(7))^2*(1-yy(3)^2)*exp(2*vol50(:,1))...
          + A2CM*(yy(7))^2*exp(2*vol50(:,2)) + A2DM*(yy(6)*yy(7))^2*exp(2*vol50(:,3));

rfree = A0F + A1XF*state50(:,1) + A1LF*state50(:,4) + A2XF*(yy(5)*yy(7))^2*(1-yy(3)^2)*exp(2*vol50(:,1))...
          + A2CF*(yy(7))^2*exp(2*vol50(:,2)) + A2DF*(yy(6)*yy(7))^2*exp(2*vol50(:,3));
 
rfree1 = A0F + A1XF*state50(:,1) + A2XF*(yy(5)*yy(7))^2*(1-yy(3)^2)*exp(2*vol50(:,1))...
          + A2CF*(yy(7))^2*exp(2*vol50(:,2)) + A2DF*(yy(6)*yy(7))^2*exp(2*vol50(:,3));
      
load pdratio_1929_2014.txt
pdratio_data = pdratio_1929_2014(end-length(time)+1:end);
      
load lrr_univ.txt
fakeCON = nan(1020,1);
fakeCON(end-670:end) = gr_mcon-0.0016;


volX = (para(5)*para(7))^2*(1-para(3)^2)*exp(2*vol50(:,1));
volC =         (para(7))^2*exp(2*vol50(:,2));
volD = (para(6)*para(7))^2*exp(2*vol50(:,3));
            
rprem1 = rp2C*volC;
rprem2 = rprem1 + rp2X*volX;
rprem3 = rprem2 + rp0L;
rprem4 = rprem3 + rp0V;


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);

load recession.txt
xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.0]);
hold on
for kk = 1:length(xx), bar(xx(kk),13,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-13,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,1200*state95(:,1)',1200*state05(:,1)',[0.6 0.6 0.6],[0.5 0.5 0.5]);
hold on
k1=plot(time,1200*fakeCON,'Color',[0.1,0.6,0.9],'LineWidth',1);
k2=plot(time,1200*lrr_univ,'Color',[0.9,0.2,0.1],'LineWidth',4,'linestyle',':');
k3=plot(time,1200*state50(:,1),'Color',[0.1,0.1,0.1],'LineWidth',2);
kk = legend([k1,k3,k2],'$$g_{c,t}^{o}$$','$$\hat{x}_{c,t}$$(asset returns)','$$\hat{x}_{c,t}$$(cash flows only)');
set(kk,'interpreter','latex','location','southeast','fontsize',22);
legend('boxoff')
axis([time(1)-1/12 time(end) -13 13])


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.0]);
hold on
for kk = 1:length(xx), bar(xx(kk),13,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-13,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
k1=plot(time,1200*YF(:,3),'Color',[0.1,0.6,0.9],'LineWidth',2);
k2=plot(time,1200*rfree1,'Color',[0.9,0.2,0.1],'LineWidth',4,'linestyle',':');
k3=plot(time,1200*rfree,'Color',[0.1,0.1,0.1],'LineWidth',2);
kk = legend([k1,k3,k2],'$$r_{f,t}^{o}$$','$$\hat{r}_{f,t}$$','$$\hat{r}_{f,t}(x_\lambda=0)$$');
set(kk,'interpreter','latex','location','northeast','fontsize',22);
legend('boxoff')
axis([time(1)-1/12 time(end) -13 13])


hname = {'$$h_{x,t}$$','$$h_{c,t}$$','$$h_{d,t}$$'};

fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.4]);
for jj=1:3
subplot(1,3,jj)    
hold on
for kk = 1:length(xx), bar(xx(kk),2,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
for kk = 1:length(xx), bar(xx(kk),-1.5,ww(kk),'FaceColor',[0.8 0.8 0.8],'EdgeColor','w'), end
hold on
f90=shadedplot(time,vol80(:,jj)',vol20(:,jj)',[0.6 0.6 0.6],[0.6 0.6 0.6]);
hold on
plot(time,vol50(:,jj),'Color',[0.1,0.1,0.1],'LineWidth',1.75)    
axis([time(1)-1/12 time(end) -1.5 2 ])
title(hname(jj))
end


fig = figure('Position',[20,20,900,600],'Name',...
        '','Color','w','Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.95]);
hold on    
k1 = shadedplot(time,1200*rprem1',zeros(1,1020),[0.9 0.9 0.9],[0.9 0.9 0.9]);
hold on
k2 = shadedplot(time,1200*rprem2',1200*rprem1',[0.7 0.7 0.7],[0.7 0.7 0.7]);
hold on
k3 = shadedplot(time,1200*rprem3',1200*rprem2',[0.4 0.4 0.4],[0.4 0.4 0.4]);
hold on
k4 = shadedplot(time,1200*rprem4',1200*rprem3',[0.1 0.1 0.1],[0.1 0.1 0.1]);
hold on
kk = legend([k1,k2,k3,k4],'','short-run risk','','long-run growth risk','','preference risk','','volatility risks');
set(kk,'orientation','horizontal','location','northoutside','fontsize',23);
legend('boxoff');
axis([1930 time(end) 0 20])



