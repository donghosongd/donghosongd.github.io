% always compute 5y-1y from the model

sPrem   = mean(premvec(:,:,5)  - premvec(:,:,1),2);
sEdgr   = mean(edgrvec(:,:,5)  - edgrvec(:,:,1),2);
sErtrn  = mean(ertrnvec(:,:,5) - ertrnvec(:,:,1),2);
sStrips = mean(stripsvec(:,:,5) - stripsvec(:,:,1),2);
pRec    = mean(svec==2,2);

tsPrem = zeros(nsim,1);
tsEdgr = zeros(nsim,1);
tsErtrn = zeros(nsim,1);

for ii=1:nsim
[~, t] = ttest(squeeze(premvec(ii,:,5)  - premvec(ii,:,1)));
tsPrem(ii,1) = t;
[~, t] = ttest(squeeze(edgrvec(ii,:,5)  - edgrvec(ii,:,1)));
tsEdgr(ii,1) = t;
[~, t] = ttest(squeeze(ertrnvec(ii,:,5)  - ertrnvec(ii,:,1)));
tsErtrn(ii,1) = t;
end

[sortpRec,index] = sort(pRec);

h1 = find(sEdgr(index)<0,1,'last')+1;
h2 = find(sErtrn(index)>0,1,'last')+1;
h3 = min(find(tsErtrn(index)==max(tsErtrn(index)))+1);

uR = 0.12;
eR = 0.26;
jR = 0.35;

sort_Edgr  = sEdgr(index);
sort_Ertrn = sErtrn(index);
sort_tsErtrn = tsErtrn(index);

puR = find(sortpRec<uR,1,'last');
peR = find(sortpRec<eR,1,'last')+1;
pjR = find(sortpRec<jR,1,'last')+1;


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')  
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);
set(0,'DefaultLegendInterpreter','latex');


fig=figure('Position',[20,20,900,600],'Name','','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2.6]);  
% subplot(1,3,1)    
% hold on
% plot(sortpRec,0*sortpRec,'k--')
% plot(sortpRec,sEdgr(index),'Color',[0.1 0.1 0.1],'linewidth',4)
% line([sortpRec(h1),sortpRec(h1)],[-0.5 0.5],'color','k','linestyle','--')
% axis([0 0.4 -0.5 0.5])
% k1=plot(uR,sort_Edgr(puR),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
% k2=plot(eR,sort_Edgr(peR),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
%                 'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
% k3=plot(jR,sort_Edgr(pjR),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
%                 'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
% kk=legend([k1,k2,k3],'$$12\%$$','$$26\%$$','$$35\%$$');
% set(kk,'location','southeast');
% legend('boxoff');
% %title('$$E (g_{d,t+5y}-g_{d,t+1y})$$')
% title('slope of expected growth')
% xlabel('recession probability')

subplot(1,2,1)    
hold on
plot(sortpRec,0*sortpRec,'k--','linewidth',2)
plot(sortpRec,sErtrn(index),'Color',[0.1 0.1 0.1],'linewidth',4)
%line([sortpRec(h1),sortpRec(h1)],[-0.5 0.5],'color','k','linestyle','--')
line([prob(2),prob(2)],[-1.5 1.5],'color','k','linestyle','--','linewidth',2)
k1=plot(uR,sort_Ertrn(puR),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k2=plot(eR,sort_Ertrn(peR),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
k3=plot(jR,sort_Ertrn(pjR),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
kk=legend([k1,k2,k3],'$$12\%$$','$$26\%$$','$$35\%$$');
set(kk,'location','northeast');
legend('boxoff');
axis([-0.001 0.501 -1.0 1.2])
%title('$$E (r_{t+5y}-r_{t+1y})$$')
title('slope of expected return')
xlabel('sample recession frequency')

subplot(1,2,2)    
hold on
plot(sortpRec,sort_tsErtrn,'Color',[0.1 0.1 0.1],'linewidth',4)
%line([sortpRec(h1),sortpRec(h1)],[0 1],'color','k','linestyle','--')
line([prob(2),prob(2)],[0 1],'color','k','linestyle','--','linewidth',2)
k1=plot(uR,sort_tsErtrn(puR),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k2=plot(eR,sort_tsErtrn(peR),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
k3=plot(jR,sort_tsErtrn(pjR),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
kk=legend([k1,k2,k3],'$$12\%$$','$$26\%$$','$$35\%$$');
set(kk,'location','northeast');
legend('boxoff');
axis([-0.001 0.501 0 1.0])
title('$$p$$-value ($$H_0:$$ slope $$=0$$)')
xlabel('sample recession frequency')









