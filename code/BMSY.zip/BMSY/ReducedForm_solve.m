function [Edgr,Strips,Ertrn,Prem,SRatio,Vdgr,R0vec,B0vec,Erpm,SRmkt,Strips1] = ReducedForm_solve(mu,sig,rho,sigC,F0,F1,trans,lambda,sigD,L)

% transition probability
% columns have to sum to 1
nS    = size(trans,1);
[v,~] = eig(trans');
prob  = v/sum(v);
lrm   = reshape(prob,1,[])*mu;     
                            
   

%% Zm(t)^n = Bn(S_t), C(t)^n = Cn(S_t)
HH    = 601;

C0vec = zeros(HH,nS);
C1vec = zeros(HH,nS);

B0vec = zeros(HH,nS);
B1vec = zeros(HH,nS);


for hh=2:HH
    
   C1vec(hh,:) = (trans* (C1vec(hh-1,:)' - F1)*rho)';
   
   tempC       = C0vec(hh-1,:)' - F0 + 0.5*(C1vec(hh-1,:)' - F1).^2.*sig - (C1vec(hh-1,:)' - F1).*sqrt(sig).*L;
   C0vec(hh,:) = (trans*( tempC + 0.5*(tempC - trans*tempC).^2 ))';
   
   B1vec(hh,:) = (trans*(B1vec(hh-1,:)' - F1 + lambda)*rho)';
   
   tempB       = repmat((1-lambda)*lrm,nS,1) + B0vec(hh-1,:)' - F0 + lambda*mu...
                 + 0.5*lambda^2*sigC + 0.5*sigD...
                 + 0.5*(B1vec(hh-1,:)'-F1+lambda).^2.*sig...
                 - (B1vec(hh-1,:)'-F1+lambda).*sqrt(sig).*L;
   
   B0vec(hh,:) = (trans*( tempB + 0.5*(tempB - trans*tempB).^2 ))';
end
     
B0vec = B0vec(2:end,:);     
B1vec = B1vec(2:end,:);     

R0vec = -C0vec(2:end,:)./[1:HH-1]';
R1vec = -C1vec(2:end,:)./[1:HH-1]';




%% ln E_t R_{t+m,t}^n

Edgr    = zeros(HH-1,nS);
Vdgr    = zeros(HH-1,nS);
Strips  = zeros(HH-1,nS);
Ertrn   = zeros(HH-1,nS);
Prem    = zeros(HH-1,nS);
SRatio  = zeros(HH-1,nS);

Edgr1   = zeros(HH-1,nS);
Strips1 = zeros(HH-1,nS);
Ertrn1  = zeros(HH-1,nS);
Prem1   = zeros(HH-1,nS);

sum_Pi = zeros(HH-1,nS^2);
for hh=1:HH-1
   sum_Pi(hh,:) = reshape(trans^hh,1,[]); 
end
sum_Pi = cumsum(sum_Pi);


sum_var = zeros(HH-1,nS);

for hh=1:HH-1
    clear coeff1 coeff2
    coeff1 = [];
    coeff2 = [];
    for jj=1:hh
        coeff1 = [((1-rho^jj)/(1-rho))^2 coeff1 ];
        coeff2 = [coeff2 trans^jj*sig];
    end
    sum_var(hh,:) = (sum(0.5*lambda^2*(coeff1.*coeff2),2))';
end

add_var = zeros(HH-1,2);
for hh=1:HH-1
   add_var(hh,:) = trans^hh*(mu - trans^hh*mu).^2;  
end
sum_varM = lambda^2*cumsum(add_var);


for hh=1:HH-1
   muG           = hh*(repmat((1-lambda)*lrm,nS,1))...
                   + (reshape(sum_Pi(hh,:),nS,nS)*(lambda*mu));
   half_sigG     = 0.5*hh*(lambda^2*sigC + sigD) +...
                   sum_var(hh,:)';             
   half_sigGM    = sum_varM(hh,:)';
    
%    Edgr(hh,:)    = (repmat((1-lambda)*lrm,nS,1) + 0.5*lambda^2*sigC + 0.5*sigD)...
%                    + (reshape(sum_Pi(hh,:),nS,nS)*(lambda*mu))/hh...
%                    + sum_var(hh,:)'/hh; % this is incorrect
   Edgr(hh,:)    = muG/hh;   
   Vdgr(hh,:)    = (2*half_sigG + 2*half_sigGM)/(hh^2);
               
   Edgr1(hh,:)   = lambda*rho*((1-rho^hh)/(1-rho));            
               
   Strips(hh,:)  = -B0vec(hh,:)/hh;
   Strips1(hh,:) = -B1vec(hh,:)/hh;
   Ertrn(hh,:)   = Strips(hh,:) +  Edgr(hh,:);
   Prem(hh,:)    = Ertrn(hh,:) - R0vec(hh,:);% + 0.5*Vdgr(hh,:);
   SRatio(hh,:)  = Prem(hh,:)./(Vdgr(hh,:).^(0.5));
end




% %% E_t \Delta d_{t+n} & V_t \Delta d_{t+n}
% fm0vec = zeros(HH-1,NS);
% fm1vec = zeros(HH-1,NS);
% 
% sm0vec = zeros(HH-1,NS);
% sm1vec = zeros(HH-1,NS);
% 
% for hh=2:HH+1
%    fm0vec(hh,:) = (repmat((1-lambda)*lrm,nS,1) + trans*(lambda*mu + fm0vec(hh-1,:)'))'; 
%    fm1vec(hh,:) = trans*(fm1vec(hh-1,:)' + repmat(lambda,nS,1))*rho;
%    
%    sm1vec(hh,:) = trans*sm1vec(hh-1,:)'*rho;
%    sm0vec(hh,:) = (trans*sm0vec(hh-1,:)' + (lambda^2*sigC + sigD)...
%                   + 0.5*trans*(2*(fm1vec(hh-1,:)'+lambda).^2.*sig))';
%     
% end
% 
% fm0vec = fm0vec(2:end,:)';
% fm1vec = fm1vec(2:end,:)';
% sm0vec = sm0vec(2:end,:)';
% sm1vec = sm1vec(2:end,:)';


%% specification
options = optimset('MaxIter', 1e20, 'MaxFunEvals', 1e20, 'TolFun',1e-20, 'Display', 'off');

%% solve for the mean of log(P/C) or z(t)
zcfcn   = @(x) zd_bar(x,mu,sig,rho,sigC,F0,F1,trans,lambda,sigD,L);
zc0     = 6.5;
[zmean] = fsolve(zcfcn,zc0,options);
k1 = exp(zmean)/(1+exp(zmean));
if k1>0.99999
    k1=0.99999;
end
k0 = log(1+exp(zmean))-k1*zmean;

%% Z(t) = A0(S_t)+A1(S_t)x_t
     
A1    = inv(eye(nS)-k1*rho*trans)*(lambda-F1)*rho;

tempR = [k0 + (1-lambda)*lrm - F0(1) + lambda*mu(1) + 0.5*lambda^2*sigC(1) + 0.5*sigD(1)...
        + 0.5*(k1*A1(1) - F1(1) + lambda)^2*sig(1) - (k1*A1(1) - F1(1) + lambda)*sqrt(sig(1))*L(1);
         k0 + (1-lambda)*lrm - F0(2) + lambda*mu(2) + 0.5*lambda^2*sigC(2) + 0.5*sigD(2)...
        + 0.5*(k1*A1(2) - F1(2) + lambda)^2*sig(2) - (k1*A1(2) - F1(2) + lambda)*sqrt(sig(2))*L(2)];

A0    = inv(eye(nS)-k1*trans)*tempR;  

Erpm  = trans*[L(1)*sqrt(sig(1))*(k1*A1(1) + lambda);
               L(2)*sqrt(sig(2))*(k1*A1(2) + lambda)];


Vrtrn = [lambda^2*sigC(1) + sigD(1);
         lambda^2*sigC(2) + sigD(2)]+...
         trans*[ (k1*A1(1) + lambda)^2*sig(1);
                 (k1*A1(2) + lambda)^2*sig(2)];
         

Erpm = Erpm - 0.5*Vrtrn;
SRmkt = Erpm./(Vrtrn.^0.5);    

%Erpm = k0 + (1-lambda)*lrm +k1*trans*A0 - A0 + lambda*trans*mu - F0;




