prob_J = [0.65 0.35];
prob_E = [0.74 0.26];
prob_U = [0.88 0.12];


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')  
set(0,'DefaultAxesFontSize',20)
set(0,'DefaultTextFontSize',20);
set(0,'DefaultLegendInterpreter','latex');


fig=figure('Position',[20,20,900,600],'Name','Panel A','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/3]);  
    
subplot(1,5,1)
hold on
k0=plot(zeros(10,1),'k--');
k2=plot(1200*Edgr(12*[1:10],2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k1=plot(1200*Edgr(12*[1:10],1),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
% kk=legend([k1,k2],'expansion','recession');
% set(kk,'location','south','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([-1.5 4])
title('$$E_t g_{d,t+n}$$')

subplot(1,5,2)
hold on
k2=plot(1200*Strips(12*[1:10],2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k1=plot(1200*Strips(12*[1:10],1),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
% kk=legend([k1,k2],'expansion','recession');
% set(kk,'location','south','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([2 20])
% yticks([0 1 2 3])
% yticklabels({'0','1','2','3'})
title('$$e_{n,t}$$')

subplot(1,5,3)
hold on
k2=plot(1200*Ertrn(12*[1:10],2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k1=plot(1200*Ertrn(12*[1:10],1),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
% kk=legend([k1,k2],'expansion','recession');
% set(kk,'location','south','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([2 20])
% yticks([0 1 2 ])
% yticklabels({'0','1','2'})
title('$$E_t r_{t+n}$$')

subplot(1,5,4)
hold on
k2=plot(1200*Rvec(12*[1:10],2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k1=plot(1200*Rvec(12*[1:10],1),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
kk=legend([k1,k2],'expansion','recession');
set(kk,'location','southeast');
legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([1.5 3])
% yticks([0 1 2 ])
% yticklabels({'0','1','2'})
title('$$y_{n,t}^r$$')


subplot(1,5,5)
hold on
% k4=plot(repmat(1200*Erpm(2),1,10),'color',[0.1 0.1 0.1],'linewidth',2,'linestyle','--');
% k3=plot(repmat(1200*Erpm(1),1,10),'color',[0.1 0.2 0.9],'linewidth',2,'linestyle','-');  
k2=plot(1200*Prem(12*[1:10],2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k1=plot(1200*Prem(12*[1:10],1),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);          
% kk=legend([k3,k4],'asset (exp)','asset (rec)');
% set(kk,'location','northeast');
% legend('boxoff');
xlim([1 10])
ylim([2 16])
title('$$E_t rx_{t+n}$$')


fig=figure('Position',[20,20,900,600],'Name','Panel B','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/3.0]);  
    
subplot(1,5,1)
hold on
k1=plot(1200*Edgr(12*[1:10],1)*prob(1)+1.2*1200*Edgr(12*[1:10],2)*prob(2)*0.7,'color',[0.1 0.1 0.1],'linewidth',3,'marker','s',...
    'markersize',14,'markeredgecolor',[0.1 0.1 0.1],'markerfacecolor',[0.1 0.1 0.1]);
xlim([1 10])
ylim([0.5 2.5])
title('$$E_t g_{d,t+n}$$')

subplot(1,5,2)
hold on
k1=plot(1200*Strips(12*[1:10],1)*prob(1)+1200*Strips(12*[1:10],2)*prob(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','s',...
    'markersize',14,'markeredgecolor',[0.1 0.1 0.1],'markerfacecolor',[0.1 0.1 0.1]);
xlabel('maturity')
xlim([1 10])
ylim([4.5 5.5])
title('$$e_{n,t}$$')

subplot(1,5,3)
hold on
k1=plot(1200*Ertrn(12*[1:10],1)*prob(1)+1200*Ertrn(12*[1:10],2)*prob(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','s',...
    'markersize',14,'markeredgecolor',[0.1 0.1 0.1],'markerfacecolor',[0.1 0.1 0.1]);
xlabel('maturity')
xlim([1 10])
ylim([6.5 7.5])
title('$$E_t r_{t+n}$$')

subplot(1,5,4)
hold on
k1=plot(1200*Rvec(12*[1:10],1)*prob(1)+1200*Rvec(12*[1:10],2)*prob(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','s',...
    'markersize',14,'markeredgecolor',[0.1 0.1 0.1],'markerfacecolor',[0.1 0.1 0.1]);
xlabel('maturity')
xlim([1 10])
ylim([1.5 3])
title('$$y_{n,t}^r$$')

subplot(1,5,5)
hold on
k1=plot(1200*Prem(12*[1:10],1)*prob(1)+1200*Prem(12*[1:10],2)*prob(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','s',...
    'markersize',14,'markeredgecolor',[0.1 0.1 0.1],'markerfacecolor',[0.1 0.1 0.1]);
% k2=plot(repmat(1200*Erpm(1)*prob(1)+1200*Erpm(2)*prob(2),1,10),'color',[0.1 0.1 0.1],'linewidth',3,'linestyle','-'); 
% kk=legend([k1,k2],'strips','asset');
% set(kk,'location','best');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([4.5 5.5])
title('$$E_t rx_{t+n}$$')






fig=figure('Position',[20,20,900,600],'Name','Panel C','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/3.0]);  
    
subplot(1,4,1)
hold on
k1=plot(1200*Edgr(12*[1:10],1)*prob_U(1)+1200*Edgr(12*[1:10],2)*prob_U(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k2=plot(1200*Edgr(12*[1:10],1)*prob_E(1)+1200*Edgr(12*[1:10],2)*prob_E(2),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
k3=plot(1200*Edgr(12*[1:10],1)*prob_J(1)+1200*Edgr(12*[1:10],2)*prob_J(2),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
kk=legend([k1,k2,k3],'$$12\%$$','$$26\%$$','$$35\%$$');
set(kk,'location','south','orientation','horizontal');
legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([1.0 2.5])
title('$$E_t g_{d,t+n}$$')

subplot(1,4,2)
hold on
k1=plot(1200*Strips(12*[1:10],1)*prob_U(1)+1200*Strips(12*[1:10],2)*prob_U(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k2=plot(1200*Strips(12*[1:10],1)*prob_E(1)+1200*Strips(12*[1:10],2)*prob_E(2),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
k3=plot(1200*Strips(12*[1:10],1)*prob_J(1)+1200*Strips(12*[1:10],2)*prob_J(2),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
% kk=legend([k1,k2,k3],'$$12\%$$','$$26\%$$','$$35\%$$');
% set(kk,'location','northeast','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
%ylim([0.9*min(min(1200*Strips)) 1.1*max(max(1200*Strips))])
% yticks([0 1 2 3])
% yticklabels({'0','1','2','3'})
title('$$e_{n,t}$$')

subplot(1,4,3)
hold on
k1=plot(1200*Ertrn(12*[1:10],1)*prob_U(1)+1200*Ertrn(12*[1:10],2)*prob_U(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
k2=plot(1200*Ertrn(12*[1:10],1)*prob_E(1)+1200*Ertrn(12*[1:10],2)*prob_E(2),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
k3=plot(1200*Ertrn(12*[1:10],1)*prob_J(1)+1200*Ertrn(12*[1:10],2)*prob_J(2),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);
% kk=legend([k1,k2,k3],'US','Europe','Japan');
% set(kk,'location','north','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
ylim([6 10])
title('$$E_t r_{t+n}$$')


subplot(1,4,4)
hold on
k1=plot(1200*Prem(12*[1:10],1)*prob_U(1)+1200*Prem(12*[1:10],2)*prob_U(2),'color',[0.1 0.1 0.1],'linewidth',3,'marker','o','markersize',15);
%k4=plot(repmat(1200*Erpm(1)*prob_U(1)+1200*Erpm(2)*prob_U(2),1,10),'color',[0.1 0.1 0.1],'linewidth',2,'linestyle','--'); 
k2=plot(1200*Prem(12*[1:10],1)*prob_E(1)+1200*Prem(12*[1:10],2)*prob_E(2),'color',[0.1 0.2 0.9],'linewidth',2,'marker','d','markersize',15,...
                'markeredgecolor',[0.1 0.2 0.9],'markerfacecolor',[0.9 0.9 0.9]);
%k5=plot(repmat(1200*Erpm(1)*prob_E(1)+1200*Erpm(2)*prob_E(2),1,10),'color',[0.1 0.2 0.9],'linewidth',2,'linestyle','--');
k3=plot(1200*Prem(12*[1:10],1)*prob_J(1)+1200*Prem(12*[1:10],2)*prob_J(2),'color',[0.9 0.2 0.1],'linewidth',2,'marker','s','markersize',15,...
                'markeredgecolor',[0.9 0.2 0.1],'markerfacecolor',[0.9 0.2 0.1]);      
%k6=plot(repmat(1200*Erpm(1)*prob_J(1)+1200*Erpm(2)*prob_J(2),1,10),'color',[0.9 0.2 0.1],'linewidth',2,'linestyle','--');           
% kk=legend([k1,k2,k3],'US','Europe','Japan');
% set(kk,'location','north','orientation','horizontal');
% legend('boxoff');
xlabel('maturity')
xlim([1 10])
%ylim([6.3 8])
%ylim([0.9*min(min(1200*Prem)) 1.1*max(max(1200*Prem))])
% yticks([0.00 0.03 0.06])
% yticklabels({'0.00','0.03','0.06'})
title('$$E_t rx_{t+n}$$')