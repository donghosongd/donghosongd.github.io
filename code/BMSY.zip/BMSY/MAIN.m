clc;clear;

% calibration based on Table A-1 in the appendix
mu1    = 0.2/100;
mu2    = 0.1/100;
sigma1 = (0.6^2)*0.3/10000; % sqrt(sigma1) = sigma_x(1)
sigma2 = (0.9^2)*0.6/10000; % sqrt(sigma2) = sigma_x(2)

q11    = 0.9965;
q22    = 0.98;

phi    = 4; 
sigmaD = 3/10000;
L1     = 40*sqrt(sigma1); % lambda(1)
L2     = 40*sqrt(sigma2); % lambda(2)


L     = [L1;L2];
mu    = [mu1;mu2];
sig   = [sigma1;sigma2];
sigC  = [0.4/10000;0.4/10000];
sigD  = [sigmaD;sigmaD];
rho   = 0.5;

trans = [q11   1-q11;
         1-q22   q22];
[v,~] = eig(trans');
prob  = v/sum(v);
lrm   = reshape(prob,1,[])*mu;   

F0    = [lrm;lrm]; % [r(1);r(2)];
F1    = [0;0];


% solve the model
[Edgr,Strips,Ertrn,Prem,SRatio,Vdgr,Rvec,B0vec,Erpm,SRmkt,Strips1] = ReducedForm_solve(mu,sig,rho,sigC,F0,F1,trans,phi,sigD,L);

% generates FIGURE 1 in the paper
FIGURE

% simulation exercise
SIMULATE

% generates FIGURE 2 in the paper
FIGURE_SIMULATE



