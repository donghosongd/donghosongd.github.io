function [diff, k0, k1] = zd_bar(x,mu,sig,rho,sigC,F0,F1,trans,lambda,sigD,L)

% transition matrix
[v,~] = eig(trans);
prob  = v/sum(v);
lrm   = reshape(prob,1,[])*mu;   

k1 = exp(x)/(1+exp(x));
k0 = log(1+exp(x))-k1*x;

nS = size(trans,1);
%% Z(t) = A0(S_t) 

A1    = inv(eye(nS)-k1*rho*trans)*(lambda-F1)*rho;

tempR = [k0 + (1-lambda)*lrm - F0(1) + lambda*mu(1) + 0.5*lambda^2*sigC(1) + 0.5*sigD(1)...
        + 0.5*(k1*A1(1) - F1(1) + lambda)^2*sig(1) - (k1*A1(1) - F1(1) + lambda)*sqrt(sig(1))*L(1);
         k0 + (1-lambda)*lrm - F0(2) + lambda*mu(2) + 0.5*lambda^2*sigC(2) + 0.5*sigD(2)...
        + 0.5*(k1*A1(2) - F1(2) + lambda)^2*sig(2) - (k1*A1(2) - F1(2) + lambda)*sqrt(sig(2))*L(2)];

A0    = inv(eye(nS)-k1*trans)*tempR;  
diff = x - reshape(prob,1,[])*reshape(A0,[],1); 


