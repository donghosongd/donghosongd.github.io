
nT     = 12*8;
nsim   = 10000;
svec   = zeros(nsim,nT);
premvec   = zeros(nsim,nT,10);
edgrvec   = zeros(nsim,nT,10);
stripsvec = zeros(nsim,nT,10);
ertrnvec  = zeros(nsim,nT,10);

FMstrips = zeros(nsim,10);
SMstrips = zeros(nsim,10);

FMstrips1 = zeros(nsim,10);
SMstrips1 = zeros(nsim,10);

FMstrips2 = zeros(nsim,10);
SMstrips2 = zeros(nsim,10);


Cvec   = zeros(nsim,nT/12-1);
Dvec   = zeros(nsim,nT/12-1);

Cstat  = zeros(nsim,3);
Dstat  = zeros(nsim,3);

mu1    = 0.2/100;
mu2    = 0.1/100;
sigma1 = (0.6^2)*0.3/10000; % sqrt(sigma1) = sigma_x(1)
sigma2 = (0.9^2)*0.6/10000; % sqrt(sigma2) = sigma_x(2)

q11    = 0.9965;
q22    = 0.98;
lambda = 4;
sigmaD = 3/10000;
L1     = 40*sqrt(sigma1); % lambda(1)
L2     = 40*sqrt(sigma2); % lambda(2)

L     = [L1;L2];
mu    = [mu1;mu2];
sig   = [sigma1;sigma2];
sigC  = [0.4/10000;0.4/10000];
sigD  = [sigmaD;sigmaD];
rho   = 0.5;

trans = [q11   1-q11;
         1-q22   q22];
[v,~] = eig(trans');
prob  = v/sum(v);
lrm   = reshape(prob,1,[])*mu;   

F0    = [lrm;lrm]; % [r(1);r(2)];
F1    = [0;0];




[Edgr,Strips,Ertrn,Prem,SRatio,Vdgr,R0vec,B0vec,Erpm,SRmkt,Strips1] = ReducedForm_solve(mu,sig,rho,sigC,F0,F1,trans,phi,sigD,L);


P     = trans';    
P_cum = cumsum(P,1);
ns    = size(P,1);
agg_coeff = ([[1:1:12] 12-[1:1:11]]/12);
xit_1 = 2;

for jj=1:nsim
    if mod(jj,500)==0        
    disp('                                                         ');
    disp(['  POSTERIOR DRAWS:   ',     num2str(jj)]                 );
    disp('                                                         ');
    disp(['  REMAINING DRAWS:   ',     num2str(nsim-jj)]            );
    disp('                                                         ');  
    end    

    
    Xdata = zeros(nT,1);
    Ydata = zeros(nT,2);
    
    for ti=1:nT
        %--- Generating exogenous regimes.
        sdraw = rand;
        for si=1:ns
            if (sdraw<P_cum(si,xit_1))
                xit = si;
                break;
            end
        end
        
        if ti>1
            Xdata(ti,:)   = rho*Xdata(ti-1,:) + mvnrnd(0,sig(xit));
        else
            Xdata(ti,:)   = mvnrnd(0,sig(xit))/(1-rho^2);
        end
        Ydata(ti,1)   = mu(xit) + Xdata(ti,:) + mvnrnd(0,sigC(xit));
        Ydata(ti,2)   = lrm + phi*(Ydata(ti,1)-lrm) + sqrt(sigD(xit))*randn;
        
        
        svec(jj,ti)        = xit;
        premvec(jj,ti,:)   = 1200*Prem([12*[1:10]],xit);
        edgrvec(jj,ti,:)   = 1200*Edgr([12*[1:10]],xit);
        stripsvec(jj,ti,:) = 1200*Strips([12*[1:10]],xit) + 1200*Strips1([12*[1:10]],xit)*Xdata(ti);
        ertrnvec(jj,ti,:)  = 1200*Ertrn([12*[1:10]],xit);
        
        %--- Reset for the next period.
        xit_1 = xit;
    end
    
    FMstrips(jj,:) = mean(squeeze(stripsvec(jj,:,:)));
    SMstrips(jj,:) = std(squeeze(stripsvec(jj,:,:)));
    
    FMstrips1(jj,:) = nanmean(squeeze(stripsvec(jj,svec(jj,:)==1,:)));
    SMstrips1(jj,:) = nanstd(squeeze(stripsvec(jj,svec(jj,:)==1,:)));
    
    FMstrips2(jj,:) = nanmean(squeeze(stripsvec(jj,svec(jj,:)==2,:)));
    SMstrips2(jj,:) = nanstd(squeeze(stripsvec(jj,svec(jj,:)==2,:)));
    

% time aggregation
for t=2:nT/12
    Cvec(jj,t-1) = Ydata(12*(t-2)+2:12*t,1)'*agg_coeff';
    Dvec(jj,t-1) = Ydata(12*(t-2)+2:12*t,2)'*agg_coeff'; 
end

Cstat(jj,1) = mean(Cvec(jj,:))*100;
Cstat(jj,2) = std(Cvec(jj,:))*100;
Cstat(jj,3) = autocorr(Cvec(jj,:),1)*[0;1];

Dstat(jj,1) = mean(Dvec(jj,:))*100;
Dstat(jj,2) = std(Dvec(jj,:))*100;
Dstat(jj,3) = autocorr(Dvec(jj,:),1)*[0;1];
end

[quantile(Cstat,0.05)' quantile(Cstat,0.5)' quantile(Cstat,0.95)']
[quantile(Dstat,0.05)' quantile(Dstat,0.5)' quantile(Dstat,0.95)']










