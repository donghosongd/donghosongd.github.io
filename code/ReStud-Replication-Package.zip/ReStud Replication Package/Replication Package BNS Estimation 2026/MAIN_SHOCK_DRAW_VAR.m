clc;clear;close all


path('data',path)
path('estimation files VAR',path)
path('max-share identification files',path)
path('results',path)
% path('toolbox_BCA',path)

% Settings: Shock identification (i.e. Angeletos et al., 2020)
maxhor  = 200;    % Maximal horizon when testing for LR effects
nrep    = 40;     % Number of periods 
test    = 1;      % Testing period for the IRF
grid    = 1024;
alpha   = 68;     % Highest posterior density interval (HPDI)

est_case = 2;     % 2 for MN, 3 for MN-LR

% HP: BC freq. correspond to *all* frequencies of latent cyclical components)
idcase = 2;

if idcase ==1

wmin    = 2*pi/32;    % lowest frequency to consider 
wmax    = 2*pi/6 ;    % highest frequency to consider

elseif idcase == 2

wmin    = 2*pi/32;    % lowest frequency to consider 
wmax    = 2*pi/6 ;    % highest frequency to consider

elseif idcase == 3

wmin    = 2*pi/50;    % lowest frequency to consider 
wmax    = 2*pi/16 ;    % highest frequency to consider

elseif idcase == 4

wmin    = 2*pi/50;    % lowest frequency to consider 
wmax    = 2*pi/32;    % highest frequency to consider

end


all     = 0; % If 1, reports both eigenvalues and eigenvectors. 
             % If 0, only eigenvectors (corresponding to vector 'q' in paper).                    

Idv     = [1,2,3,4,5,6,7];  % index of Variable (in the estimated TC-VAR) for which we maximize the variance contribution 
                          % Assume that instead of looking at Y in isolation, you want to maximize over Y and unempl at the same time. 
                          % Then Idv would look like Idv=[[1,2],2,3,4,5,6] 
ncase   = length(Idv);

% load/convert data
load_data_unr_spf
str        = str_ind(:,select);          % Order labels to {Y,U,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}
y          = YY(20:end,[1 2 3 4 5 6 7]); % we use from 1960:Q1 onward (our data start from 1955:Q2)
lags       = 2;                          % n. of lags on the VAR
[T,n]      = size(y);

mn_case     = [0;1;-1];
IndPhi_case = [zeros(1,size(y,2));ones(1,size(y,2));-ones(1,size(y,2))];


    disp('                                                               ');
    disp(['                          CASES:   ', num2str(est_case)]        );
    disp('                                                               ');

    load(['results/estimation_var_', num2str(est_case), '.mat'],'Phi_var','Sig_var','DD_var','variables','y','spec');

    n       = size(y,2);
    p       = floor(size(Phi_var,2)/size(Phi_var,3));
    
    % burn initial draws
    nsim       = size(Phi_var,1);
    nburn      = nsim*0.25;
    skip       = 5;
    skip_ident = skip;
    grid_skip  = 1:skip:(nsim-nburn);
    grid_skip_ident = 1:skip_ident:(nsim-nburn)/skip;
    
    % after throwing initial draws, pick every `skip'th draw
    Phi_var    = Phi_var(nburn+1:nsim,:,:);
    Sig_var    = Sig_var(nburn+1:nsim,:,:);
    DD_var     = DD_var(nburn+1:nsim,:);
    Phi_var    = Phi_var(grid_skip,:,:);
    Sig_var    = Sig_var(grid_skip,:,:);
    DD_var     = DD_var(grid_skip,:);
    
    % to save time, pick every `skip_ident'th draw
    Phi_var_ident = Phi_var(grid_skip_ident,:,:);
    Sig_var_ident = Sig_var(grid_skip_ident,:,:);
    DD_var_ident  = DD_var(grid_skip_ident,:);

    nvar    = n;
    Ident   = eye(nvar);
    MYtmp   = [eye(nvar) zeros(nvar,nvar*(p-1))];
    MY      = MYtmp(1:nvar,:);
    ny      = size(MY,1);
    

    % Storage:
    MYvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar,nvar*p);       % measurement eq;
    MDvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar*p);            % measurement eq;
    MXvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar*p,nvar*p);     % transition eq;
    MEvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar*p,nvar);       % transition eq;
  
    disp('                                                               ');
    disp('                          SHOCK IDENTIFICATION BEGINS          ');
    ii      = 1;
    tic
    for im = ii:(nsim-nburn)/(skip*skip_ident)
        
        % 1) Build the state space representation of the VAR for draw i;
        S     = chol(squeeze(Sig_var_ident(im,:,:)))'; %reshape(tmp,nvar,nvar)
        tmp   = squeeze(Phi_var_ident(im,:,:))';   %reshape(COEFS(i,:)',nvar*lags,nvar)';
        MD    = DD_var_ident(im,:)';
        DYN   = tmp(:,1:nvar*p);
        MX    = [DYN;eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)];
        nx    = size(MX,1);
        ME    = [S;zeros(nvar*(p-1),nvar)];
    
        modvar.mx = MX;
        modvar.my = MY;
        modvar.me = ME;
    
        % 2) Compute IRFs and cumulative squared IRFs from Choleski decomposition;
        Itmp1 = zeros(nrep*ny,nvar);    % IRFs: column k stacks the IRFs (up to horizon nrep) of all variables to a shock to variable k
        Itmp2 = zeros(ny,nvar);         % IRF at the test horizon (used to fix the sign): column k stacks the period-'test' IRF of all variables to a shock to variable k
        Itmp3 = zeros(maxhor*ny,nvar);  % same as Itmp1 but for horizons up to maxhor
        for k = 1:nvar
            tmp        = comp_irf(modvar,k,maxhor);  
            ttmp       = tmp.y(1:nrep,:);           % tmp.y: each column is the IRF (up to maxhor) of one variable to a shock to variable k
            Itmp1(:,k) = (ttmp(:));
            Itmp2(:,k) = tmp.y(test,:)';
            vtmp       = tmp.y(1:maxhor,:);
            Itmp3(:,k) = (vtmp(:));
        end
        % 3) Computes the MBC shock, then the IRFs, FEV and variance decomposition to this shock;
        QQ = zeros(nvar,ncase);
        ic = 2;
        idx             = Idv(ic);
        nidx            = size(idx,1)*size(idx,2); 
        weight          = ones(1,nidx)/nidx;  % weight to assign to each variable when trying to maximize other several variables.  

        Q               = func_fdq(modvar,S,wmin,wmax,idx,weight,grid,all); % Computes the MBC shock targeting each case ic

        sgn             = sign((Itmp2(idx(1),:)*Q));   
        IRFsr(im,:)     = sgn*(Itmp1*Q);     
    
        q1              = sgn*Q;                 % identified shock vector (n x 1)
        q1              = q1 / norm(q1);         % normalize to unit length
        N               = null(q1.');            % orthonormal basis for the orthogonal complement (n x (n-1))
        Qfull           = [q1, N];               % columns are orthonormal by construction: We only care about the first column shock
    
        MYs             = MY;
        MXs             = MX;
        MEs             = [S*Qfull;zeros(nvar*(p-1),nvar)];
    
        MYvec(im,:,:)   = MYs;
        MXvec(im,:,:)   = MXs;
        MEvec(im,:,:)   = MEs;
        MDvec(im,:)     = MD;
        
    
        if mod(im,100)==0
            disp('                                                               ');
            disp('                                                               ');
            disp(['                          DRAW NUMBER:   ', num2str(im)]        );
            disp('                                                               ');
            disp(['                          REMAINING DRAWS:   ',num2str((nsim-nburn)/(skip*skip_ident))]);
            disp('                                                               ');
            disp(['                          ELAPPSED TIME:   ',num2str(floor(toc)), ' SEC']);
            disp('                                                               ');
        end
    
    
    end



shock_vec      = zeros((nsim-nburn)/(skip*skip_ident),T);
shock_full_vec = zeros((nsim-nburn)/(skip*skip_ident),T,7);
init0_vec      = zeros((nsim-nburn)/(skip*skip_ident),21);

for jj=1:(nsim-nburn)/(skip*skip_ident)
    if mod(jj,100)==0
    disp(['                          DRAW NUMBER:   ', num2str(jj)]        );
    disp('                                                               ');
    end
    [~,~,At_draw] = KFKS_var(y,squeeze(MYvec(jj,:,:)),squeeze(MDvec(jj,:)),squeeze(MXvec(jj,:,:)),squeeze(MEvec(jj,:,:)));
    shock_vec(jj,:)        = At_draw(:,nvar*p+1);
    shock_full_vec(jj,:,:) = At_draw(:,nvar*p+1:nvar*p+nvar);
    init0_vec(jj,:)        = At_draw(1,:);
end

save(['results/ushock_var_', num2str(est_case), '_', num2str(idcase),'.mat'],'Phi_var','Sig_var','DD_var','variables','y','spec',...
        'MYvec','MXvec','MEvec','MDvec','shock_vec','shock_full_vec','init0_vec');