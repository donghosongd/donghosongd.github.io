
load('data_1955_2019.mat');  
time_data   = X_19(:,1);
data        = X_19(:,2:11);
str         = {' Output',' Investment',' Consumption',' Hours Worked',' Unemployment',' Labor Share',...
               ' Nom. Int. Rate',' Inflation',' Labor Prod.',' TFP'};

% Group first-diff stationary data in levels as first block
% {Y, I , C , h , Lab Sh , Y/h , TFP, u , R , pi}
ind      = [1:4 6 9 10 5 7 8];
data_ind = data(:, ind);
str_ind  = str(:,ind);

% Add PGDP Infl.Exp 4q-ahead
load('data_infl_exp_19.mat');
data_ind = [data_ind infl_exp_4q_19(find(infl_exp_dates_19 == 1955.00):find(infl_exp_dates_19 == 2019.75))]; 
str_ind(end+1) = {' Infl.Exp.4q'};

% Add Adjusted CPI Infl.Exp 40q-ahead
data_ind = [data_ind infl_exp_40q_19(find(infl_exp_dates_19 == 1955.00):find(infl_exp_dates_19 == 2019.75))];
str_ind(end+1) = {' Infl.Exp.40q'};

% Add UnR.Exp 4q-ahead
load('data_unr_exp_19.mat');
data_ind = [data_ind (unr_exp_4q_19(find(unr_exp_dates_19 == 1955.00):find(unr_exp_dates_19 == 2019.75)))];
str_ind(end+1) = {' UnR.Exp.4q'};

% convert to first-diff data
ndiff  = 7; % The first 'ndiff' variables are first-differenced, while the others are left unchanged.
Y0     = [diff(data_ind(:,1:ndiff)) data_ind(2:end,ndiff+1:end)];
time   = time_data(2:end);

select = [1 8 9 10 11 12 13]; % {Y,UnR,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}
Y1     = Y0(:,select);

% remove zlb data for interest rates
zlb    = Y1(:,3)<0.05;
Y1(zlb==1,3) = nan;

% GDP gr, UNR, FFR, INF, ExpINF+1Q, ExpINF+10y
YY      = 4*Y1;     % annualize
YY(:,[2 7]) = Y1(:,[2 7]);  % UNR was already annualized




