clear
close all
clc

path('figure',path)
path('other files',path)
path('max-share identification files',path)
path('results',path)

summarize_shocks_TCVAR_cyc2all_1_APPX_Figure_1;