clc;clear;close all

path('data',path)
path('estimation files',path)
path('figure',path)
path('forecasting results',path)
% path('gauss files',path)
path('max-share identification files',path)
path('other files',path)
path('results',path)

% Settings: Shock identification (i.e. Angeletos et al., 2020)
maxhor  = 200;    % Maximal horizon when testing for LR effects
nrep    = 40;     % Number of periods 
test    = 1;      % Testing period for the IRF
grid    = 1024;
alpha   = 68;     % Highest posterior density interval (HPDI)

idpick  = 2;      % 1 is targeting observed, 2 is targeting cyclical unrate

all     = 0; % If 1, reports both eigenvalues and eigenvectors. 
             % If 0, only eigenvectors (corresponding to vector 'q' in paper).                    

Idv     = [1,2,3,4,5,6];  % index of Variable (in the estimated TC-VAR) for which we maximize the variance contribution 
                          % Assume that instead of looking at Y in isolation, you want to maximize over Y and unempl at the same time. 
                          % Then Idv would look like Idv=[[1,2],2,3,4,5,6] 
ncase   = length(Idv);

% load estimation results
corr    = 1;
stdcorr = 0.1;

load(['results/estimation_tcvar_', num2str(corr),'_', num2str(stdcorr),  '.mat'])

% for table
specif_tvar   = 'TCvar_';

% burn initial draws
nsim       = size(Phi_var,1);
nburn      = nsim*0.25;
skip       = 5;
skip_ident = skip;
grid_skip  = 1:skip:(nsim-nburn);
grid_skip_ident = 1:skip_ident:(nsim-nburn)/skip;

% after throwing initial draws, pick every `skip'th draw
Phi_var    = Phi_var(nburn+1:nsim,:,:);
Sig_var    = Sig_var(nburn+1:nsim,:,:);
para_trend = para_trend(nburn+1:nsim,:);
Phi_var    = Phi_var(grid_skip,:,:);
Sig_var    = Sig_var(grid_skip,:,:);
para_trend = para_trend(grid_skip,:);
Y_trend    = Y_trend(nburn+1:nsim,:,:);
Y_trend    = Y_trend(grid_skip,:,:);
Y_cycle    = Y_cycle(nburn+1:nsim,:,:);
Y_cycle    = Y_cycle(grid_skip,:,:);

% to save time, pick every `skip_ident'th draw
Phi_var_ident    = Phi_var(grid_skip_ident,:,:);
Sig_var_ident    = Sig_var(grid_skip_ident,:,:);
Y_trend_ident    = Y_trend(grid_skip_ident,:,:);
Y_cycle_ident    = Y_cycle(grid_skip_ident,:,:);
para_trend_ident = para_trend(grid_skip_ident,:,:);

% restoring observables in the estimation
Z1 = [1 0 0 0 1 0 0 0 0 0 -1 0 0 0 0 0
    0 1 0 0 0 1 0 0 0 0  0 0 0 0 0 0
    0 0 1 1 0 0 1 0 0 0  0 0 0 0 0 0
    0 0 0 1 0 0 0 1 0 0  0 0 0 0 0 0
    0 0 0 1 0 0 0 0 1 0  0 0 0 0 0 0
    0 1 0 0 0 0 0 0 0 1  0 0 0 0 0 0];
% cyclical components
Z2 = [0 0 0 0 1 0 0 0 0 0  0 0 0 0 0 0
    0 0 0 0 0 1 0 0 0 0  0 0 0 0 0 0
    0 0 0 0 0 0 1 0 0 0  0 0 0 0 0 0
    0 0 0 0 0 0 0 1 0 0  0 0 0 0 0 0
    0 0 0 0 0 0 0 0 1 0  0 0 0 0 0 0
    0 0 0 0 0 0 0 0 0 1  0 0 0 0 0 0];

if idpick==1
    % HP: BC freq. correspond to *all* frequencies of latent cyclical components)
    wmin    = 2*pi/32;    % lowest frequency to consider
    wmax    = 2*pi/6 ;    % highest frequency to consider
    MY      = Z1;
elseif idpick==2
    % HP: BC freq. correspond to *all* frequencies of latent cyclical components)
    wmin    = 0;        % lowest frequency to consider
    wmax    = 2*pi;     % highest frequency to consider
    MY      = Z2;
elseif idpick==3
    % HP: BC freq. correspond to *all* frequencies of latent cyclical components)
    wmin    = 2*pi/50;    % lowest frequency to consider
    wmax    = 2*pi/16;    % highest frequency to consider
    MY      = Z1;
elseif idpick==4
    % HP: BC freq. correspond to *all* frequencies of latent cyclical components)
    wmin    = 2*pi/50;    % lowest frequency to consider
    wmax    = 2*pi/32;    % highest frequency to consider
    MY      = Z1;
end

% re-define variables
ny      = size(MY,1);      % number of observables
nvar    = size(Y_cycle,3); % number of cyclical components
p       = spec.nlags;      % number of lags
ntn     = 4;               % number of trend components
ne      = size(Sig_var,2); % number of shocks
Ident   = eye(nvar);
HH      = 40;

% require VAR parameters (Phi_var & Sig_var) and measurement equation parameter MY
rMYvec  = zeros((nsim-nburn)/(skip*skip_ident),nvar,ntn+nvar*p);       % measurement eq;
MYvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar,ntn+nvar*p);       % measurement eq;
MXvec   = zeros((nsim-nburn)/(skip*skip_ident),ntn+nvar*p,ntn+nvar*p); % transition eq;
MEvec   = zeros((nsim-nburn)/(skip*skip_ident),ntn+nvar*p,ne);         % transition eq;
IRvec   = zeros((nsim-nburn)/(skip*skip_ident),nvar,HH); 
IRvecC  = zeros((nsim-nburn)/(skip*skip_ident),nvar,HH); 
IRFsr   = zeros((nsim-nburn)/(skip*skip_ident),ny*nrep);     % contains IRFs;


disp('                                                               ');
disp('                          SHOCK IDENTIFICATION BEGINS          ');
ii      = 1;
tic
for im = ii:(nsim-nburn)/(skip*skip_ident)

    
    % 1) Build the state space representation for draw i;
    S     = chol(squeeze(Sig_var_ident(im,:,:)))'; 
    tmp   = squeeze(Phi_var_ident(im,:,:))';      
    DYN   = tmp(:,1:nvar*p);   % drop constant if exists
    MX    = blkdiag(eye(ntn),[DYN;eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]);
    MX(1,1) = para_trend_ident(im,2);  % replacing persistence estimate
    nx    = size(MX,1);
    ME    = [S;zeros(nx-nvar-ntn,ne)];

    modvar.mx = MX;
    modvar.my = MY;
    modvar.me = ME;

    % 2) Compute IRFs and cumulative squared IRFs from Choleski decomposition;
    Itmp1 = zeros(nrep*ny,ne);    % IRFs: column k stacks the IRFs (up to horizon nrep) of all variables to a shock to variable k
    Itmp2 = zeros(ny,ne);         % IRF at the test horizon (used to fix the sign): column k stacks the period-'test' IRF of all variables to a shock to variable k
    Itmp3 = zeros(maxhor*ny,ne);  % same as Itmp1 but for horizons up to maxhor
    for k = 1:ne
        tmp        = comp_irf(modvar,k,maxhor);  
        ttmp       = tmp.y(1:nrep,:);           % tmp.y: each column is the IRF (up to maxhor) of one variable to a shock to variable k
        Itmp1(:,k) = (ttmp(:));
        Itmp2(:,k) = tmp.y(test,:)';
        vtmp       = tmp.y(1:maxhor,:);
        Itmp3(:,k) = (vtmp(:));
    end
    % 3) Computes the MBC shock, then the IRFs, FEV and variance decomposition to this shock;
    QQ=zeros(nvar,ncase);
    ic = 2;
    idx             = Idv(ic);
    nidx            = size(idx,1)*size(idx,2); 
    weight          = ones(1,nidx)/nidx;  % weight to assign to each variable when trying to maximize other several variables.  

    Q               = func_fdq(modvar,S,wmin,wmax,idx,weight,grid,all); % Computes the MBC shock targeting each case ic

    sgn             = sign((Itmp2(idx(1),:)*Q));   
    IRFsr(im,:)     = sgn*(Itmp1*Q);     

    q1              = sgn*Q;                 % identified shock vector (n x 1)
    q1              = q1 / norm(q1);         % normalize to unit length
    N               = null(q1.');            % orthonormal basis for the orthogonal complement (n x (n-1))
    Qfull           = [q1, N];               % columns are orthonormal by construction: We only care about the first column shock

    MYs             = MY;
    MXs             = MX;
    MEs             = [S*Qfull;zeros(nx-nvar-ntn,ne)];

    rMYvec(im,:,:)  = Z1;
    MYvec(im,:,:)   = MYs;
    MXvec(im,:,:)   = MXs;
    MEvec(im,:,:)   = MEs;

    if mod(im,100)==0
        disp('                                                               ');
        disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(corr)]);
        disp(['                          CORR STD :   ', num2str(stdcorr)]);
        disp(['                          DRAW NUMBER:   ', num2str(im)]        );
        disp(['                          Full DRAWS:   ',num2str((nsim-nburn)/(skip*skip_ident))]);
        disp(['                          ELAPPSED TIME:   ',num2str(floor(toc)), ' SEC']);
        disp('                                                               ');
    end

    pick = zeros(ne,1); pick(1) = 1;
    
    for h=1:HH
        IRvec(im,:,h)  = MYs*MXs^(h-1)*MEs*pick;
        IRvecC(im,:,h) = Z2*MXs^(h-1)*MEs*pick;
    end
end


%% estimation 

% load/convert data
load_data_unr_spf
str = str_ind(:,select); % Order labels to {Y,U,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}

% specification
H          = 20;
n          = 6;
p          = 2;
n0         = 1;   % obs 1  - 1955:Q2
n1         = 19;  % obs 19 - 1959:Q4
Ypre       = YY(n0:n1,:);

% pre-sample moments
pMN        = mean(Ypre(:,[1 2 3 4]));
pMN(:,3)   = mean(Ypre(:,3)-Ypre(:,4));
pSD        = nanstd(Ypre(:,[1 2 3 4]));

% add moments for survey measures which aren't available
pMN(5)     = pMN(4); pSD(5)     = pSD(4);
pMN(6)     = pMN(2); pSD(6)     = pSD(2);

b0         = zeros(n*p,n);  
d          = n+2;
Psi        = (pSD).^2; 
dtr        = 100;
Psitr      = [1/40  1/40  1/20  1/20]'; 

delta_mean = 0.0;
delta_var  = 0.1;
deltaT     = 10;
deltaV     = 0.1;

YYY        = YY(n1+1:end,:);
time       = time(n1+1:end);
[T,nv]     = size(YYY);

rslt       = [1 2 3 4 5 7];
YYY        = YYY(:,rslt);
str        = str(rslt);

shock_vec      = zeros((nsim-nburn)/(skip*skip_ident),T);
init0_vec      = zeros((nsim-nburn)/(skip*skip_ident),size(MXvec,3)+size(MEvec,3));
shock_full_vec = zeros((nsim-nburn)/(skip*skip_ident),T,size(MEvec,3));


for jj=1:(nsim-nburn)/(skip*skip_ident)
    if mod(jj,100)==0
    disp(['                          DRAW NUMBER:   ', num2str(jj)]        );
    disp('                                                               ');
    end

    if isequal(MY,Z2)
    [~,~,At_draw] = KFKS(squeeze(Y_cycle_ident(jj,:,:)),squeeze(MYvec(jj,:,:)),squeeze(MXvec(jj,:,:)),squeeze(MEvec(jj,:,:)),squeeze(Y_trend_ident(jj,1,:)));
    else
    [~,~,At_draw] = KFKS(YYY,squeeze(MYvec(jj,:,:)),squeeze(MXvec(jj,:,:)),squeeze(MEvec(jj,:,:)),squeeze(Y_trend_ident(jj,1,:)));
    end
    shock_vec(jj,:)        = At_draw(:,size(MXs,1)+1);
    shock_full_vec(jj,:,:) = At_draw(:,size(MXs,1)+1:size(MXs,1)+10);
    init0_vec(jj,:)        = At_draw(1,:);
end

save(['results/ushock_tcvar_', num2str(idpick),  '.mat'],...
        'MYvec','rMYvec','MXvec','MEvec','shock_vec','shock_full_vec','init0_vec','YYY','Y_trend_ident','Y_cycle_ident','wmin','wmax')


