clear
close all
clc

path('figure',path)
path('other files',path)
path('max-share identification files',path)
path('results',path)

summarize_shocks_var_2_Figure_5;