clc;clear

path('data',path)
path('estimation files VAR',path)
path('forecasting results',path)

% Seed rng
rng(1234567890)

% Loading the data
load('data_1955_2019.mat');  
time_data   = X_19(:,1);
data        = X_19(find(time_data== 1955.25):find(time_data==2019.75),2:11);
time_data   = time_data(find(time_data== 1955.25):find(time_data==2019.75),1);

str         = {' Output',' Investment',' Consumption',' Hours Worked',' Unemployment',' Labor Share',...
               ' Nom. Int. Rate',' Inflation',' Labor Prod.',' TFP'};

YY          = data;
order       = [1 2 3 5 4 10 6 8 7 9];
y           = YY(:,order);
variables   = str(order);
n           = length(variables);

spec        = [];
spec.lags   = 2;     % number of lags on the VAR
spec.nsim   = 10000; % number of posterior draws

for est_case=2:3
    
    % Defines the matrix with the linear transformations used to elicit the Long Run Prior
    %     Y   I   C   u   H  TFP wh/Y \pi  R  Y-H
spec.H = [
          1   1   1   0   0   0   0    0   0   0;  %Y+C+I
         -1   1   0   0   0   0   0    0   0   0;  %I-Y
         -1   0   1   0   0   0   0    0   0   0;  %C-Y
          0   0   0   1   0   0   0    0   0   0;  %u
          0   0   0   0   1   0   0    0   0   0;  %H
          0   0   0   0   0   1   0    0   0   0;  %TFP
          0   0   0   0   0   0   1    0   0   0;  %wh/Y
          0   0   0   0   0   0   0    1   1   0;  %\pi + R
          0   0   0   0   0   0   0   -1   1   0;  %R-\pi 
          1   0   0   0  -1   0   0    0   0  -1]; %Y-H-(Y-H) 

    if est_case==1
        % no prior
        spec.mn         = 0;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==2
        % optimize MN prior
        spec.mn         = 1;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==3
        % optimize MN+PLR prior
        spec.mn         = 1;
        spec.IndPhi     = ones(1,n);
        spec.SinglePhi  = 0;
    end

    % initialize
    spec.Phi        = zeros(1+n*spec.lags,n);
    % residual variance of AR(1) for each variable
    spec.Sig        = fitARmodel(y);
    % forecast horizon
    HH              = 12;

    nStart          = find(time_data==2000);
    nEnd            = find(time_data==2019.75)-HH;
    YYpred_var      = zeros(nEnd-nStart+1,HH,n);
    EEpred_var      = zeros(nEnd-nStart+1,HH,n);
    MSE_var         = zeros(nEnd-nStart+1,HH,n);
    YF_var          = zeros(nEnd-nStart+1,HH,n);
    jsim            = 100;
    j_ind           = 1:floor(spec.nsim/jsim):spec.nsim;
    EE_var1         = zeros(nEnd-nStart+1,jsim,HH);
    EE_var2         = zeros(nEnd-nStart+1,jsim,HH);
    EE_var3         = zeros(nEnd-nStart+1,jsim,HH);
    EE_var4         = zeros(nEnd-nStart+1,jsim,HH);

    for estE   = nStart:nEnd
    
    disp('                                                               ');
    disp(['                          RECURSIVE SAMPLE:   ', num2str(estE-nStart+1)]        );
    disp('                                                               ');
    disp(['                          TOTAL SAMPLE:   ',num2str(nEnd-nStart+1)]);

    % recursive sample
    yy = YY(20:estE,order); % we use from 1960:Q1 onward (our data start from 1955:Q2)
    yf = YY(estE+1:estE+HH,order);

    % Gibbs sampler
    [Phi_var,Sig_var,PHIF_var,DD_var,Y_var,PHIFpm_var,DDpm_var,XX_var] = Gibbs(yy,spec,est_case);

    % store
    YYpred = zeros(spec.nsim,HH,n);
    EEpred = zeros(spec.nsim,HH,size(Sig_var,2));
    XXpred = zeros(spec.nsim,HH,size(XX_var,2));

    for ii=1:spec.nsim
        DD   = DD_var(ii,:)';
        PHIF = squeeze(PHIF_var(ii,:,:));
        SIG  = squeeze(Sig_var(ii,:,:));
        RR   = zeros(size(PHIF,1),size(SIG,2));
        RR(1:size(SIG,1),:) = eye(size(SIG,1));
        ZZ   = zeros(n,size(PHIF,1));
        ZZ(:,1:n) = eye(n);

        for hh=1:HH
            EEpred(ii,hh,:) = chol(SIG)'*randn(size(SIG,1),1);
            if hh>1
                XXpred(ii,hh,:) = (DD + PHIF*squeeze(XXpred(ii,hh-1,:)) + RR*squeeze(EEpred(ii,hh,:)))';
            else
                XXpred(ii,hh,:) = (DD + PHIF*XX_var(ii,:)' + RR*squeeze(EEpred(ii,hh,:)))';
            end
            YYpred(ii,hh,:) = ZZ*squeeze(XXpred(ii,hh,:));
        end
    end

    YYpred_var(estE-nStart+1,:,:) = squeeze(median(YYpred));
    EEpred_var(estE-nStart+1,:,:) = yf-squeeze(median(YYpred));
    MSE_var(estE-nStart+1,:,:)    = (yf-squeeze(median(YYpred))).^2;
    YF_var(estE-nStart+1,:,:)     = yf;

    EE_var1(estE-nStart+1,:,:)    = repmat(yf(:,1)',jsim,1)-squeeze(YYpred(j_ind,:,1));
    EE_var2(estE-nStart+1,:,:)    = repmat(yf(:,2)',jsim,1)-squeeze(YYpred(j_ind,:,2));
    EE_var3(estE-nStart+1,:,:)    = repmat(yf(:,3)',jsim,1)-squeeze(YYpred(j_ind,:,3));
    EE_var4(estE-nStart+1,:,:)    = repmat(yf(:,4)',jsim,1)-squeeze(YYpred(j_ind,:,4));


    end

    save(['forecasting results/forecast_var_aer_', num2str(estE-nStart+1), '_', num2str(est_case), '.mat'],...
        'EEpred_var','YYpred_var','MSE_var','EE_var1','EE_var2','EE_var3','EE_var4','YF_var','spec');


end


