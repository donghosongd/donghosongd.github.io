clc;clear;close all

path('data',path)
path('estimation files',path)
path('figure',path)
path('forecasting results',path)
path('max-share identification files',path)
path('other files',path)
path('results',path)

% 1 is targeting observed, 6-32 qts
% 2 is targeting cyclical unrate, 0-inf qts
% 3 is targeting observed, 16-50 qts
% 4 is targeting observed, 32-50 qts

idshock = 2; 

%% VAR results
est_case = 2; % 2 for MN, 3 for MN-LR
load(['results/ushock_var_', num2str(est_case), '_', num2str(idshock),'.mat'],'variables','y','spec',...
        'MYvec','MXvec','MEvec','MDvec','shock_vec','shock_full_vec','init0_vec');

MYvec_var = MYvec;
MXvec_var = MXvec;
MEvec_var = MEvec;
YYY_var   = y;
vname_var = variables;
init_vec_var = init0_vec;
shock_vec_var = shock_vec;
shock_full_vec_var = shock_full_vec;

[nsim_var,nT_var] = size(shock_vec_var);
nX_var = size(MXvec_var,3)+1;
nY_var = size(MYvec_var,2);
nE_var = size(MEvec_var,3);

x_vec_var    = zeros(nsim_var,nT_var,nX_var);
y_vec_var    = zeros(nsim_var,nT_var,nY_var);
e_vec_var    = zeros(nsim_var,nT_var,nE_var);

x_vec_var_cf = zeros(nsim_var,nT_var,nX_var);
y_vec_var_cf = zeros(nsim_var,nT_var,nY_var);
e_vec_var_cf = zeros(nsim_var,nT_var,nE_var);


%% TC-VAR results
load(['results/ushock_tcvar_', num2str(idshock),  '.mat'],...
        'MYvec','rMYvec','MXvec','MEvec','shock_vec','shock_full_vec','init0_vec','YYY','Y_trend_ident','Y_cycle_ident')



[nsim,nT] = size(shock_vec);
nX = size(MXvec,3)+1;
nY = size(MYvec,2);
nE = size(MEvec,3);

x_vec    = zeros(nsim,nT,nX);
y_vec    = zeros(nsim,nT,nY);
e_vec    = zeros(nsim,nT,nE);

x_vec_cf = zeros(nsim,nT,nX);
y_vec_cf = zeros(nsim,nT,nY);
e_vec_cf = zeros(nsim,nT,nE);

for ii=1:nsim_var
    if mod(ii,100)==0
    disp(['                          DRAW NUMBER:   ', num2str(ii)]        );
    disp('                                                               ');
    end

    %x_vec_var(ii,1,:) = init_vec_var(ii,1:nX_var)';
    MX_var0     = squeeze(MXvec_var(ii,:,:));
    MY_var0     = squeeze(MYvec_var(ii,:,:));
    ME_var0     = squeeze(MEvec_var(ii,:,:));
    e1y_var     = zeros(1,size(MY_var0,1)); e1y_var(1,1) = 1;

    MX_var      = [MX_var0         zeros(size(MX_var0,1),1);
                   e1y_var*MY_var0*MX_var0  1];
    ME_var      = [ME_var0;
                   e1y_var*MY_var0*ME_var0];
    MY_var      = [MY_var0 zeros(size(MY_var0,1),1)]; MY_var(1,:) = 0; MY_var(1,end) = 1;

    for tt=1:nT_var
        e_vec_var(ii,tt,1)    = shock_vec_var(ii,tt);
        e_vec_var_cf(ii,tt,1) = shock_vec(ii,tt);

%        e_vec_var(ii,tt,:) = shock_full_vec_var(ii,tt,:);
        if tt>1
        x_vec_var(ii,tt,:)    = MX_var*squeeze(x_vec_var(ii,tt-1,:))   +ME_var*squeeze(e_vec_var(ii,tt,:));
        x_vec_var_cf(ii,tt,:) = MX_var*squeeze(x_vec_var_cf(ii,tt-1,:))+ME_var*squeeze(e_vec_var_cf(ii,tt,:));
        else
        x_vec_var(ii,tt,:)    = ME_var*squeeze(e_vec_var(ii,tt,:));
        x_vec_var_cf(ii,tt,:) = ME_var*squeeze(e_vec_var_cf(ii,tt,:));
        end
        y_vec_var(ii,tt,:)    = MY_var*squeeze(x_vec_var(ii,tt,:));
        y_vec_var_cf(ii,tt,:) = MY_var*squeeze(x_vec_var_cf(ii,tt,:));
    end
end


for ii=1:nsim
    if mod(ii,100)==0
    disp(['                          DRAW NUMBER:   ', num2str(ii)]        );
    disp('                                                               ');
    end

    %x_vec(ii,1,:) = init0_vec(ii,1:nX)';
    MX0     = squeeze(MXvec(ii,:,:));
    MY0     = squeeze(rMYvec(ii,:,:));
    ME0     = squeeze(MEvec(ii,:,:));

    e1y     = zeros(1,size(MY0,1)); e1y(1,1) = 1;

    MX      = [MX0         zeros(size(MX0,1),1);
               e1y*MY0*MX0  1];
    ME      = [ME0;
               e1y*MY0*ME0];
    MY      = [MY0 zeros(size(MY0,1),1)]; MY(1,:) = 0; MY(1,end) = 1;

    for tt=1:nT
        e_vec(ii,tt,1)    = shock_vec(ii,tt);
        e_vec_cf(ii,tt,1) = shock_vec_var(ii,tt);

%        e_vec(ii,tt,:) = shock_full_vec(ii,tt,:);
        if tt>1
        x_vec(ii,tt,:)    = MX*squeeze(x_vec(ii,tt-1,:))   +ME*squeeze(e_vec(ii,tt,:));
        x_vec_cf(ii,tt,:) = MX*squeeze(x_vec_cf(ii,tt-1,:))+ME*squeeze(e_vec_cf(ii,tt,:));
        else
        x_vec(ii,tt,:)    = ME*squeeze(e_vec(ii,tt,:));
        x_vec_cf(ii,tt,:) = ME*squeeze(e_vec_cf(ii,tt,:));
        end
        y_vec(ii,tt,:)    = MY*squeeze(x_vec(ii,tt,:));
        y_vec_cf(ii,tt,:) = MY*squeeze(x_vec_cf(ii,tt,:));
    end
end


time = 1960:.25:2019.75;
vname = {'Output growth','Unemployment','Interest rate',...
    'Inflation','Inflation exp.','Unemployment exp.'};
cname = {'Output','Unemployment','Interest rate',...
    'Inflation','Inflation exp.','Unemployment exp.'};

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);

pickme    = [2 4];
ylim_all0 = [-4 5;
            -5 9];

ylim_all  = [-5.5 5;
            -6.5 9];

% 
% fig = figure('Position',[20,20,900,600],'Name',...
% 'Data','Color','w','Position',[1 scrsz(4)/20 scrsz(3)/2.0 scrsz(4)/2.5]);
fig = figure('Position',[1,44,2107,635],'Name',...
'Data','Color','w','OuterPosition',[0,38,2109,716]);
for jjj=1:2
    subplot(1,2,jjj)
    jj = pickme(jjj);
    hold on
    g1=shadedplot(time,quantile(y_vec(:,:,jj),0.05),quantile(y_vec(:,:,jj),0.95),[0.83 0.83 0.999],[0.83 0.83 0.999]);
    hold on
    if jj~=1
    g2=plot(time,YYY(:,jj)-nanmean(YYY(:,jj)),'Color',[1.0, 0.6, 0.2],'linewidth',2,'marker','s','markersize',8,...
    'MarkerIndices',1:3:length(time),'markerfacecolor',[1.0, 0.6, 0.2]);
    else
    g2=plot(time,quantile(Y_cycle_ident(:,:,jj),0.50),'Color',[1.0, 0.6, 0.2],'linewidth',2,'marker','s','markersize',8,...
    'MarkerIndices',1:3:length(time),'markerfacecolor',[1.0, 0.6, 0.2]);
    % plot(time,quantile(Y_cycle_ident(:,:,jj),0.05),'Color',[1.0, 0.6, 0.2],'LineWidth',1);
    % plot(time,quantile(Y_cycle_ident(:,:,jj),0.95),'Color',[1.0, 0.6, 0.2],'LineWidth',1);
    end
    g3=plot(time,quantile(y_vec(:,:,jj),0.50),'color',[0.5 0.5 0.9],'linewidth',3);

    rho = corr(quantile(y_vec(:,:,jj),0.50)',YYY(:,jj));
    gg=legend([g2,g3],'Data',sprintf('TC-VAR $(\\mathrm{Corr}_{\\mathrm{Data}}$ = %.2f)', rho), ...
            'location','southwest','interpreter','latex');legend('boxoff');
    ylim([ylim_all0(jjj,1) ylim_all0(jjj,2)])
    xlim([1960 2020])
    xticks(1960:20:2020);
    title(cname(jj))
end
print('-depsc2','figure/Figure_3_observables.eps');
exportgraphics(gcf, 'figure/Figure_3_observables.pdf', 'ContentType', 'vector');


pause(1)
% fig = figure('Position',[20,20,900,600],'Name',...
% 'Data','Color','w','Position',[1 scrsz(4)/20 scrsz(3)/2.0 scrsz(4)/2.5]);
fig = figure('Position',[1,44,2107,635],'Name',...
'Data','Color','w','OuterPosition',[0,38,2109,716]);
for jjj=1:2
    subplot(1,2,jjj)
    jj = pickme(jjj);
    hold on
    g1=shadedplot(time,quantile(y_vec(:,:,jj),0.05),quantile(y_vec(:,:,jj),0.95),[0.83 0.83 0.999],[0.83 0.83 0.999]);
    hold on
    g2=plot(time,quantile(Y_cycle_ident(:,:,jj),0.50),'Color',[1.0, 0.6, 0.2],'linewidth',2,'marker','s','markersize',8,...
    'MarkerIndices',1:3:length(time),'markerfacecolor',[1.0, 0.6, 0.2]);
    % g21=plot(time,quantile(Y_cycle_ident(:,:,jj),0.05),'Color',[1.0, 0.6, 0.2],'LineWidth',1,'linestyle','--');
    % g22=plot(time,quantile(Y_cycle_ident(:,:,jj),0.95),'Color',[1.0, 0.6, 0.2],'LineWidth',1,'linestyle','--');
    g3=plot(time,quantile(y_vec(:,:,jj),0.50),'color',[0.5 0.5 0.9],'linewidth',3);

    rho = corr(quantile(y_vec(:,:,jj),0.50)',quantile(Y_cycle_ident(:,:,jj),0.50)');
    gg=legend([g2,g3],'Cycle',sprintf('TC-VAR $(\\mathrm{Corr}_{\\mathrm{Cycle}}$ = %.2f)', rho), ...
            'location','southwest','interpreter','latex');legend('boxoff');
    ylim([ylim_all0(jjj,1) ylim_all0(jjj,2)])
    xlim([1960 2020])
    xticks(1960:20:2020);
    title(cname(jj))
end
print('-depsc2','figure/Figure_3_cycles.eps');
exportgraphics(gcf, 'figure/Figure_3_cycles.pdf', 'ContentType', 'vector');
