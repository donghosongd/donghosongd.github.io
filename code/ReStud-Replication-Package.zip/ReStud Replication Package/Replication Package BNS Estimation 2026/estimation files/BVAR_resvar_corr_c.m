function [beta,sigma,resvar,delta] = BVAR_resvar_corr_c(y,f,spec)

% y - cyclical variables, f - residuals from trend variables whose shocks are correlated with those of y

% dimensions 
[TT,n] = size(y);
lags   = spec.nlags;
k      = n*lags;         % # coefficients for each equation
j      = size(f,2);

% constructing the matrix of regressors
x = zeros(TT,k);
for i=1:lags
    x(:,(i-1)*n+1:i*n) = lag(y,i);
end
x     = x(lags+1:end,:);
y     = y(lags+1:end,:);
f     = f(lags:end,:);      % one more row as we are going to take the difference for trend
[T,n] = size(y);

% priors for trend component
dtr    = spec.dtr;          % df for covariance (trend)
PSItr  = spec.Psitr;        % mode matrix for covariance (trend)

% posterior draw of sigma_tau
epsf      = diff(f);        % random-walk spec is baseline
epsf(:,1) = f(2:end,1) - spec.tau_mean_post(1) - spec.tau_mean_post(2)*f(1:end-1,1);  % replace with AR(1)
PRtr      = zeros(j,j);
PRtr(1,1) = reshape((spec.tau_mean_post - spec.tau_mean),1,[])*inv(spec.tau_var)*reshape((spec.tau_mean_post - spec.tau_mean),[],1);
tsigmahat = epsf'*epsf + PRtr + diag(PSItr)*(dtr+j+1); % 2nd component, mode to scale
[V, E]    = eig(tsigmahat);
Sinv      = V*diag(1./abs(diag(E)))*V';
eta       = mvnrnd(zeros(1,j),Sinv,T+dtr);
tsigma    = (eta'*eta)\eye(j);

Lt        = chol(tsigma,'lower');

% add to regressors
x     = [x epsf*inv(Lt)'];        % with correlated shocks, y = [x z]*beta + eps

% priors for cyclical components
alpha  = 2;                    % lag-decaying parameter of the MN prior
lambda = 0.2;                  % std of the MN prior
b      = [spec.b0;zeros(j,n)]; % prior mean for beta - all zeros
d      = spec.d;               % df for covariance (cycle)
PSI    = spec.Psi;             % scale matrix for covariance (cycle)
omega  = zeros(k+j,1);
for i  = 1:lags
    omega((i-1)*n+1:i*n) = (d-n-1)*(lambda^2)*(1/(i^alpha))./PSI(1:n);
end
omega(lags*n+1:lags*n+j) = spec.corrstd^2; % std of correlation prior

% posterior mode of the VAR coefficients (Formulas in Appendix A of DN et al., 2017)
betahat     = (x'*x+diag(1./omega))\(x'*y+diag(1./omega)*b);
betahat_tr  = (x(:,1:n*lags)'*x(:,1:n*lags)+diag(1./omega(1:n*lags)))\(x(:,1:n*lags)'*y+diag(1./omega(1:n*lags))*b(1:n*lags,:));

% VAR residuals
epshat      = y-x*betahat;
sigmahat    = (epshat'*epshat + diag(PSI) + (betahat-b)'*diag(1./omega)*(betahat-b))/(T+d+n+1);

epshat_tr   = y-x(:,1:n*lags)*betahat_tr;
sigmahat_tr = (epshat_tr'*epshat_tr + diag(PSI) + (betahat(1:n*lags,:)-b(1:n*lags,:))'*diag(1./omega(1:n*lags))*(betahat(1:n*lags,:)-b(1:n*lags,:)))/(T+d+n+1);

resvar.y           = y;
resvar.x           = x(:,1:n*lags);
resvar.betahat     = betahat_tr;
resvar.epshat      = epshat_tr;
resvar.sigmahat    = sigmahat_tr;

% posterior draw of beta and sigma_c
stationary = 0;
while stationary==0

    if spec.corr==0
        [V, E]    = eig(sigmahat_tr*(T+d+n+1));
        Sinv      = V*diag(1./abs(diag(E)))*V';
        eta       = mvnrnd(zeros(1,n),Sinv,T+d);
        csigma    = (eta'*eta)\eye(n);
        cholSIGMA = cholred((csigma+csigma')/2);
        cholZZinv = cholred((x(:,1:n*lags)'*x(:,1:n*lags)+diag(1./omega(1:n*lags)))\eye(k));
        betaall   = betahat_tr + cholZZinv'*randn(size(betahat_tr))*cholSIGMA;    
    elseif spec.corr==1
        [V, E]    = eig(sigmahat*(T+d+n+1));
        Sinv      = V*diag(1./abs(diag(E)))*V';
        eta       = mvnrnd(zeros(1,n),Sinv,T+d);
        csigma    = (eta'*eta)\eye(n);
        cholSIGMA = cholred((csigma+csigma')/2);
        cholZZinv = cholred((x'*x+diag(1./omega))\eye(k+j));
        betaall   = betahat + cholZZinv'*randn(size(betahat))*cholSIGMA;
    end

    % stationarity check
    AA        = zeros(n*lags);
    AA(1:n,1:n*lags) = betaall(1:n*lags,1:n)';
    AA(n+1:end,1:n*(lags-1))=eye(n*(lags-1));
    stationary = (sum(abs(eig(AA))>1)==0);
end

% re-parametrization
beta  = betaall(1:n*lags,1:n);
if spec.corr==0
    delta = zeros(j,n)';
elseif spec.corr==1
    delta = betaall(n*lags+1:n*lags+j,:)';
end
sigma = [tsigma                  tsigma*inv(Lt)'*delta';
         delta*inv(Lt)*tsigma    delta*delta'+csigma];

end

function z = lag(x,n,v)
% PURPOSE: creates a matrix or vector of lagged values
% -------------------------------------------------------
% USAGE: z = lag(x,n,v)
% where: x = input matrix or vector, (nobs x k)
%        n = order of lag
%        v = (optional) initial values (default=0)
% e.g.
%     z = lag(x) creates a matrix (or vector) of x, lagged 1 observations
%     z = lag(x,n) creates a matrix (or vector) of x, lagged n observations
%     z = lag(x,n,v) creates a matrix (or vector) of x, lagged n observations,
%         with initial values taking a value v.
% ------------------------------------------------------
% RETURNS: z = matrix (or vector) of lags (nobs x k)
% ------------------------------------------------------
% NOTES: if n <= 0, z = [] is returned. While you may find this
%        preverse, it is sometimes useful.
%-------------------------------------------------------
% SEE ALSO: mlag() 
%-------------------------------------------------------

% written by:
% James P. LeSage, Dept of Economics
% University of Toledo
% 2801 W. Bancroft St,
% Toledo, OH 43606
% jpl@jpl.econ.utoledo.edu

switch(nargin)

case 1
   n = 1; v = 0;
   zt = ones(n,cols(x))*v;
   z = [ zt; trimr(x,0,n)];

case 2
   v = 0;
   if n < 1
   z = [];
   return;
   end;
   zt = ones(n,cols(x))*v;
   z = [ zt; trimr(x,0,n)];

case 3
   if n < 1
   z = [];
   return;
   end;
   zt = ones(n,cols(x))*v;
   z = [ zt; trimr(x,0,n)];

otherwise
error('lag: wrong # of input arguments');
end

end

function c = cols(x)
% PURPOSE: return columns in a matrix x
% -----------------------------------------
% USAGE: c = cols(x)
% where: x = input matrix
% -----------------------------------------
% RETURNS: c = # of columns in x
% -----------------------------------------

  [r,c] = size(x);
end

function z = trimr(x,n1,n2)
% PURPOSE: return a matrix (or vector) x stripped of the specified rows.
% -----------------------------------------------------
% USAGE: z = trimr(x,n1,n2)
% where: x = input matrix (or vector) (n x k)
%       n1 = first n1 rows to strip
%       n2 = last  n2 rows to strip
% NOTE: modeled after Gauss trimr function
% -----------------------------------------------------
% RETURNS: z = x(n1+1:n-n2,:)
% -----------------------------------------------------

% written by:
% James P. LeSage, Dept of Economics
% Texas State University-San Marcos
% 601 University Drive
% San Marcos, TX 78666
% jlesage@spatial-econometrics.com

  [n junk] = size(x);
  if (n1+n2) >= n; 
     error('Attempting to trim too much in trimr');
  end;
  h1 = n1+1;   
  h2 = n-n2;
  z = x(h1:h2,:);
end
  
  
function C = cholred(S)
    [v,d]  = eig(S);
    dd     = diag(d);
    dd(dd<1e-6)=0;
    C      = diag(sqrt(dd))*v';
end



function Sigma = CovarianceDraw(z,df0,mS0)

[T,n] = size(z);
Sc0   = mS0*(df0+n+1); %From mode to scale
S     = (z'*z)+Sc0;

[V,E] = eig(S);
eta   = randn(T+df0,n)*diag(1./abs(sqrt(diag(E))))*V';
Sigma = (eta'*eta)\eye(n);

end