function [DD,ZZ,PHI,RR,SIG,n1,n2] = coefficients(Phi,Sig,delta,SigE,muT,rhoT)

% 4 RW and 6 Cycles
n1 = 4;
n2 = 6;
n3 = 1;
nt = length(muT);
p  = size(Phi,2)/n2; 

PHI = blkdiag(blkdiag(eye(n1), [Phi;eye(n2*(p-1)) zeros(n2*(p-1),n2)]),zeros(n3,n3));
SIG = blkdiag(Sig,SigE);
DD  = zeros(n1+n2*p+n3,1);
DD(1:nt) = reshape(muT,[],1); % mean for output growth and unrate
PHI(1:nt,1:nt) = diag(rhoT);   % each modeled as an AR(1) process


RR                        = zeros(n1+p*n2+n3,n1+n2+n3);
RR(1:n1+n2,1:n1+n2)       = eye(n1+n2);
RR(n1+p*n2+1:n1+p*n2+n3,n1+n2+1:n1+n2+n3) = eye(n3);


ZZ = zeros(n2+1,size(PHI,1));
ZZ(1:n2+1,1:n1) = [1 0 0 0;
                   0 1 0 0;
                   0 0 1 1;
                   0 0 0 1;
                   0 0 0 1;
                   0 0 0 1;
                   0 1 0 0];

ZZ(1:n2+1,n1+1:n1+n2) = [1 0 0 0 0     0;
                         0 1 0 0 0     0;
                         0 0 1 0 0     0;
                         0 0 0 1 0     0;
                         0 0 0 0 1     0;
                         0 0 0 0 delta 0;
                         0 0 0 0 0     1];

ZZ(1,n1+n2+1)         = -1;       % output growth  
ZZ(6,n1+p*n2+1)       = 1;        % inflation survey errors

end