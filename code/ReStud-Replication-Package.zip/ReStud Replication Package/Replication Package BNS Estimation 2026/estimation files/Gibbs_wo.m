function [Phi_var,Sig_var,Y_trend,Y_cycle,para_trn,XX_var] = Gibbs_wo(YY,spec,init)

% initial starting values
Phi   = init.Phi;
Sig   = init.Sig;
muT   = init.muT;
rhoT  = init.rhoT;

% specification
nsim    = spec.nsim;
n1      = 4; % # of trend components
n2      = 4; % # of cyclical components
nt      = length(muT);
p       = spec.nlags; % var lag order
[nT,nv] = size(YY);

% store coefficients
Phi_var  = zeros(nsim,n2*p,n2);
Sig_var  = zeros(nsim,n1+n2,n1+n2);
Y_trend  = zeros(nsim,nT,n1);
Y_cycle  = zeros(nsim,nT,n2);
XX_var   = zeros(nsim,n1+n2*p);
para_trn = zeros(nsim,nt*2);


disp('                                                               ');
disp('                          GIBBS SAMPLER BEGINS                 ');

tic

for ii=1:nsim
    
    Phi_var(ii,:,:) = Phi;
    Sig_var(ii,:,:) = Sig;
    
    %% Smoothed estimates of trend and cycle components given parameters
    [~,~,At_draw]   = evallh_wo(YY,Phi',Sig,muT,rhoT,spec);
    YYtrend         = At_draw(:,1:n1);
    YYcycle         = At_draw(:,n1+1:n1+n2); 
    
    XX_var(ii,:)    = At_draw(end,:);
    Y_trend(ii,:,:) = YYtrend;
    Y_cycle(ii,:,:) = YYcycle;

    %% Update parameters for trend growth and unrate
    [tau_beta,tau_beta_mean] = post_beta_rest(spec.tau_mean, spec.tau_var, YYtrend(:,1:nt), Sig(1:nt,1:nt));
    muT                      = tau_beta(1:nt);
    rhoT                     = tau_beta(nt+1:2*nt);
    spec.tau_mean_post       = tau_beta_mean;
    para_trn(ii,:)           = tau_beta;

    %% Direct sampling of parameters for cyclical components: assume that cycl. loads on trend shocks  
    [Phi,Sig] = BVAR_resvar_corr_c(YYcycle,YYtrend,spec);     % c loads on tau shocks


    if mod(ii,1000)==0
        disp('                                                               ');
        disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(spec.corr)]);
        disp('                                                               ');
        disp(['                          DRAW NUMBER:   ', num2str(ii)]        );
        disp('                                                               ');
        disp(['                          REMAINING DRAWS:   ',num2str(nsim-ii)]);
        disp('                                                               ');
        disp(['                          ELAPPSED TIME:   ',num2str(floor(toc)), ' SEC']);
        disp('                                                               ');
    end

end

end

function [loglh, At_mat, At_draw] = evallh_wo(YY,Phi,Sig,muT,rhoT,spec)
    
    [T,nv] = size(YY);
   
    % selection matrix for missing observation
    PP = eye(nv);
    
    % model-coefficients
    [DD,ZZ,PHIF,RR,SIG,n1,n2] = coefficients_wo(Phi,Sig,muT,rhoT);
    VV   = 0*eye(nv);

    mdim = size(PHIF,1);
    
    % initialization of the filter    
    At = zeros(mdim,1);    
    At(1:4) = spec.premom(1:4,1);
    Pt = zeros(mdim,mdim);
    for kk=1:100
    Pt=PHIF*Pt*PHIF'+RR*SIG*RR';
    end
    Pt(1:n1,1:n1) = eye(n1);
        
    At_mat = zeros(T,mdim);
    Pt_mat = zeros(T,mdim^2);
    
    loglh = 0;
    
    % Filter loop 
    for t = 1:T
        
        ind  = ~isnan(YY(t,:));
        data = YY(t,ind==1)';
        mO   = PP(:,ind==1)';
        mZ   = mO*ZZ;
        mV   = mO*VV*mO';
        
        At1  = At;
        Pt1  = Pt;

        % Forecasting   
        alphahat = DD + PHIF * At1 ;
        Phat     = PHIF * Pt1 * PHIF' + RR*SIG*RR';
        Phat     = 0.5*(Phat+Phat');
      
        yhat = mZ*alphahat;
        nut  = data - yhat;
       
        Ft = mZ*Phat*mZ' + mV;  
        Ft = 0.5*(Ft+Ft');
        
        [Up, Sp, Vp] = svd(Ft);
        sp = diag(Sp); kp = sum(sp>1e-10);
        inv_Ft = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
        det_Ft = prod(sp(1:kp));

        loglh = loglh-0.5*length(data)*log(2*pi)-0.5*log(det_Ft)-0.5*nut'*inv_Ft*nut;
        loglh = real(loglh);
                
        % Updating 
        At = alphahat + (Phat*mZ')*inv_Ft*nut;
        Pt = Phat - (Phat*mZ')*inv_Ft*(Phat*mZ')';
        At_mat(t,:)  = At';
        Pt_mat(t,:)  = reshape(Pt,1,mdim^2);
       
    end
   
    At_draw  = zeros(T,mdim);
    
    % singular value decomposition
    [u, s, v] = svd(reshape(Pt_mat(T,:),mdim,mdim));
    Pchol = u*sqrt(s);
    At_draw(T,:)   = At_mat(T,:)+(Pchol*randn(mdim,1))';
    Pt_draw(T,:,:) = reshape(Pchol,1,mdim^2); 
    
    % Kalman Smoother 
    for i = 1:T-1
                
        Att  = At_mat(T-i,:)';
        Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

        Phat = PHIF * Ptt * PHIF' + RR*SIG*RR';
        Phat = 0.5*(Phat+Phat');
    
        [Up, Sp, Vp] = svd(Phat);
        sp = diag(Sp); kp = sum(sp>1e-10);
        inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
    
        nut   = At_draw(T-i+1,:)'- DD - PHIF*Att;
      
        Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
        Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   
  
        % singular value decomposition
        [um, sm, vm] = svd(Pmean);
        Pmchol = um*sqrt(sm);
        At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
        Pt_draw(T-i,:,:) = reshape(Pmchol,1,mdim^2);
         
    end
    
end
    
function [DD,ZZ,PHI,RR,SIG,n1,n2] = coefficients_wo(Phi,Sig,muT,rhoT)

% 4 RW and 6 Cycles
n1 = 4;
n2 = 4;
nt = length(muT);
p  = size(Phi,2)/n2; 

PHI = blkdiag(eye(n1), [Phi;eye(n2*(p-1)) zeros(n2*(p-1),n2)]);
SIG = Sig;
DD  = zeros(n1+n2*p,1);
DD(1:nt) = reshape(muT,[],1); % mean for output growth and unrate
PHI(1:nt,1:nt) = diag(rhoT);   % each modeled as an AR(1) process


RR                        = zeros(n1+p*n2,n1+n2);
RR(1:n1+n2,1:n1+n2)       = eye(n1+n2);


ZZ = zeros(n2,size(PHI,1));
ZZ(1:n2,1:n1)   = [1 0 0 0;
                   0 1 0 0;
                   0 0 1 1;
                   0 0 0 1];

ZZ(1:n2,n1+1:n1+n2)   = [1 0 0 0;
                         0 1 0 0;
                         0 0 1 0;
                         0 0 0 1];

ZZ(1,n1+n2+1)         = -1;       % output growth  

end



function [beta, post_mean, post_var] = post_beta_rest(prior_mean, prior_var, tau, Sigma)
% POST_BETA  posterior draw for n-dim AR(1) with intercept and
% correlated shocks, enforcing |rho_j|<1 with a cap.
%
% Model:
%   tau_t = mu + diag(rho) * tau_{t-1} + eps_t
%   eps_t ~ N(0, Sigma)   % Sigma is n x n
%
% Inputs:
%   prior_mean : (2n x 1)  [mu_1; ...; mu_n; rho_1; ...; rho_n]
%   prior_var  : (2n x 2n)
%   tau        : (T x n)
%   Sigma      : (n x n)   covariance of eps_t
%
% Outputs:
%   beta       : (2n x 1) draw satisfying |rho_j|<1 (if found)
%   post_mean  : (2n x 1)
%   post_var   : (2n x 2n)

[T, n] = size(tau);
TT = T - 1;
k  = 2 * n;

SigInv = inv(Sigma);

% build the stacked regression system explicitly
Y = zeros(n*TT, 1);
X = zeros(n*TT, k);

row = 0;
for t = 2:T
    y_t    = tau(t, :)';     % n x 1
    tauLag = tau(t-1, :);    % 1 x n

    Y(row+1:row+n) = y_t;

    Xt = [eye(n), diag(tauLag)];   % n x 2n
    X(row+1:row+n, :) = Xt;

    row = row + n;
end

% GLS accumulation: A = sum Xt' * SigInv * Xt, b = sum Xt' * SigInv * y_t
A = zeros(k, k);
b = zeros(k, 1);

for t = 1:TT
    idx = (n*(t-1)+1):(n*t);
    Xt  = X(idx, :);          % n x 2n
    Yt  = Y(idx);             % n x 1

    A = A + Xt' * SigInv * Xt;
    b = b + Xt' * SigInv * Yt;
end

% posterior
post_var  = inv(A + inv(prior_var));
post_mean = post_var * (b + inv(prior_var) * prior_mean);
post_var  = (post_var + post_var') / 2;

% draw with stationarity, capped
max_iter = 1e3;
for iter = 1:max_iter
    beta = mvnrnd(post_mean, post_var)';   % 2n x 1
    rho  = beta(n+1:end);
    if all(abs(rho) < 1)
        return;
    end
end

beta = post_mean;

end


