%% plot trend and cycle 
scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);


load recess.mat

xx = sum(recession,2)/2;
ww = recession(:,2) - recession(:,1);

vo = {'Output growth','Unemployment','Interest rate','Inflation',...
    'Inflation exp.(1yr)','Inflation exp.(10yr)','Unemployment exp.(1yr)'};
vn = {'Output','Unemployment','Interest rate','Inflation',...
    'Inflation exp.(1yr)','Inflation exp.(10yr)','Unemployment exp.(1yr)'};

order = [1 2 7 3 4 5 6];

Y_trend0        = Y_trend;
Y_trend0(:,:,3) = Y_trend(:,:,3)+Y_trend(:,:,4);
Y_trend0(:,:,5) = Y_trend(:,:,4);
Y_trend0(:,:,6) = Y_trend(:,:,4);
Y_trend0(:,:,7) = Y_trend(:,:,2);

Y_cycle0        = Y_cycle;
Y_cycle0(:,:,6) = Svy_var(:,1).*Y_cycle(:,:,5);
Y_cycle0(:,:,7) = Y_cycle(:,:,6);

model_ffr = squeeze(Y_trend0(:,:,3)+Y_cycle0(:,:,3));


place = [1 2 3 4 6 7 8];

% 
% fig = figure('Position',[4,36,1703,753],'Name',...
% '','Color','w','OuterPosition',[3,30,1705,836]); %'Position',[1 scrsz(4)/20 scrsz(3)/1.5 scrsz(4)/2.0]);

fig = figure('Position',[4,20,2288,744],'Name',...
'','Color','w','OuterPosition',[3,14,2290,825]);
for iii=1:nv
    subplot(2,4,place(iii))
    ii = order(iii);
    hold on
    for kk = 1:length(xx), bar(xx(kk),20,ww(kk),'FaceColor',[0.9 0.9 0.9],'EdgeColor','w'), end
    for kk = 1:length(xx), bar(xx(kk),-20,ww(kk),'FaceColor',[0.9 0.9 0.9],'EdgeColor','w'), end  
    hold on
    shadedplot(time,quantile(Y_trend0(:,:,ii),0.05),quantile(Y_trend0(:,:,ii),0.95),[0.73 0.73 0.999],[0.7 0.7 0.999]);
    hold on
    plot(time,YYY(:,ii),'Color',[1.0, 0.6, 0.2],'linewidth',2,'marker','s','markersize',6,...
    'MarkerIndices',1:8:length(time),'markerfacecolor',[1.0, 0.6, 0.2]);
    plot(time,quantile(Y_trend0(:,:,ii),0.5),'color',[0.5 0.5 0.9],'linewidth',2);
    axis tight
    xlim([1960 2020])
    title(vo(ii),'Interpreter','latex')
    if iii==2  || iii==3
        ylim([3 12])
    elseif iii==4
        ylim([-2 20])
    elseif iii==1
        ylim([-12 12])
    elseif iii==5 || iii==6 || iii==7
        ylim([-3 12])
    end
       
end
print('-depsc2','figure/Figure_1_Trends');
exportgraphics(gcf, 'figure/Figure_1_Trends.pdf', 'ContentType', 'vector');
            

fig = figure('Position',[4,20,2288,744],'Name',...
'','Color','w','OuterPosition',[3,14,2290,825]); % 'Position',[1 scrsz(4)/20 scrsz(3)/1.5 scrsz(4)/2.0]);
for iii=1:nv
    subplot(2,4,place(iii))
    ii = order(iii);
    hold on
    for kk = 1:length(xx), bar(xx(kk),20,ww(kk),'FaceColor',[0.9 0.9 0.9],'EdgeColor','w'), end
    for kk = 1:length(xx), bar(xx(kk),-50,ww(kk),'FaceColor',[0.9 0.9 0.9],'EdgeColor','w'), end  
    hold on
    shadedplot(time,quantile(Y_cycle0(:,:,ii),0.05),quantile(Y_cycle0(:,:,ii),0.95),[0.73 0.73 0.999],[0.7 0.7 0.999]);
    hold on
    % plot(time,(YYY(:,ii)-quantile(Y_trend0(:,:,ii),0.5)'),'color',[0.9 0.3 0.3],'marker','s','markersize',10,...
    %      'markerfacecolor',[0.9 0.3 0.3],'markeredgecolor',[0.9 0.3 0.3],'MarkerIndices',1:4:length(time),'linewidth',1);
    plot(time,quantile(Y_cycle0(:,:,ii),0.5),'color',[0.5 0.5 0.9],'linewidth',2);
    title(vn(ii),'Interpreter','latex')
    axis tight
    xlim([1960 2020])
    if iii==2  || iii==3
        ylim([-2.5 4.5])
    elseif iii==4
        ylim([-8 14])
    elseif iii==1
        ylim([-45 20])
    elseif iii==5 
        ylim([-4 10])
    elseif iii==6 || iii==7 
        ylim([-1.5 4])
    end
end
print('-depsc2','figure/Figure_1_Cycles');
exportgraphics(gcf, 'figure/Figure_1_Cycles.pdf', 'ContentType', 'vector');

