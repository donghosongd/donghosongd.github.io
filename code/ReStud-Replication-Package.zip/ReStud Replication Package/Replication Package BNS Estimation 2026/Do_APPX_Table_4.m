clear
close all
clc

path('other files',path)
path('max-share identification files',path)
path('results',path)

summarize_shocks_TCVAR_woSPF_cyc2all_1_APPX_Table_4;