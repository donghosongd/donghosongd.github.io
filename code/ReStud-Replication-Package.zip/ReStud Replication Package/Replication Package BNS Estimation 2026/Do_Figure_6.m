clc;clear;close all

path('figure',path)
path('forecasting results',path)

this        = [1:68];
HH          = 12;
select      = [1 2 4];
select_aer  = [1 4 8];

load forecast_var_aer_68_2.mat
[MSE_aer0_tr,EEEpred_aer0] = changeLVtoGR(EEpred_var,YF_var);
rmse_aer0   = squeeze(sqrt(mean(MSE_aer0_tr(this,1:HH,:),1)));
EE_aer0     = EEEpred_aer0(this,:,:);
ld_aer0     = 100*logdetM(EE_aer0,select_aer,HH);

load forecast_var_aer_68_3.mat
[MSE_aer_tr,EEEpred_aer] = changeLVtoGR(EEpred_var,YF_var);
rmse_aer   = squeeze(sqrt(mean(MSE_aer_tr(this,1:HH,:),1)));
EE_aer     = EEEpred_aer(this,:,:);
ld_aer     = 100*logdetM(EE_aer,select_aer,HH);


load forecast_tcvar_wo_68_1_0.1.mat
rmse_tcvarwo101 = squeeze(sqrt(mean(MSE_var(this,1:HH,select),1)));
EE_tcvarwo101   = EEpred_var(this,:,select);
ld_tcvarwo101   = 100*logdetM(EE_tcvarwo101,select,HH);


load forecast_var_68_2.mat
rmse_var0 = squeeze(sqrt(mean(MSE_var(this,1:HH,select),1)));
EE_var0   = EEpred_var(this,:,select);
ld_var0   = 100*logdetM(EE_var0,select,HH);

load forecast_var_68_3.mat
rmse_var = squeeze(sqrt(mean(MSE_var(this,1:HH,select),1)));
EE_var   = EEpred_var(this,:,select);
ld_var   = 100*logdetM(EE_var,select,HH);

load forecast_tcvar_68_1_0.1.mat
rmse_tcvar101 = squeeze(sqrt(mean(MSE_var(this,1:HH,select),1)));
EE_tcvar101   = EEpred_var(this,:,select);
ld_tcvar101   = 100*logdetM(EE_tcvar101,select,HH);


scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',30)
set(0,'DefaultTextFontSize',30);

fig = figure('Position',[7,-9,1114,784],'Name',...
'Data','Color','w','OuterPosition',[6,-15,1116,865]);
% fig = figure('Position',[20,20,900,600],'Name',...
% '','Color','w','Position',[1 scrsz(4)/20 scrsz(3)/2.5 scrsz(4)/1.5]);
hold on
j0=plot(zeros(1,HH),'k--');
k0=plot(ld_tcvar101-ld_var0,'k','Color',[0.5 0.5 0.5],'Marker','^','linewidth',3,'markersize',15,'markerfacecolor',[0.99 0.99 0.99]);
k1=plot(ld_tcvar101-ld_var,'k','linewidth',5);
k2=plot(ld_tcvar101-ld_aer0,'Color',[0.9 0.2 0.1],'Marker','>','linewidth',3,'markersize',12,'markerfacecolor',[0.9 0.2 0.1]);
k3=plot(ld_tcvar101-ld_aer,'Color',[0.9 0.2 0.1],'linewidth',6,'linestyle',':');
k4=plot(ld_tcvar101-ld_tcvarwo101,'Color',[0.1 0.6 0.1],'Marker','s','linewidth',3,'markersize',15,'markerfacecolor',[0.8 0.99 0.8]);
%k5=plot(ld_tcvar101-ld_tcvarw101,'Color',[0.1 0.6 0.1],'Marker','o','linewidth',3,'markersize',15,'markerfacecolor',[0.8 0.99 0.8]);
kk=legend([k0,k1,k2,k3,k4],...
    'MN-VAR','MN-LR-VAR','MN-VAR (Angeletos et al. 2020)','MN-LR-VAR (Angeletos et al. 2020)',...
    'TC-VAR (without survey data)');
set(kk,'location','southwest');legend('boxoff');
xlabel('Quarters')
ylabel('\%')
xlim([1 12])
ylim([-40 10])
print('-depsc2','figure/Figure_6.eps');
exportgraphics(gcf, 'figure/Figure_6.pdf', 'ContentType', 'vector');





function [MSE_var_tr,EEEpred_var] = changeLVtoGR(EEpred_var,YF_var)

str         = {' Output',' Investment',' Consumption',' Hours Worked',' Unemployment',' Labor Share',...
               ' Nom. Int. Rate',' Inflation',' Labor Prod.',' TFP'};
order       = [1 2 3 5 4 10 6 8 7 9];
variables   = str(order);

% change to output growth, unemployment, inflation

[n1,n2,n3] = size(EEpred_var);

% output growth
EEEpred_var = zeros(n1,n2,3);
for bb=1:n1
    EEEpred_var(bb,2:end,1) = 4*diff(EEpred_var(bb,:,1));

    temp = diff([squeeze(YF_var(bb,1,1));squeeze(YF_var(bb,1,1)+EEpred_var(bb,1,1))]);
    EEEpred_var(bb,1,1)     = 4*temp;
end
% unemployment
EEEpred_var(:,:,2) = EEpred_var(:,:,4);

% inflation 
EEEpred_var(:,:,3) = 4*EEpred_var(:,:,8);

MSE_var_tr = EEEpred_var.^2;


end


function ld = logdetM(EE,select,HH)

nE   = size(EE,1);
ld   = zeros(HH,1);

if ndims(EE)<3

    for h=1:HH
        temp = zeros(nE,1);
        for ee=1:nE
            temp(ee,:) = squeeze(EE(ee,h))*squeeze(EE(ee,h))';
        end
        ld(h,:) = log(det(squeeze(mean(temp,1))))/(2*length(select));
    end


else

    for h=1:HH
        temp = zeros(nE,length(select),length(select));
        for ee=1:nE
            temp(ee,:,:) = squeeze(EE(ee,h,:))*squeeze(EE(ee,h,:))';
        end
        ld(h,:) = log(det(squeeze(mean(temp,1))))/(2*length(select));
    end

end


end