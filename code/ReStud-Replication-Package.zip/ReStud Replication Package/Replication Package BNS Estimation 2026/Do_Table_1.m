clear
close all
clc

path('other files',path)
path('max-share identification files',path)
path('results',path)

tbl_file = 'results/Table_1.csv';   % the table printed below is also saved to this file
if exist(tbl_file,'file'), delete(tbl_file); end

summarize_shocks_TCVAR_cyc2all_1_Table_1;