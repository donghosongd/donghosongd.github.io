clear
close all
clc

path('other files',path)
path('max-share identification files',path)
path('results',path)

summarize_shocks_TCVAR_cyc2all_uncorr_0_APPX_Table_2;