function Sig = fitARmodel(y)

n   = size(y,2);
Sig = zeros(n, n);
for i = 1:n
    % Extract the current column and its lagged values
    y_current = y(2:end, i);
    y_lagged = y(1:end-1, i);
    
    % Identify rows where neither current nor lagged values are NaN
    valid_indices = ~isnan(y_current) & ~isnan(y_lagged);
    
    % If enough valid data points exist, perform OLS
    if nnz(valid_indices) > 1
        y_current_valid = y_current(valid_indices);
        y_lagged_valid = y_lagged(valid_indices);
        X = [ones(nnz(valid_indices), 1), y_lagged_valid];
        ar1 = ols1(y_current_valid, X);
        Sig(i, i) = ar1.sig2hatols;
    else
        Sig(i, i) = NaN; % Set to NaN if not enough data
    end
end

end