function [loglh,At_mat,At_draw,DD,PHIF] = KFKS_var(YY,ZZ0,DD0,PHIF0,CHOLF0)
    
    [T,nv] = size(YY);
   
    % selection matrix for missing observation
    PP   = eye(nv);
    
    % model-coefficients
    ZZ    = [ZZ0 zeros(nv)];
    DD    = [reshape(DD0,[],1);zeros(nv,1)];
    VV    = 0*eye(nv);
    PHIF  = blkdiag(PHIF0,zeros(nv));
    mdim  = size(PHIF,1);
    CHOLF = [CHOLF0;eye(nv)];
    SIGF  = CHOLF*CHOLF';

    % initialization of the filter    
    At = zeros(mdim,1);    
    Pt = zeros(mdim,mdim);
    for kk=1:12
    Pt=PHIF*Pt*PHIF'+SIGF;
    end
        
    At_mat = zeros(T,mdim);
    Pt_mat = zeros(T,mdim^2);
    
    loglh = 0;
    % Filter loop 
    for t = 1:T
        
        ind  = ~isnan(YY(t,:));
        data = YY(t,ind==1)';
        mO   = PP(:,ind==1)';
        mZ   = mO*ZZ;
        mV   = mO*VV*mO';
        
        At1  = At;
        Pt1  = Pt;

        % Forecasting   
        alphahat = DD + PHIF * At1 ;
        Phat     = PHIF * Pt1 * PHIF' + SIGF;
        Phat     = 0.5*(Phat+Phat');
      
        yhat = mZ*alphahat;
        nut  = data - yhat;
       
        Ft = mZ*Phat*mZ' + mV;  
        Ft = 0.5*(Ft+Ft');
        
        [Up, Sp, Vp] = svd(Ft);
        sp = diag(Sp); kp = sum(sp>1e-10);
        inv_Ft = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
        det_Ft = prod(sp(1:kp));

        loglh = loglh-0.5*length(data)*log(2*pi)-0.5*log(det_Ft)-0.5*nut'*inv_Ft*nut;
        loglh = real(loglh);
                
        % Updating 
        At = alphahat + (Phat*mZ')*inv_Ft*nut;
        Pt = Phat - (Phat*mZ')*inv_Ft*(Phat*mZ')';
        At_mat(t,:)  = At';
        Pt_mat(t,:)  = reshape(Pt,1,mdim^2);
       
    end
   
    At_draw  = zeros(T,mdim);
    
    % singular value decomposition
    [u, s, v] = svd(reshape(Pt_mat(T,:),mdim,mdim));
    Pchol = u*sqrt(s);
    At_draw(T,:)   = At_mat(T,:)+(Pchol*randn(mdim,1))';
    Pt_draw(T,:,:) = reshape(Pchol,1,mdim^2); 
    
    % Kalman Smoother 
    for i = 1:T-1
                
        Att  = At_mat(T-i,:)';
        Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

        Phat = PHIF * Ptt * PHIF' + SIGF;
        Phat = 0.5*(Phat+Phat');
    
        [Up, Sp, Vp] = svd(Phat);
        sp = diag(Sp); kp = sum(sp>1e-8);
        inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
    
        nut   = At_draw(T-i+1,:)'- DD - PHIF*Att;
      
        Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
        Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   
  
        % singular value decomposition
        [um, sm, vm] = svd(Pmean);
        Pmchol = um*sqrt(sm);
        At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
        Pt_draw(T-i,:,:) = reshape(Pmchol,1,mdim^2);
         
    end
    
end