function [logML,betahat,sigmahat,lambda,Phi,HH,beta,sigma]=logMLbvarPLR(par,y,x,lags,T,n,b,MIN,MAX,SS,Vc,pos,mn,HH,HHcompl,IndPhi,SinglePhi,y0,hyperpriors,priorcoef,HPmode)

% Based on Giannone, Lenza and Primiceri (2017)
d    = n+2;
cont = 1;
if mn == 1
    lambda = MIN.lambda+(MAX.lambda-MIN.lambda)/(1+exp(-par(cont)));
    cont   = cont +1;
elseif mn == -1 % Dogmatic
    lambda = 0;
elseif mn == -2 % Mode
    lambda = HPmode.lambda;
elseif mn == 0  % OFF
    lambda = inf;
else
    error('mn can only take the values 0, 1, -1, -2')
end

alpha = 2;
psi   = SS;
for jlr = 1:length(IndPhi)
    if IndPhi(jlr)==0      % OFF
        Phi(jlr) = inf;
    elseif IndPhi(jlr)==-1 % Dogmatic
        Phi(jlr) = 0.0001;
    elseif IndPhi(jlr)==-2 % Mode
        Phi(jlr) = HPmode.Phi;
    elseif IndPhi(jlr)==1  % Optimize
        Phi(jlr)=MIN.Phi+(MAX.Phi-MIN.Phi)./(1+exp(-par(cont)));
        if SinglePhi == 0
            cont = cont+1;
        end
    else
        error('IndPhi can only take the values 0, 1, -1, -2')
    end    
end

% setting up the priors
k        = 1+n*lags;
omega    = zeros(k,1);
omega(1) = Vc;

for i=1:lags
    omega(1+(i-1)*n+1:1+i*n)=(d-n-1)*(lambda^2)*(1/(i^alpha))./psi;
end

% prior scale matrix for the covariance of the shocks
PSI  = diag(psi);
Td   = 0;
ydlr = [];
xdlr = [];

% dummy observations for the long run priors
rHH = size(HH,1); %rank of HH (HH must be full row rank)
if rHH<n
    HH = [HH;HHcompl];
end
y0H  = y0*HH';
HH_1 = inv(HH);

for jlr = 1:length(IndPhi)
    if jlr <=rHH
        if IndPhi(jlr)~=0
            Phitemp = Phi(jlr);
            scale   = y0H(jlr)/Phitemp;
            ydtemp  = scale*HH_1(:,jlr)';
            xdtemp  = [0 scale*repmat(HH_1(:,jlr)',1,lags)];
        end
    elseif IndPhi(jlr)==1 || IndPhi(jlr)==-2
        Phitemp = Phi(jlr);
        JJ      = rHH+1:n;
        ydtemp  = (HH_1(:,JJ)*HH(JJ,:)*y0')'/Phitemp;
        xdtemp  = [1/Phitemp repmat((HH_1(:,JJ)*HH(JJ,:)*y0')',1,lags)/Phitemp];
    elseif IndPhi(jlr)~=0
        error('IndPhi the null space can only take the values 0,1,-2')
    end
    if IndPhi(jlr)~=0
        ydlr    = [ydlr;ydtemp];
        xdlr    = [xdlr;xdtemp];
    end
    
end

y  = [y;ydlr];
x  = [x;xdlr];
Td = Td+size(xdlr,1);
T  = T+Td;

% posterior mode of the VAR coefficients
if mn == 0 %flat
    lambda   = inf;
    betahat  = (x'*x)\(x'*y); 
    epshat   = y-x*betahat;            % VAR residuals
    sigmahat = (epshat'*epshat)/(T-k); % Posterior mode of the covariance matrix
    logML    = -inf;                   % ML equal zero bacause of flat

    % posterior draws of VAR coefficients
    stationary = 0;
    while stationary==0
        [V, E]    = eig(sigmahat*(T+d+n+1));
        Sinv      = V*diag(1./abs(diag(E)))*V';
        eta       = mvnrnd(zeros(1,n),Sinv,T+d);
        sigma     = (eta'*eta)\eye(n);
        cholSIGMA = cholred((sigma+sigma')/2);
        cholZZinv = cholred((x'*x+diag(1./omega))\eye(k));
        beta      = betahat + cholZZinv'*randn(size(betahat))*cholSIGMA;
        AA        = zeros(n*lags);
        AA(1:n,1:n*lags) = beta(2:end,:)';
        AA(n+1:end,1:n*(lags-1)) = eye(n*(lags-1));
        stationary = (sum(abs(eig(AA))>1)==0);
    end
elseif mn~=0 
    if mn == -1          
        % Dogmatic
        betahat  = b;    
        epshat   = y-x*betahat; % VAR residuals
        sigmahat = (epshat'*epshat + PSI)/(T+d+n+1);

        [V, E]   = eig(sigmahat*(T+d+n+1));
        Sinv     = V*diag(1./abs(diag(E)))*V';
        eta      = mvnrnd(zeros(1,n),Sinv,T+d);
        sigma    = (eta'*eta)\eye(n);
        beta     = betahat;
    else   
        % Informative
        betahat  = (x'*x+diag(1./omega))\(x'*y+diag(1./omega)*b);
        epshat   = y-x*betahat; % VAR residuals
        sigmahat = (epshat'*epshat + PSI + (betahat-b)'*diag(1./omega)*(betahat-b))/(T+d+n+1);

        stationary = 0;
        max_iter = 1000;
        iter = 0;
        cholZZinv = cholred((x'*x+diag(1./omega))\eye(k));  % Precompute
        
        while stationary == 0 && iter < max_iter
            iter      = iter + 1;
            [V, E]    = eig(sigmahat*(T+d+n+1));
            Sinv      = V * diag(1./abs(diag(E))) * V';
            eta       = mvnrnd(zeros(1,n), Sinv, T+d);
            sigma     = (eta'*eta) \ eye(n);
            cholSIGMA = chol((sigma+sigma')/2, 'lower');
            beta      = betahat + (cholZZinv' * randn(size(betahat)) * cholSIGMA);
            AA                  = zeros(n*lags);
            AA(1:n,1:n*lags)    = beta(2:end,:)';
            AA(n+1:end,1:n*(lags-1)) = eye(n*(lags-1));
        
            eigAA = eig(AA, 'vector');
            if all(abs(eigAA) <= 1)
                stationary = 1;
            elseif iter == max_iter
                % if no stationary draw is found after max_iter attempts,
                % rescale the eigenvalues of AA to lie inside the unit circle
                disp('Rescaling eigenvalues to enforce stationarity...');
                [Q, D] = eig(AA);
                maxEig = max(abs(diag(D)));
                if maxEig > 1
                    D = D / (maxEig + 0.01);  % Scale to ensure max eigenvalue < 1
                end
                AA = real(Q * D / Q);  % Ensure no imaginary parts remain
                stationary = 1;        % Exit loop with stationary AA
            end
        end


    end

   
    % logML
    aaa = diag(sqrt(omega))*(x'*x)*diag(sqrt(omega));
    if mn == -1
        bbb = diag(1./sqrt(psi))*(epshat'*epshat )*diag(1./sqrt(psi));
    else
        bbb = diag(1./sqrt(psi))*(epshat'*epshat + (betahat-b)'*diag(1./omega)*(betahat-b))*diag(1./sqrt(psi));
    end
    
    eigaaa  = real(eig(aaa)); eigaaa(eigaaa<1e-12)=0; eigaaa=eigaaa+1;
    eigbbb  = real(eig(bbb)); eigbbb(eigbbb<1e-12)=0; eigbbb=eigbbb+1;
    
    logML   = - n*T*log(pi)/2 + sum(gammaln((T+d-[0:n-1])/2)-gammaln((d-[0:n-1])/2)) +...
              - T*sum(log(psi))/2 - n*sum(log(eigaaa))/2 - (T+d)*sum(log(eigbbb))/2;

    if isempty(ydlr)~=1
        yd = ydlr;
        xd = xdlr;
        
        % prior mode of the VAR coefficients
        betahatd = b;     % this is the case for our priors (the line above delivers the same but is numerically not very stable)
        
        % VAR residuals at the prior mode
        epshatd  = yd-xd*betahatd;
        aaa      = diag(sqrt(omega))*(xd'*xd)*diag(sqrt(omega));
        
        if mn ==-1
            bbb  = diag(1./sqrt(psi))*(epshatd'*epshatd)*diag(1./sqrt(psi));
        else
            bbb  = diag(1./sqrt(psi))*(epshatd'*epshatd + (betahatd-b)'*diag(1./omega)*(betahatd-b))*diag(1./sqrt(psi));
        end
        
        eigaaa   = real(eig(aaa)); eigaaa(eigaaa<1e-12)=0; eigaaa=eigaaa+1;
        eigbbb   = real(eig(bbb)); eigbbb(eigbbb<1e-12)=0; eigbbb=eigbbb+1;
        
        % normalizing constant
        norm     = - n*Td*log(pi)/2 + sum(gammaln((Td+d-[0:n-1])/2)-gammaln((d-[0:n-1])/2)) +...
                   - Td*sum(log(psi))/2 - n*sum(log(eigaaa))/2 - (T+d)*sum(log(eigbbb))/2;
        logML    = logML-norm;
    end
    
    if hyperpriors==1
        if mn == 1
            logML=logML+logPhipdf(lambda,priorcoef.lambda.k,priorcoef.lambda.theta);
        end
        
        temp = 0;
        for jlr = 1:length(IndPhi)
            if IndPhi(jlr) == 1 && temp==0
                logML=logML+logPhipdf(Phi(jlr),priorcoef.Phi.k,priorcoef.Phi.theta);
                if SinglePhi == 1
                    temp = 1;
                end
            end
        end
    end
    logML = -logML;
end

end

function r=logPhipdf(x,k,theta)
    r = (k-1)*log(x)-x/theta-k*log(theta)-gammaln(k);
end

function r=logIG2pdf(x,alpha,beta)
    r = alpha*log(beta)-(alpha+1)*log(x)-beta./x-Philn(alpha);
end

function C = cholred(S)
    [v,d]       = eig(S);
    dd          = diag(d);
    dd(dd<1e-6) = 0;
    C           = diag(sqrt(dd))*v';
end
