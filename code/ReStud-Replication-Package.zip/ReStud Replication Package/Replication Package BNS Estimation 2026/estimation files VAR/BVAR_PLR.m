function r = BVAR_PLR(y,lags,mn,HH,IndPhi,SinglePhi,rr)

r           = [];
pos         = [];
Vc          = 10e6;
HHcompl     = [];
hyperpriors = 1; 

r.setpriors.hyperpriors = hyperpriors;
r.setpriors.Vc          = Vc;
r.setpriors.pos         = pos;
r.setpriors.mn          = mn;
r.setpriors.HH          = HH;
r.setpriors.IndPhi      = IndPhi;
r.setpriors.SinglePhi   = SinglePhi;

% parameters of the hyperpriors, if choosen
HPmode        = [];
HPmode.lambda = 0.2;       % hyperpriors modes
HPmode.Phi    = 1;

HPsd          = [];
HPsd.lambda   = 0.4;       % hyperpriors std
HPsd.Phi      = 1;

% coefficients of hyperpriors
priorcoef.lambda = GammaCoef(HPmode.lambda,HPsd.lambda,0);  
priorcoef.Phi    = GammaCoef(HPmode.Phi,HPsd.Phi,0);

% bounds for maximization
MIN = []; MAX = [];
MIN.lambda    = 0.0001;
MIN.Phi       = 0.00001;
MAX.lambda    = 5;
MAX.Phi       = 50;


% constructing the matrix of regressors
[TT,n] = size(y);
k      = n*lags+1;         % # coefficients for each equation
x      = zeros(TT,k);
x(:,1) = 1;
for i  = 1:lags
    x(:,1+(i-1)*n+1:1+i*n) = lag(y,i);
end
y0    = mean(y(1:lags,:),1);
x     = x(lags+1:end,:);
y     = y(lags+1:end,:);
[T,n] = size(y);

% MN prior mean
b     = zeros(k,n);
diagb = ones(n,1);
diagb(pos) = 0;   % Set to zero the prior mean on the first own lag for variables selected in the vector pos
b(2:n+1,:) = diag(diagb);

% starting values for the minimization
lambda0 = 0.2;     % std of MN prior
Phi0    = 1;       % std of plr prior

% residual variance of AR(1) for each variable
SS = diag(fitARmodel(y));

if mn==1
    inlambda = -log((MAX.lambda-lambda0)./(lambda0-MIN.lambda));
else
    inlambda = [];
end

nlr = sum(IndPhi>=1);
if SinglePhi==1
    nlr = min(nlr,1);
end
if nlr>0   
    inPhi = -log((MAX.Phi-Phi0)/(Phi0-MIN.Phi))*ones(nlr,1);
else
    inPhi = [];
end

x0 = [inlambda;inPhi];
H0 = 10*eye(length(x0));          % initial guess for the inverse Hessian

if rr.OPT==1
    [fh,xh,gh,H,itct,fcount,retcodeh] = csminwel('logMLbvarPLR',x0,H0,[],1e-10,1000,y,x,lags,T,n,b,MIN,MAX,SS,Vc,pos,mn,HH,HHcompl,IndPhi,SinglePhi,y0,hyperpriors,priorcoef,HPmode);
    r.postmax.itct = itct;              % #iteration before reaching maximum
    r.xh           = xh; 
else
    r.xh           = rr.xh;
end
% VAR coefficients and residuals at the posterior model
[fh,r.postmax.betahat,r.postmax.sigmahat,r.postmax.lambda,r.postmax.Phi,r.HH,r.beta,r.sigma]...
     = logMLbvarPLR(r.xh,y,x,lags,T,n,b,MIN,MAX,SS,Vc,pos,mn,HH,HHcompl,IndPhi,SinglePhi,y0,hyperpriors,priorcoef,HPmode);

r.lags            = lags;               % # lags
r.postmax.SSar1   = SS;                 % residual variance of AR(1) for each variable
r.postmax.logPost = -fh;                % value of the posterior of the hyperparameters at the peak

[DD,~,PHIF,~,~] = coefficients(r.postmax.betahat,r.postmax.sigmahat);
r.DDpm    = DD;
r.PHIFpm  = PHIF;
r.betapm  = r.postmax.betahat;
r.sigmapm = r.postmax.sigmahat;

[~,~,~,~,~,~,beta,sigma]=logMLbvarPLR(r.xh,y,x,lags,T,n,b,MIN,MAX,SS,Vc,pos,mn,HH,HHcompl,IndPhi,SinglePhi,y0,hyperpriors,priorcoef,HPmode);

[DD,~,PHIF,~,~] = coefficients(beta,sigma);
r.DD    = DD;
r.PHIF  = PHIF;
r.beta  = beta;
r.sigma = sigma;

end





