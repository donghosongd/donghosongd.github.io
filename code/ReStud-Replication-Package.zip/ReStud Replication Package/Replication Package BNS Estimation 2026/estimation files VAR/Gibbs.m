function [Phi_var,Sig_var,PHIF_var,DD_var,Y_var,PHIFpm_var,DDpm_var,XX_var] = Gibbs(data,spec,cases)

[nT,nv]  = size(data);
r.beta   = spec.Phi;
r.sigma  = spec.Sig;
Phi_var  = zeros(spec.nsim,size(spec.Phi,1)-1,size(spec.Phi,2));
Sig_var  = zeros(spec.nsim,size(spec.Sig,1),size(spec.Sig,2));
Y_var    = zeros(spec.nsim,nT,nv);
PHIF_var = zeros(spec.nsim,max(size(spec.Phi))-1,max(size(spec.Phi))-1);
DD_var   = zeros(spec.nsim,max(size(spec.Phi))-1);
XX_var   = zeros(spec.nsim,max(size(spec.Phi))-1);
RR       = [];
nI       = 500;
hyp_var    = zeros(spec.nsim/nI,length(spec.IndPhi)+1);
PHIFpm_var = zeros(spec.nsim/nI,max(size(spec.Phi))-1,max(size(spec.Phi))-1);
DDpm_var   = zeros(spec.nsim/nI,max(size(spec.Phi))-1);

for ii=1:spec.nsim
    if mod(ii,500)==0
    disp('                                                              ');
    disp(['       DRAW NUMBER:   ', num2str(ii)]                          );
    disp('                                                              ');
    disp(['       REMAINING DRAWS:   ', num2str(spec.nsim-ii)]                 );
    end

    % Kalman Smoother
    [~, ~, At_draw]  = evallh(data,r.beta,r.sigma);
    YY               = At_draw(:,1:nv);
    Y_var(ii,:,:)    = YY;
    XX_var(ii,:)     = At_draw(end,:);
    
    % Draw VAR coefficients
    if cases==1 
            RR.OPT = 0;
            RR.xh  = zeros(1,length(spec.IndPhi)+1);
    else
        if ii==1 || mod(ii,nI)==0
            RR.OPT = 1;
        else
            RR.OPT = 0;
            RR.xh  = r.xh;
        end
    end

    r = BVAR_PLR(YY,spec.lags,spec.mn,spec.H,spec.IndPhi,spec.SinglePhi,RR);

    % Save
    if mod(ii,nI)==0
        hyp_var(ii/nI,:)      = r.xh;
        PHIFpm_var(ii/nI,:,:) = r.PHIFpm;
        DDpm_var(ii/nI,:)     = r.DDpm;
    end
    Phi_var(ii,:,:)  = r.beta(2:end,:);
    Sig_var(ii,:,:)  = r.sigma;
    PHIF_var(ii,:,:) = r.PHIF;
    DD_var(ii,:)     = r.DD;
end

end




function [loglh,At_mat,At_draw,DD,PHIF] = evallh(YY,Phi,Sig)
    
    [T,nv] = size(YY);
   
    % selection matrix for missing observation
    PP = eye(nv);
    
    % model-coefficients
    [DD,ZZ,PHIF,RR,SIG] = coefficients(Phi,Sig);
    VV   = 0*eye(nv);
    mdim = size(PHIF,1);
    
    % initialization of the filter    
    At = zeros(mdim,1);    
    Pt = zeros(mdim,mdim);
    for kk=1:12
    Pt=PHIF*Pt*PHIF'+RR*SIG*RR';
    end
        
    At_mat = zeros(T,mdim);
    Pt_mat = zeros(T,mdim^2);
    
    loglh = 0;
    
    % Filter loop 
    for t = 1:T
        
        ind  = ~isnan(YY(t,:));
        data = YY(t,ind==1)';
        mO   = PP(:,ind==1)';
        mZ   = mO*ZZ;
        mV   = mO*VV*mO';
        
        At1  = At;
        Pt1  = Pt;

        % Forecasting   
        alphahat = DD + PHIF * At1 ;
        Phat     = PHIF * Pt1 * PHIF' + RR*SIG*RR';
        Phat     = 0.5*(Phat+Phat');
      
        yhat = mZ*alphahat;
        nut  = data - yhat;
       
        Ft = mZ*Phat*mZ' + mV;  
        Ft = 0.5*(Ft+Ft');
        
        [Up, Sp, Vp] = svd(Ft);
        sp = diag(Sp); kp = sum(sp>1e-10);
        inv_Ft = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
        det_Ft = prod(sp(1:kp));

        loglh = loglh-0.5*length(data)*log(2*pi)-0.5*log(det_Ft)-0.5*nut'*inv_Ft*nut;
        loglh = real(loglh);
                
        % Updating 
        At = alphahat + (Phat*mZ')*inv_Ft*nut;
        Pt = Phat - (Phat*mZ')*inv_Ft*(Phat*mZ')';
        At_mat(t,:)  = At';
        Pt_mat(t,:)  = reshape(Pt,1,mdim^2);
       
    end
   
    At_draw  = zeros(T,mdim);
    
    % singular value decomposition
    [u, s, v] = svd(reshape(Pt_mat(T,:),mdim,mdim));
    Pchol = u*sqrt(s);
    At_draw(T,:)   = At_mat(T,:)+(Pchol*randn(mdim,1))';
    Pt_draw(T,:,:) = reshape(Pchol,1,mdim^2); 
    
    % Kalman Smoother 
    for i = 1:T-1
                
        Att  = At_mat(T-i,:)';
        Ptt  = reshape(Pt_mat(T-i,:),mdim,mdim);

        Phat = PHIF * Ptt * PHIF' + RR*SIG*RR';
        Phat = 0.5*(Phat+Phat');
    
        [Up, Sp, Vp] = svd(Phat);
        sp = diag(Sp); kp = sum(sp>1e-8);
        inv_Phat = (Up(:,1:kp)*diag(1./sp(1:kp))*Vp(:,1:kp)')';
    
        nut   = At_draw(T-i+1,:)'- DD - PHIF*Att;
      
        Amean = Att + (Ptt*PHIF')*inv_Phat*nut;
        Pmean = Ptt - (Ptt*PHIF')*inv_Phat*(Ptt*PHIF')';   
  
        % singular value decomposition
        [um, sm, vm] = svd(Pmean);
        Pmchol = um*sqrt(sm);
        At_draw(T-i,:)   = (Amean+Pmchol*randn(mdim,1))'; 
        Pt_draw(T-i,:,:) = reshape(Pmchol,1,mdim^2);
         
    end
    
end



