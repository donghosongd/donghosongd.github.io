function [DD,ZZ,PHIF,RR,SIG] = coefficients(Phi,Sig)

nv   = size(Phi,2);
nlag = (size(Phi,1)-1)/nv;

PHIF = [Phi(2:end,:)';[kron(eye(nv),eye(nlag-1)) zeros(nv*(nlag-1),nv)]];
SIG  = Sig;
RR   = zeros(size(PHIF,1),size(SIG,2));
RR(1:size(SIG,1),:) = eye(size(SIG,1));
DD   = zeros(size(PHIF,1),1);
DD(1:nv) = Phi(1,:)';

ZZ   = zeros(nv,size(PHIF,1));
ZZ(:,1:nv) = eye(nv);

end
