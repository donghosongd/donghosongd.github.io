function DC_path = deterministic_components(DD,PHIF,Y,nT)

nv   = size(Y,2);
% DC: deterministic components a la GLP
nD   = length(DD);
nlag = size(PHIF,1)/nv;
selt = [eye(nv) zeros(nv,nD-nv)];
init = [reshape(Y(nlag:-1:1,:)',[],1);zeros(nD-length(reshape(Y(nlag:-1:1,:)',[],1)),1)];
DC   = @(t) selt*((eye(nD)-PHIF^(t-1))*inv(eye(nD)-PHIF)*DD + PHIF^(t-1)*init);

DC_path = zeros(nT,nv);
for tt=1:nT
    DC_path(tt,:) = DC(tt);
end


end