%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                               %
%  Replication codes for                                        %
%  "Inflation and Real Activity over the Business Cycle"        %
%  by Francesco Bianchi, Giovanni Nicolo`, and Dongho Song,     %
%  forthcoming at the Review of Economic Studies.               %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% estimate TC-VAR, 
MAIN_ESTIMATE_TCVAR

% The commented routines below (suffixes _lag4, _uncorr, _woSPF) reproduce the
% Online Appendix exhibits (then run Do_APPX_Figure_1, Do_APPX_Figure_2,
% Do_APPX_Table_1 to Do_APPX_Table_4). They are included in this folder but
% are not needed for the manuscript and are not run by RUN_ALL.m; uncomment
% to run them (about 10 additional hours).
% estimate TC-VAR with cycles modeled as VAR(4)
% MAIN_ESTIMATE_TCVAR_lag4
% estimate TC-VAR with uncorrelated trend and cycle shocks 
% MAIN_ESTIMATE_TCVAR_uncorr
% estimate TC-VAR without surveys
% MAIN_ESTIMATE_TCVAR_woSPF
% estimate VAR
MAIN_ESTIMATE_VAR

% estimate VAR with Angeletos et al. (2020)'s dataset
MAIN_ESTIMATE_VAR_AER 

% baseline max-share identification based on estimated TC-VAR
MAIN_IDSHOCKS_TCVAR_cyc2all

% max-share identification based on estimated TC-VAR with cycles modeled as VAR(4)
% MAIN_IDSHOCKS_TCVAR_cyc2all_lag4
% max-share identification based on estimated TC-VAR with uncorrelated trend and cycle shocks 
% MAIN_IDSHOCKS_TCVAR_cyc2all_uncorr
% max-share identification based on estimated TC-VAR without surveys
% MAIN_IDSHOCKS_TCVAR_cyc2all_woSPF
% alternative identification strategy based on estimated TC-VAR
MAIN_IDSHOCKS_TCVAR_obs

% alternative identification strategy based on estimated VAR
MAIN_IDSHOCKS_VAR

% alternative identification strategy based on estimated VAR with Angeletos et al. (2020)'s dataset
MAIN_IDSHOCKS_VAR_AER

% based on estimates from TC-VAR, draw the time-series of max-share shock targeting various (observed or cyclical) series
MAIN_SHOCK_DRAW_TCVAR

% based on estimates from VAR, draw the time-series of max-share shock targeting observed series
MAIN_SHOCK_DRAW_VAR

% recursive out-of-sample forecasting based on TC-VAR
MAIN_FORECAST_TCVAR

% recursive out-of-sample forecasting based on TC-VAR without survyes
MAIN_FORECAST_TCVAR_woSPF

% recursive out-of-sample forecasting based on VAR
MAIN_FORECAST_VAR

% recursive out-of-sample forecasting based on VAR with Angeletos et al. (2020)'s dataset
MAIN_FORECAST_VAR_AER
