clc;clear;close all

path('data',path)
path('estimation files',path)
path('figure',path)
path('forecasting results',path)
% path('gauss files',path)
path('max-share identification files',path)
path('other files',path)
path('results',path)

% Seed rng
rng(1234567890)

% load/convert data
load_data_unr_spf
str = str_ind(:,select); % Order labels to {Y,U,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}

% specification
H          = 20;
n          = 6;
p          = 2;
n0         = 1;   % obs 1  - 1955:Q2
n1         = 19;  % obs 19 - 1959:Q4
Ypre       = YY(n0:n1,:);
nv         = size(YY,2);

% pre-sample moments
pMN        = mean(Ypre(:,[1 2 3 4]));
pMN(:,3)   = mean(Ypre(:,3)-Ypre(:,4));
pSD        = nanstd(Ypre(:,[1 2 3 4]));

% add moments for survey measures which aren't available
pMN(5)     = pMN(4); pSD(5)     = pSD(4);
pMN(6)     = pMN(2); pSD(6)     = pSD(2);

b0         = zeros(n*p,n);  
d          = n+2;
Psi        = (pSD).^2; 
dtr        = 100;
Psitr      = [1/40  1/40  1/20  1/20]'; 

delta_mean = 0.0;
delta_var  = 0.1;
deltaT     = 10;
deltaV     = 0.1;

% store specification
spec        = [];
spec.corr   = 1;
spec.nsim   = 10000;
spec.nlags  = p;
spec.premom = [reshape(pMN,[],1) reshape(pSD,[],1)];
spec.nburn  = spec.nsim/2;
spec.skip   = 100;

% prior
spec.corrstd    = 0.1; % std of correlation loading c on tau
spec.b0         = b0;
spec.d          = d;
spec.Psi        = Psi;
spec.dtr        = dtr;
spec.Psitr      = Psitr;
spec.delta_mean = delta_mean;
spec.delta_var  = delta_var;
spec.deltaT     = deltaT;
spec.deltaV     = deltaV;
spec.meT        = 100;
spec.meV        = 0.1;
spec.tau_mean   = [0.5 0.75]';     % for dimension larger than 1, do constant constant... slope slope...
spec.tau_var    = diag([1.0 0.1]);
spec.tau_mean_post = spec.tau_mean;

% forecast of HH horizon
HH         = 12;
fn1        = 4;  % # of trends
fn2        = 6;  % # of cycles
fn3        = 1;  % # of errors

nStart     = find(time==2000);
nEnd       = find(time==2019.75)-HH;
YYpred_var = zeros(nEnd-nStart+1,HH,nv);
EEpred_var = zeros(nEnd-nStart+1,HH,nv);
MSE_var    = zeros(nEnd-nStart+1,HH,nv);
YF_var     = zeros(nEnd-nStart+1,HH,nv);
jsim       = 100;
j_ind      = 1:floor(spec.nsim/jsim):spec.nsim;
EE_var1    = zeros(nEnd-nStart+1,jsim,HH);
EE_var2    = zeros(nEnd-nStart+1,jsim,HH);
EE_var3    = zeros(nEnd-nStart+1,jsim,HH);
EE_var4    = zeros(nEnd-nStart+1,jsim,HH);

for estE   = nStart:nEnd


disp('                                                               ');
disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(spec.corr)]);
disp(['                          CORR STD :   ', num2str(spec.corrstd)]);
disp(['                          RECURSIVE SAMPLE:   ', num2str(estE-nStart+1)]        );
disp(['                          TOTAL SAMPLE:   ',num2str(nEnd-nStart+1)]);

% define sample    
YYY        = YY(n1+1:estE,:);
YF         = YY(estE+1:estE+HH,:);
T          = size(YYY,1);

% initial guess: 
init        = [];
init.Sig    = blkdiag(diag(spec.Psitr),diag(spec.Psi));
init.Phi    = spec.b0;
init.delta  = delta_mean;
init.SigE   = 0.1*nanvar(YYY(:,6));
init.SigM   = 0.0*nanvar(YYY(:,4)); % size of inflation measurement error variance
init.rhoT   = spec.tau_mean(2);
init.muT    = spec.tau_mean(1);   


% run Gibbs sampler
[Phi_var,Sig_var,Y_trend,Y_cycle,inf_err,Svy_var,para_trend,XX_var] = Gibbs(YYY,spec,init);

YYpred = zeros(spec.nsim,HH,nv);
EEpred = zeros(spec.nsim,HH,size(init.Sig,1)+fn3);
XXpred = zeros(spec.nsim,HH,size(XX_var,2));

for ii=1:spec.nsim
    Phi   = squeeze(Phi_var(ii,:,:))';
    Sig   = squeeze(Sig_var(ii,:,:));
    delta = Svy_var(ii,1);
    SigE  = Svy_var(ii,2);
    muT   = para_trend(ii,1);
    rhoT  = para_trend(ii,2);
     
    [DD,ZZ,PHI,RR,SIG] = coefficients(Phi,Sig,delta,SigE,muT,rhoT);

    for hh=1:HH
        EEpred(ii,hh,:) = chol(SIG)'*randn(size(SIG,1),1);
        if hh>1
        XXpred(ii,hh,:) = (DD + PHI*squeeze(XXpred(ii,hh-1,:)) + RR*squeeze(EEpred(ii,hh,:)))';
        else
        XXpred(ii,hh,:) = (DD + PHI*XX_var(ii,:)' + RR*squeeze(EEpred(ii,hh,:)))';
        end
        YYpred(ii,hh,:) = ZZ*squeeze(XXpred(ii,hh,:)); 
    end
end

YYpred_var(estE-nStart+1,:,:) = squeeze(median(YYpred));
EEpred_var(estE-nStart+1,:,:) = YF-squeeze(median(YYpred));
MSE_var(estE-nStart+1,:,:)    = (YF-squeeze(median(YYpred))).^2;
YF_var(estE-nStart+1,:,:)     = YF;
EE_var1(estE-nStart+1,:,:)    = repmat(YF(:,1)',jsim,1)-squeeze(YYpred(j_ind,:,1));
EE_var2(estE-nStart+1,:,:)    = repmat(YF(:,2)',jsim,1)-squeeze(YYpred(j_ind,:,2));
EE_var3(estE-nStart+1,:,:)    = repmat(YF(:,3)',jsim,1)-squeeze(YYpred(j_ind,:,3));
EE_var4(estE-nStart+1,:,:)    = repmat(YF(:,4)',jsim,1)-squeeze(YYpred(j_ind,:,4));


end

% save forecast results
save(['forecasting results/forecast_tcvar_', num2str(estE-nStart+1), '_', num2str(spec.corr),'_', num2str(spec.corrstd),  '.mat'],...
    'EEpred_var','YYpred_var','MSE_var','EE_var1','EE_var2','EE_var3','EE_var4','YF_var','spec');










