clc;clear;close all

path('data',path)
path('estimation files',path)
path('results',path)

% Seed rng
rng(1234567890)

% load/convert data
load_data_unr_spf
str = str_ind(:,select); % Order labels to {Y,U,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}

% specification
H          = 20;
n          = 6;
p          = 4;
n0         = 1;   % obs 1  - 1955:Q2
n1         = 19;  % obs 19 - 1959:Q4
Ypre       = YY(n0:n1,:);

% pre-sample moments
pMN        = mean(Ypre(:,[1 2 3 4]));
pMN(:,3)   = mean(Ypre(:,3)-Ypre(:,4));
pSD        = nanstd(Ypre(:,[1 2 3 4]));

% add moments for survey measures which aren't available
pMN(5)     = pMN(4); pSD(5)     = pSD(4);
pMN(6)     = pMN(2); pSD(6)     = pSD(2);

b0         = zeros(n*p,n);  
d          = n+2;
Psi        = (pSD).^2; 
dtr        = 100;
Psitr      = [1/40  1/40  1/20  1/20]'; 

delta_mean = 0.0;
delta_var  = 0.1;
deltaT     = 10;
deltaV     = 0.1;

YYY        = YY(n1+1:end,:);
time       = time(n1+1:end);
[T,nv]     = size(YYY);

% store specification
spec        = [];
spec.corr   = 1;        % 1 allows correlation b/w tau/c shocks
spec.nsim   = 50000;
spec.nlags  = p;
spec.premom = [reshape(pMN,[],1) reshape(pSD,[],1)];
spec.nburn  = spec.nsim/2;
spec.skip   = 100;

% prior
spec.corrstd    = 0.1; % std of correlation loading c on tau, do not set to zero even if spec.corr=0
spec.b0         = b0;
spec.d          = d;
spec.Psi        = Psi;
spec.dtr        = dtr;
spec.Psitr      = Psitr;
spec.delta_mean = delta_mean;
spec.delta_var  = delta_var;
spec.deltaT     = deltaT;
spec.deltaV     = deltaV;
spec.meT        = 100;
spec.meV        = 0.1;
spec.tau_mean   = [0.5 0.75]';     % for dimension larger than 1, do constant constant... slope slope...
spec.tau_var    = diag([1.0 0.1]);
spec.tau_mean_post = spec.tau_mean;

% initial guess: 
init        = [];
init.Sig    = blkdiag(diag(spec.Psitr),diag(spec.Psi));
init.Phi    = spec.b0;
init.delta  = delta_mean;
init.SigE   = 0.1*nanvar(YYY(:,6));
init.SigM   = 0.0*nanvar(YYY(:,4)); % size of inflation measurement error variance, we set to zero
init.rhoT   = spec.tau_mean(2);
init.muT    = spec.tau_mean(1);   

%% run Gibbs sampler
[Phi_var,Sig_var,Y_trend,Y_cycle,inf_err,Svy_var,para_trend,XX_var] = Gibbs(YYY,spec,init);

% save estimation results
save(['results/estimation_tcvar_lag4_', num2str(spec.corr),'_', num2str(spec.corrstd), '.mat'],...
    'XX_var','Phi_var','Sig_var','para_trend','Svy_var','Y_trend','Y_cycle','inf_err','spec','str');


