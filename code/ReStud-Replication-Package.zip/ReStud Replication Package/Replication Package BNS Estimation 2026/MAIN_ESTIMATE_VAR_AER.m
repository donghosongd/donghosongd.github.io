clc;clear

path('data',path)
path('estimation files VAR',path)
path('results',path)

% Seed rng
rng(1234567890)

% Loading the data
load('data_1955_2019.mat');  
time_data   = X_19(:,1);
data        = X_19(find(time_data== 1955.25):find(time_data==2019.75),2:11);
time_data   = time_data(find(time_data== 1955.25):find(time_data==2019.75),1);

str         = {' Output',' Investment',' Consumption',' Hours Worked',' Unemployment',' Labor Share',...
               ' Nom. Int. Rate',' Inflation',' Labor Prod.',' TFP'};

YY          = data;
order       = [1 2 3 5 4 10 6 8 7 9];
y           = YY(:,order);
variables   = str(order);

[T,n]      = size(y); 
spec       = [];
spec.lags  = 2;     % number of lags on the VAR
spec.nsim  = 50000; % number of posterior draws

for est_case=1:3
    
    % Defines the matrix with the linear transformations used to elicit the Long Run Prior
    %     Y   I   C   u   H  TFP wh/Y \pi  R  Y-H
spec.H = [
          1   1   1   0   0   0   0    0   0   0;  %Y+C+I
         -1   1   0   0   0   0   0    0   0   0;  %I-Y
         -1   0   1   0   0   0   0    0   0   0;  %C-Y
          0   0   0   1   0   0   0    0   0   0;  %u
          0   0   0   0   1   0   0    0   0   0;  %H
          0   0   0   0   0   1   0    0   0   0;  %TFP
          0   0   0   0   0   0   1    0   0   0;  %wh/Y
          0   0   0   0   0   0   0    1   1   0;  %\pi + R
          0   0   0   0   0   0   0   -1   1   0;  %R-\pi 
          1   0   0   0  -1   0   0    0   0  -1]; %Y-H-(Y-H) 

    if est_case==1
        % no prior
        spec.mn         = 0;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==2
        % optimize MN prior
        spec.mn         = 1;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==3
        % optimize MN+PLR prior
        spec.mn         = 1;
        spec.IndPhi     = ones(1,n);
        spec.SinglePhi  = 0;
    end

    % initialize
    spec.Phi        = zeros(1+n*spec.lags,n);
    % residual variance of AR(1) for each variable
    spec.Sig        = fitARmodel(y);

    % Gibbs sampler
    [Phi_var,Sig_var,PHIF_var,DD_var,Y_var,PHIFpm_var,DDpm_var] = Gibbs(y,spec,est_case);

    % deterministic components: GLP
    DC_path        = deterministic_components(DDpm_var(end,:)',squeeze(PHIFpm_var(end,:,:)),y(1:spec.lags,:),T+40);

    save(['results/estimation_var_aer_', num2str(est_case), '.mat'],'Phi_var','Sig_var','PHIFpm_var','DDpm_var','Y_var','variables','y','spec','DC_path');

end





















