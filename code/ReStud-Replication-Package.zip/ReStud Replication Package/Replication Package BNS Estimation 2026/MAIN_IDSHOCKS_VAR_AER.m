clc;clear;close all

path('max-share identification files',path)
path('results',path)

%%%%%%%%%%%%%%%%%%%% Load estimation results and settings
% load estimation results
for prior    = 1:3  % 1: Flat prior
                    % 2: Optimized MN prior
                    % 3: Optimized MN + LR prior

    load(['results/estimation_var_aer_', num2str(prior),'.mat'])  
    spec_id.prior = prior;
    
    % burn initial draws
    nsim    = spec.nsim;        spec_id.nsim     = nsim; 
    nburn   = spec.nsim/2;      spec_id.nburn    = nburn; 
    skip    = 10;       
    spec_id.skip     = skip;           
    skip_id = 1;                spec_id.skip_id  = skip_id;     
    
    grid_skip  = 1:skip:(nsim-nburn);
    grid_skip_id = 1:skip_id:(nsim-nburn)/skip;
    
    % after throwing initial draws, pick every `skip'th draw
    Phi_var    = Phi_var(nburn+1:nsim,:,:);
    Sig_var    = Sig_var(nburn+1:nsim,:,:);
    Phi_var    = Phi_var(grid_skip,:,:);
    Sig_var    = Sig_var(grid_skip,:,:);
    
    % to save time, pick every `skip_ident'th draw
    Phi_var_id = Phi_var(grid_skip_id,:,:);
    Sig_var_id = Sig_var(grid_skip_id,:,:);
    
    % Define vars
    ncyc    = size(Phi_var,3);  spec_id.ncyc  = ncyc;  % number of cyclical components
    nlags   = spec.lags;        spec_id.nlags = nlags; % number of lags
    ntrn    = 0;                spec_id.ntrn  = ntrn;  % number of trend components
    ne      = size(Sig_var,2);  spec_id.ne    = ne;    % number of shocks
    Ident   = eye(ncyc);
    
    %%%%%%%%%%%%%%%%% Max-share identification
    % Settings
    spec_id.maxhor  = 200;  
    spec_id.nrep    = 40;   
    spec_id.test    = 1;    
    spec_id.grid    = 1024;
    spec_id.alpha   = 68;   
    
    NameCase = {'var_aer'};
    spec_id.MYcyc = [zeros(ncyc,ntrn) eye(ncyc) zeros(ncyc)];
    
    spec_id.MY = spec_id.MYcyc;

    spec_id.ny    = size(spec_id.MY,1);  
    spec_id.all     = 0; 
    spec_id.Idv     = 1:spec_id.ny; 
    spec_id.ncase   = size(spec_id.Idv,2);
    
    spec_id.NameFD_ID = {'6-32-Q'};
    spec_id.FD_ID_WMIN = 2*pi/32;
    spec_id.FD_ID_WMAX =  2*pi/6;
    
    spec_id.NameFD_VC = {'6-32-Q'};
    spec_id.FD_VC_WMIN = 2*pi/32;
    spec_id.FD_VC_WMAX =  2*pi/6;
    
    for kk = 1:size(spec_id.FD_ID_WMIN,2)
        spec_id.namefd_id = spec_id.NameFD_ID(kk);
        spec_id.fd_id_wmin   = spec_id.FD_ID_WMIN(kk);   
        spec_id.fd_id_wmax   = spec_id.FD_ID_WMAX(kk);   
        
        spec_id.namefd_vc = spec_id.NameFD_VC(kk);
        spec_id.fd_vc_wmin   = spec_id.FD_VC_WMIN(kk);   
        spec_id.fd_vc_wmax   = spec_id.FD_VC_WMAX(kk);   
        
        [SVT,SVT_stat,IRFsr,VD] = identification_func_aer(Phi_var_id,Sig_var_id,spec_id);
        
        save(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
            spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat'],...
            'SVT','SVT_stat','IRFsr','VD','spec_id');
        
        clear SVT SVT_stat IRFsr VD 
    end
    clear
end
