function VDtmp = vdec(IRFe,Q,nrep)
    [N,k] = size(IRFe);
    col   = (N/nrep); 
    IRFq  = reshape(IRFe*Q,nrep,col);
    Vnum  = cumsum(IRFq.*IRFq,1);
    Vden  = zeros(nrep,col);
    for j=1:k
        tmp0 = reshape(IRFe(:,j),nrep,col);
        Vden = Vden+cumsum(tmp0.*tmp0,1);
    end
    VDtmp = Vnum./Vden;
end