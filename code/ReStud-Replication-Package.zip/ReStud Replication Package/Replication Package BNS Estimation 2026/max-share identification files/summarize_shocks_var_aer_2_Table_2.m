

spec_id.prior    = 2;
NameCase = {'var_aer'};
spec_id.NameFD_ID = {'6-32-Q'};
spec_id.NameFD_VC = {'6-32-Q'};

for kk = 1:size(spec_id.NameFD_ID,2)
    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);


    disp(' ')
    disp('------------------------------------------------------------------------------')
    disp(' ')
    disp('                          PRIOR:   Optimized Minnesota prior');
    disp(' ')
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    disp(['                          FREQUENCY VC:   ',[spec_id.NameFD_VC{1,kk}]]);
   
    % In the VAR
    str         = {' Output',' Investment',' Consumption',' Hours Worked',' Unemployment',' Labor Share',...
                   ' Nom. Int. Rate',' Inflation',' Labor Prod.',' TFP'};
    order_var       = [1 2 3 5 4 10 6 8 7 9];
    str1   = str(order_var);
    
    order  = [4,8];  

    norder = size(order,2);
    cnames = str1(order);
    alpha = spec_id.alpha;
    rnames = {'50',num2str((100-alpha)/2),num2str(100-(100-alpha)/2)};

    IC_sel = 4;  % Unemployment
    
    for jj = 1:size(IC_sel,2)
        ic   = IC_sel(jj); 
        
        disp(['                          SHOCK TARGET:  ',[str1{ic}]]);
        
        msvt = SVT_stat.msvt;
        lsvt = SVT_stat.lsvt;
        ssvt = SVT_stat.ssvt;
        
        disp(' ')
        SVTtmptbl = [msvt(ic,order);lsvt(ic,order);ssvt(ic,order)];
        r=printresults3(SVTtmptbl,cnames,rnames);
        disp(r)
        if exist('tbl_file','var'), export_table(r, tbl_file, ['VAR, Angeletos et al. (2020) data, optimized Minnesota prior; frequency ID ',spec_id.NameFD_ID{1,kk},'; frequency VC ',spec_id.NameFD_VC{1,kk}]); end
    end
end