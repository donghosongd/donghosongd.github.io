

spec_id.corr    = 1;
spec_id.corrstd = 0.1;
NameCase = {'TCVAR_wo_cyc2all'};  
spec_id.NameFD_ID = {'0-inf-Q'};
spec_id.NameFD_VC = {'0-inf-Q'};

for kk = 1:size(spec_id.NameFD_ID,2)

    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.corr),'_', num2str(spec_id.corrstd),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);

    ncyc = spec_id.ncyc;
    ntrn = spec_id.ntrn;
    ny   = spec_id.ny;
    nrep = spec_id.nrep;
    
    disp(' ')
    disp('------------------------------------------------------------------------------')
    disp(' ')
    disp('                          SURVEY EXPECTATIONS :  NO ');
    disp(' ')
    disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(spec_id.corr)]);
    disp(['                          CORR STD :   ', num2str(spec_id.corrstd)]);
    disp(' ')
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    disp(['                          FREQUENCY VC:   ',[spec_id.NameFD_VC{1,kk}]]);
    
    %              1 2 3 4  
    % Cycles: Y u R Δp 
    % Reorder columns in table as: u Y R Δp ;
    order      = [2,1,3,4];  
    
    %         1 2 3 4  
    % String: Y u R Δp 
    str1   = str([1 2 3 4]);
    
    norder = size(order,2);
    cnames = str1(order);
    alpha = spec_id.alpha;
    rnames = {'50',num2str((100-alpha)/2),num2str(100-(100-alpha)/2)};

    IC_sel = 2; % Unemployment


    for jj = 1:size(IC_sel,2)
        ic   = IC_sel(jj);  

        disp(['                          SHOCK TARGET:  Cyclical ',[str1{ic}]]);
        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')
        
        msvt = SVT_stat.msvt;
        lsvt = SVT_stat.lsvt;
        ssvt = SVT_stat.ssvt;
    
        disp(' ')
        disp('--------------------------')
        disp('Contributions to cyclical components');
        disp('--------------------------')
        disp(' ')
        SVTtmptblcyc = [msvt(ic,order);lsvt(ic,order);ssvt(ic,order)];
        r=printresults3(SVTtmptblcyc,cnames,rnames);
        disp(r)
        
    end
end