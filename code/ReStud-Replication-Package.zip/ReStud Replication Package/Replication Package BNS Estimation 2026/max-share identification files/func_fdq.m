function Q = func_fdq(modvar,S,wmin,wmax,idx,weight,grid,all)
  
    freqs   = linspace(1e-5,2*pi-1e-5,grid);
    F       = zeros(size(freqs));
    F(and((freqs>=wmin),(freqs<=wmax)))= 1;
    F(and((freqs>=(2*pi-wmax)),(freqs<=(2*pi-wmin))))= 1;
    
    ne      = size(S,2);
    MX      = modvar.mx;
    nx      = size(MX,1);
    MY      = modvar.my;
    ME      = [S(:,1:ne);zeros(nx-size(S,1),ne)];
    im      = sqrt(-1);
    zi      = exp(-im*freqs);
    r2pi    = 1/(2*pi);
    nidx    = size(idx,1)*size(idx,2);
    VD      = zeros(ne,ne);
    for i = 1:nidx
        sp      = zeros(grid,1);
        sp2     = zeros(grid,ne*ne);
        for gp = 1:grid
            if F(gp)==1
                fom     = MY(idx(i),:)*((eye(nx)-MX*zi(gp))\ME); 
                tmp     = r2pi*(fom*fom');
                tmp     = F(gp)*tmp;
                sp(gp)  = tmp;
                tmp     = r2pi*(fom'*fom);
                tmp     = F(gp)*tmp;
                sp2(gp,:) = (tmp(:))';
            end
        end        
        VTtmp           = 2*pi*real(ifft(sp,[],1));
        VDtmp           = 2*pi*real(ifft(sp2,[],1));
        VD              = VD+weight(i)*reshape(VDtmp(1,:)./VTtmp(1),ne,ne); 
    end
    [P,D]     = eig(VD);
    [~,imax]= max(abs(diag(D)));
    if all
        Q.D = D;
        Q.P = P;
    else
        Q       = real(P(:,imax));
    end
end