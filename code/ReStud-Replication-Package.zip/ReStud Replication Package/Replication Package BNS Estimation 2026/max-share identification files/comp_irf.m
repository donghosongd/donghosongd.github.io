
function irf = comp_irf(modvar,k,nrep)
  MX=modvar.mx;
  MY=modvar.my;
  ME=modvar.me;
  [nx,ne] = size(ME);
  I      = eye(ne);
  X      = zeros(nx,nrep);
  X(:,1) = ME*I(:,k);
  for t = 2:nrep
    X(:,t) = MX*X(:,t-1);
  end
  irf.y = (MY*X)';
  irf.x = X';
end

