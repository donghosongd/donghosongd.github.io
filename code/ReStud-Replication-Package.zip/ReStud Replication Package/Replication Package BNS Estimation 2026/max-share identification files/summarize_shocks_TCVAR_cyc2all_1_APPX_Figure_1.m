

spec_id.corr    = 1;
spec_id.corrstd = 0.1;
NameCase = {'TCVAR_cyc2all'};
spec_id.NameFD_ID = [{'0-inf-Q'},{'0-inf-Q'},{'0-inf-Q'},{'0-inf-Q'}];
spec_id.NameFD_VC = [{'0-inf-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}];

for kk = 1:1

    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.corr),'_', num2str(spec_id.corrstd),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);

    ncyc = spec_id.ncyc;
    ntrn = spec_id.ntrn;
    ny   = spec_id.ny;
    nrep = spec_id.nrep;
    
    disp(' ')
    disp('------------------------------------------------------------------------------')
    disp(' ')
    disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(spec_id.corr)]);
    disp(['                          CORR STD :   ', num2str(spec_id.corrstd)]);
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    
    %         1 2 3 4      5         6
    % Cycles: Y u R Δp Infl.Exp Unempl.Exp.4q
    % Reorder columns in table as: u Y Unempl.Exp.4q R Δp Infl.Exp. ;
    order      = [2,1,6,3,4,5];  % Ordering of cyclical vars
    order_obs  = [2,7,6,3,4,5];  % Ordering of observable vars to reflect log-level of output rather than its growth rate
    
    alpha = spec_id.alpha;
    
    IC_sel = 2; % Unemployment
    
    for jj = 1:size(IC_sel,2)
        ic   = IC_sel(jj); 

        disp(['                          SHOCK TARGET:  Cyclical  ',[str{ic}]]);
        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')

        % IRFs to identified shock
        med = NaN(nrep*ny,1); pcm = NaN(nrep*ny,1); pcs = NaN(nrep*ny,1);
        tmp     = IRFsr(ic,:,:);
        for i=1:nrep*ny
            med(i)  = median(tmp(1,:,i));
            pcm(i)     = prctile(tmp(1,:,i),(100-alpha)/2) ;
            pcs(i)     = prctile(tmp(1,:,i),100-(100-alpha)/2) ;
        end
        Y       = reshape(med,nrep,ny);
        sgy     = sign(Y(1,1));
        Y       = sgy*Y;
        Ym      = reshape(pcm,nrep,ny);
        Ym      = sgy*Ym;
        Ys      = reshape(pcs,nrep,ny);
        Ys      = sgy*Ys;
        
        % Plot IRFs
        if kk ==1 
            scrsz = get(0,'ScreenSize');
            set(0,'defaulttextinterpreter','latex')
            set(0,'defaultaxesfontname','times')
            set(0,'DefaultAxesFontSize',30)
            set(0,'DefaultTextFontSize',30);
    
            vname     = {'Unemployment','Output','Unemployment exp.(1y)',...
                 'Interest rate','Inflation','Inflation exp.(1y)'};
            Case      = str(ic);
            fig_title = string(strcat('IRFs: shock targeting ',Case));

            % IRFs of cycles, trends and observables to cyclical shocks
            for mm = 1:1
                if mm == 1
                    gr_hor  = 20;    % Graph horizon;
                end
                smpl    = 1:gr_hor;
                
                fig = figure('Position',[4,36,1703,753],'Name',fig_title,'Color','w','OuterPosition',[3,30,1705,836]);
                for i=1:length(order)
                    j      = order(i);
                    j_obs  = order_obs(i);
                    subplot(2,3,i);
                    hold on;
                        shadedplot(smpl,Ys(smpl,j)',Ym(smpl,j)',[0.83 0.83 0.999],[0.5 0.5 0.99]);
                    hold off;
                    hold on;
                        plot(smpl,Y(smpl,j),'color',[0.5 0.5 0.9],'linewidth',3); 
                        plot(smpl,Y(smpl,(ncyc+ntrn)+j_obs),'k');
                        plot(smpl,Ym(smpl,(ncyc+ntrn)+j_obs),'k--');
                        plot(smpl,Ys(smpl,(ncyc+ntrn)+j_obs),'k--');
                    
                    if j == 1 
                        plot(smpl,Y(smpl,end),'color',[1 0.7 0.7],'linewidth',2); 
                        plot(smpl,Ym(smpl,end),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                        plot(smpl,Ys(smpl,end),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                    elseif j == 2 | j ==6
                        plot(smpl,Y(smpl,6+2),'color',[1 0.7 0.7],'linewidth',2);
                        plot(smpl,Ym(smpl,6+2),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                        plot(smpl,Ys(smpl,6+2),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                    elseif j == 3 
                        plot(smpl,Y(smpl,6+3)+Y(smpl,6+4),'color',[1 0.7 0.7],'linewidth',2);
                        plot(smpl,Ym(smpl,6+3)+Ym(smpl,6+4),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                        plot(smpl,Ys(smpl,6+3)+Ys(smpl,6+4),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                    else
                        plot(smpl,Y(smpl,6+4),'color',[1 0.7 0.7],'linewidth',2);
                        plot(smpl,Ym(smpl,6+4),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                        plot(smpl,Ys(smpl,6+4),'color',[1 0.7 0.7],'LineStyle','--','linewidth',2);
                    end
                    hold off;
        
                    title(vname(i));
                    if ic == 2
                        if i==1 || i==3
                            ylim([-0.4 0.2])
                        elseif i ==2
                            ylim([-2 4])
                        elseif i==5 || i==6
                            ylim([-0.2 0.8])
                            yticks(-0.2:0.2:0.8)
                        end
                    end
                end
                str_ic = str{ic};
                print('-depsc2','figure/APPX_Figure_1.eps');
                exportgraphics(gcf, 'figure/APPX_Figure_1.pdf', 'ContentType', 'vector');
            end

        end   
    
    end
end