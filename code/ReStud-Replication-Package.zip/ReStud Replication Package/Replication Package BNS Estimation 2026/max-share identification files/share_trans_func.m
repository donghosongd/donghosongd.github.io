function [svt_ic] = share_trans_func(res,S,wmin,wmax,Q,grid)

    freqs   = linspace(1e-6,2*pi-1e-6,grid);
    Fsvt     = zeros(size(freqs));

    Fsvt(and((freqs>=wmin(1)),(freqs<=wmax(1))))= 1;
    Fsvt(and((freqs>=(2*pi-wmax(1))),(freqs<=(2*pi-wmin(1)))))= 1;
    
    MX      = res.mx;
    nx      = size(MX,1);
    ns      = size(S,1);
    ne      = size(S,2);
    MY      = res.my;
    ME0     = [S;zeros(nx-ns,ne)];
    ME2     = [S*Q;zeros(nx-ns,1)];
    im      = sqrt(-1);
    zi      = exp(-im*freqs);
    r2pi    = 1/(2*pi);
    ny      = size(MY,1);
    svt_ic   = zeros(1,ny);
    
    for i = 1:ny
        spsvt0     = zeros(grid,1);
        
        spsvt2     = zeros(grid,1);
        
        for gp = 1:grid
            if Fsvt(gp)==1
                fom0        = MY(i,:)*((eye(nx)-MX*zi(gp))\ME0);
                fom2        = MY(i,:)*((eye(nx)-MX*zi(gp))\ME2);
                spsvt0(gp)   = r2pi*(fom0*fom0');
                spsvt2(gp)   = r2pi*(fom2*fom2');
            end
          
        end
        spsvt0(isnan(spsvt0))=0;
        spsvt2(isnan(spsvt2))=0;

        V0tmp       = 2*pi*real(ifft(spsvt0,[],1));
        V2tmp       = 2*pi*real(ifft(spsvt2,[],1));
        svt_ic(i)    = 100*V2tmp(1)/V0tmp(1); 
              
    end
end