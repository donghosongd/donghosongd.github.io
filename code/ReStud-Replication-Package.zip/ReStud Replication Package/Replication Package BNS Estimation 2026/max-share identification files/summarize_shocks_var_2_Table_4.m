

spec_id.prior    = 2;
NameCase = {'var'};

spec_id.NameFD_ID = [{'6-32-Q'}, {'6-32-Q'}, {'6-32-Q'},{'16-50-Q'},{'16-50-Q'},{'16-50-Q'},{'32-50-Q'},{'32-50-Q'},{'32-50-Q'},]; 
spec_id.NameFD_VC = [{'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}]; 

for kk = 1:size(spec_id.NameFD_ID,2)
    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
    spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat'],'spec_id');

    ny   = spec_id.ny;
    nrep = spec_id.nrep;

    %              1   2 3 4      5           6              7          8
    % MY for VAR: Ygr u R Δp Infl.Exp.4q Infl.Exp.40q Unempl.Exp.4q   Ylvl
    % Reorder columns in table as: Δp
    order  = 4;  %  Inflation
    str1   = {'Output gr','Unemployment','Interest rate',...
             'Inflation','Inflation exp.(1y)','Inflation exp.(10y)','Unemployment exp.(1y)','Output'};
     
    norder = size(order,2);
    cnames = str1(order);
    IC_sel    = 2; % Unemployment in VAR model
    
    alpha = spec_id.alpha;
    rnames = {'50',num2str((100-alpha)/2),num2str(100-(100-alpha)/2)};
      

    disp(' ')
    if kk == 1
        disp('                          PRIOR:          Optimized Minnesota prior');
        disp(['                          SHOCK TARGET:  ',[str1{IC_sel(1)}]]);
        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')
    else
        disp('------------------------------------------------------------------------------')
        disp(' ')
    end
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    disp(['                          FREQUENCY VC:   ',[spec_id.NameFD_VC{1,kk}]]);
  
    for jj = 1:1
        load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);

        ic   = IC_sel(jj); 
        
        msvt = SVT_stat.msvt;
        lsvt = SVT_stat.lsvt;
        ssvt = SVT_stat.ssvt;
        
        disp(' ')
        SVTtmptbl = [msvt(ic,order);lsvt(ic,order);ssvt(ic,order)];
        r=printresults3(SVTtmptbl,cnames{:},rnames);
        disp(r)
        if exist('tbl_file','var'), export_table(r, tbl_file, ['VAR (baseline data, optimized Minnesota prior); frequency-band identification (max-share on unemployment); contribution to inflation; frequency ID ',spec_id.NameFD_ID{1,kk},'; frequency VC ',spec_id.NameFD_VC{1,kk}]); end
    
    end
end