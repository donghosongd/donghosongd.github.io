

spec_id.corr    = 1;
spec_id.corrstd = 0.1;
NameCase = {'TCVAR_obs'};

spec_id.NameFD_ID = [{'6-32-Q'}, {'6-32-Q'}, {'6-32-Q'},{'16-50-Q'},{'16-50-Q'},{'16-50-Q'},{'32-50-Q'},{'32-50-Q'},{'32-50-Q'},]; 
spec_id.NameFD_VC = [{'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}]; 

for kk = 1:size(spec_id.NameFD_ID,2)
    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.corr),'_', num2str(spec_id.corrstd),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);
        
    ny   = spec_id.ny;
    nrep = spec_id.nrep;

    str{1,1} = ' Output gr';
    str{1,8} = ' Output';
    str1   = str([1:5 7 8]); 
    order  = 4;  % Inflation

    norder = size(order,2);
    cnames = str1(order);
    alpha = spec_id.alpha;
    rnames = {'50',num2str((100-alpha)/2),num2str(100-(100-alpha)/2)};
    
    IC_sel = 2; % Unemployment

    disp(' ')
    if kk == 1
        disp(['                          SHOCKS CORRELATED, 1 YES :   ', num2str(spec_id.corr)]);
        disp(['                          CORR STD :   ', num2str(spec_id.corrstd)]);
        disp(['                          SHOCK TARGET:   ',[str1{IC_sel(1)}]]);
        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')
    else
        disp('------------------------------------------------------------------------------')
        disp(' ')
    end
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    disp(['                          FREQUENCY VC:   ',[spec_id.NameFD_VC{1,kk}]]);

    for jj = 1:1
        ic   = IC_sel(jj); 

        msvt = SVT_stat.msvt;
        lsvt = SVT_stat.lsvt;
        ssvt = SVT_stat.ssvt;
        
        disp(' ')
        SVTtmptbl = [msvt(ic,order);lsvt(ic,order);ssvt(ic,order)];
        r=printresults3(SVTtmptbl,cnames{:},rnames);
        disp(r)
        if exist('tbl_file','var'), export_table(r, tbl_file, ['TC-VAR; frequency-band identification (max-share on unemployment); contribution to inflation; frequency ID ',spec_id.NameFD_ID{1,kk},'; frequency VC ',spec_id.NameFD_VC{1,kk}]); end
    
    end
end