function [SVT,SVT_stat,IRFsr,VD] = identification_func_var(Phi_var_id,Sig_var_id,spec_id)

nsim    = spec_id.nsim ; 
nburn   = spec_id.nburn; 
skip    = spec_id.skip;           
skip_id = spec_id.skip_id;     

ncyc    = spec_id.ncyc;
nlags   = spec_id.nlags;
ntrn    = spec_id.ntrn;
ne      = spec_id.ne;

fd_id_wmin = spec_id.fd_id_wmin;     
fd_id_wmax = spec_id.fd_id_wmax;    
fd_vc_wmin = spec_id.fd_vc_wmin;    
fd_vc_wmax = spec_id.fd_vc_wmax;    
all_fd  = spec_id.all; 

maxhor  = spec_id.maxhor; 
nrep    = spec_id.nrep;  
test    = spec_id.test;
grid    = spec_id.grid;
alpha   = spec_id.alpha;

ncase = spec_id.ncase;
Idv   = spec_id.Idv;

Qmat    = zeros(ncase,(nsim-nburn)/(skip*skip_id),ne);      
MY      = spec_id.MY;
ny      = spec_id.ny;
IRFsr   = zeros(ncase,(nsim-nburn)/(skip*skip_id),ny*nrep); 
SVT   = zeros(ncase,(nsim-nburn)/(skip*skip_id),ny);        
VD      = zeros(ncase,(nsim-nburn)/(skip*skip_id),ny*maxhor);

disp('                                                               ');
disp('                          SHOCK IDENTIFICATION BEGINS          ');
ii      = 1;
tic
for im = ii:(nsim-nburn)/(skip*skip_id)
    
    % 1) Build the state space representation for draw i;
    S     = chol(squeeze(Sig_var_id(im,:,:)))'; 
    tmp   = squeeze(Phi_var_id(im,:,:))';      
    DYN   = tmp(:,1:ncyc*nlags);   
    MX    = blkdiag(eye(ntrn),[DYN;eye(ncyc*(nlags-1)) zeros(ncyc*(nlags-1),ncyc)]);
    nx    = size(MX,1);
    ME    = [S;zeros(nx-ncyc-ntrn,ne)];
    
    % Add output level 
    switch spec_id.NameCase{:}
        case 'var_wo'
            MYtmp   = [1 0 0 0   0 0 0 0]; 
        otherwise
            MYtmp   = [1 0 0 0 0 0 0   0 0 0 0 0 0 0];
    end
    
    MX    = [MX zeros(size(MX,1),1);
            MYtmp*MX eye(1)];  
    nx    = size(MX,1);
    ME    = [ME;MYtmp*ME];


    modvar.mx = MX;
    modvar.my = MY;
    modvar.me = ME;

    % 2) Compute IRFs from Choleski decomposition;
    Itmp1 = zeros(nrep*ny,ne);   
    Itmp2 = zeros(ny,ne);        
    Itmp3 = zeros(maxhor*ny,ne); 
    for k = 1:ne
        tmp        = comp_irf(modvar,k,maxhor);  
        ttmp       = tmp.y(1:nrep,:); 
        Itmp1(:,k) = (ttmp(:));
        Itmp2(:,k) = tmp.y(test,:)';
        vtmp       = tmp.y(1:maxhor,:);
        Itmp3(:,k) = (vtmp(:));
    end
    % 3) Identify the shock and compute IRFs and variance contributions
    for ic = 1:ncase
        idx             = Idv(ic);
        nidx            = size(idx,1)*size(idx,2); 
        weight          = ones(1,nidx)/nidx;  

        Q               = func_fdq(modvar,S,fd_id_wmin,fd_id_wmax,idx,weight,grid,all_fd);

        sgn             = sign((Itmp2(idx(1),:)*Q));    
        Qmat(ic,im,:)   = sgn*Q;
        IRFsr(ic,im,:)  = sgn*(Itmp1*Q);  

        [svt_ic]      = share_trans_func(modvar,S,fd_vc_wmin,fd_vc_wmax,Q,grid);      
        SVT(ic,im,:)  = svt_ic;
        VDtmp           = vdec(Itmp3,Q,maxhor);               
        VD(ic,im,:)     = (VDtmp(:));
    end

    if mod(im,10)==0
        disp('                                                               ');
        disp(['                          PRIOR:   ', num2str(spec_id.prior)]);
        disp(['                          FREQUENCY ID:   ',spec_id.namefd_id{1}]);
        disp(['                          FREQUENCY VC:   ',spec_id.namefd_vc{1}]);
        disp(['                          DRAW NUMBER:   ', num2str(im)]        );
        disp(['                          FULL DRAWS:   ',num2str((nsim-nburn)/(skip*skip_id))]);
        disp(['                          ELAPPSED TIME:   ',num2str(floor(toc)), ' SEC']);
        disp('                                                               ');
    end
end

asvt = zeros(ncase,ny);
msvt = zeros(ncase,ny);
lsvt = zeros(ncase,ny);
ssvt = zeros(ncase,ny);

for ic = 1:ncase
     asvt(ic,:) = mean(SVT(ic,:,:),2);
     msvt(ic,:) = median(SVT(ic,:,:),2);
     for jj=1:ny
         lsvt(ic,jj) = prctile(SVT(ic,:,jj),(100-alpha)/2) ;
         ssvt(ic,jj) = prctile(SVT(ic,:,jj),100-(100-alpha)/2);
     end  
     
end
SVT_stat.asvt = asvt;
SVT_stat.msvt = msvt;
SVT_stat.lsvt = lsvt;
SVT_stat.ssvt = ssvt;

end