

spec_id.corr    = 1;
spec_id.corrstd = 0.1;
NameCase = {'TCVAR_cyc2all'};
spec_id.NameFD_ID = [{'0-inf-Q'},{'0-inf-Q'},{'0-inf-Q'},{'0-inf-Q'}];
spec_id.NameFD_VC = [{'0-inf-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}];

for kk = 2:size(spec_id.NameFD_ID,2)

    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.corr),'_', num2str(spec_id.corrstd),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);

    ncyc = spec_id.ncyc;
    ntrn = spec_id.ntrn;
    ny   = spec_id.ny;
    nrep = spec_id.nrep;
    
    disp('------------------------------------------------------------------------------')
    disp(' ')
    disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
    disp(['                          FREQUENCY VC:   ',[spec_id.NameFD_VC{1,kk}]]);
    
    %         1 2 3 4      5         6
    % Cycles: Y u R Δp Infl.Exp Unempl.Exp.4q
    % Reorder columns in table as: u Y Unempl.Exp.4q R Δp Infl.Exp. ;
    order      = [2,1,6,3,4,5];  % Ordering of cyclical vars
    order_obs  = [2,7,6,3,4,5];  % Ordering of observable vars to reflect log-level of output rather than its growth rate
    
    %         1 2 3 4      5           6              7
    % String: Y u R Δp Infl.Exp.4q Infl.Exp.40q Unempl.Exp.4q
    str1   = str([1 2 3 4 5 7]);
    
    norder = size(order,2);
    cnames = str1(order);
    alpha = spec_id.alpha;
    rnames = {'50',num2str((100-alpha)/2),num2str(100-(100-alpha)/2)};
    
    IC_sel = 2; % Unemployment

    for jj = 1:size(IC_sel,2)
        ic   = IC_sel(jj); 

        disp(['                          SHOCK TARGET:   Cyclical  ',[str1{ic}]]);
        
        msvt = SVT_stat.msvt;
        lsvt = SVT_stat.lsvt;
        ssvt = SVT_stat.ssvt;
        
        disp(' ')
        disp('--------------------------')
        disp('Contributions to observables');
        disp('--------------------------')
        disp(' ')
        SVTtmptblobs = [msvt(ic,(ncyc+ntrn)+order_obs);lsvt(ic,(ncyc+ntrn)+order_obs);ssvt(ic,(ncyc+ntrn)+order_obs)];
        r=printresults3(SVTtmptblobs,cnames,rnames);
        disp(r)
        if exist('tbl_file','var'), export_table(r, tbl_file, ['TC-VAR; baseline identification (max-share on cyclical unemployment); contributions to observables; frequency ID ',spec_id.NameFD_ID{1,kk},'; frequency VC ',spec_id.NameFD_VC{1,kk}]); end

    end
end