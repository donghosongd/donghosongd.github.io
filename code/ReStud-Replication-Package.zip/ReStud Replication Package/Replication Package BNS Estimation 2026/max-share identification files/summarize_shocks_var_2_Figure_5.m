

spec_id.prior    = 2;
NameCase = {'var'};

spec_id.NameFD_ID = [{'6-32-Q'}, {'6-32-Q'}, {'6-32-Q'},{'16-50-Q'},{'16-50-Q'},{'16-50-Q'},{'32-50-Q'},{'32-50-Q'},{'32-50-Q'},]; 
spec_id.NameFD_VC = [{'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}, {'6-32-Q'},{'16-50-Q'},{'32-50-Q'}]; 

for kk = [1 4]
    load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
    spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat'],'spec_id');

    ny   = spec_id.ny;
    nrep = spec_id.nrep;

     
    %              1   2 3 4      5           6              7          8
    % MY for VAR: Ygr u R Δp Infl.Exp.4q Infl.Exp.40q Unempl.Exp.4q   Ylvl
    % Reorder columns in table as: u Ylvl R Δp 
    order  = [2,8,3,4];  
    str1   = {'Output gr','Unemployment','Interest rate',...
             'Inflation','Inflation exp.(1y)','Inflation exp.(10y)','Unemployment exp.(1y)','Output'};
     
    norder = size(order,2);
    
    IC_sel    = 2; % Unemployment 
    
    %                 1  2 3 4      5           6           7   
    % MY for TC-VAR: Ygr u R Δp Infl.Exp.4q Unempl.Exp.4q   Ylvl
    % Reorder columns in table as: u Ylvl Unempl.Exp.4q R Δp Infl.Exp.4q ;        
    order_tc = [2,7,3,4];
    IC_sel_tc = 2;  % Unemployment in TC-VAR model
    
    alpha = spec_id.alpha;
    

    for jj = 1:size(IC_sel,2)
        load(['results/identification_',NameCase{1,1},'_',num2str(spec_id.prior),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat']);

        ic   = IC_sel(jj);  
        ic_tc = IC_sel_tc(jj);
        
        % IRFs to identified shock
        gr_hor  = 20;              % Graph horizon;
        smpl    = 1:gr_hor;
        
        med = NaN(nrep*ny,1); pcm = NaN(nrep*ny,1); pcs = NaN(nrep*ny,1);
        tmp     = IRFsr(ic,:,:);
        for i=1:nrep*ny
            med(i)  = median(tmp(1,:,i));
            pcm(i)     = prctile(tmp(1,:,i),(100-alpha)/2) ;
            pcs(i)     = prctile(tmp(1,:,i),100-(100-alpha)/2) ;
        end
        Y       = reshape(med,nrep,ny);
        sgy     = sign(Y(1,1));
        Y       = sgy*Y;
        Ym      = reshape(pcm,nrep,ny);
        Ym      = sgy*Ym;
        Ys      = reshape(pcs,nrep,ny);
        Ys      = sgy*Ys;

        Y  = Y(:, order); 
        Ym = Ym(:,order);
        Ys = Ys(:,order);


        % Get IRFs from TC-VAR w/ shock targeting observables and over same frequencies
        load(['results/identification_TCVAR_obs_1_0.1_',spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk}],'IRFsr')

        IRFsr_tc = IRFsr; clear IRFsr;
        ny_tc = size(IRFsr_tc,1);
        med_tc = NaN(nrep*ny_tc,1); pcm_tc = NaN(nrep*ny_tc,1); pcs_tc = NaN(nrep*ny_tc,1);
        tmp_tc     = IRFsr_tc(ic_tc,:,:);
        for i=1:nrep*ny_tc
            med_tc(i)  = median(tmp_tc(1,:,i));
            pcm_tc(i)     = prctile(tmp_tc(1,:,i),(100-alpha)/2) ;
            pcs_tc(i)     = prctile(tmp_tc(1,:,i),100-(100-alpha)/2) ;
        end
        Y_tc       = reshape(med_tc,nrep,ny_tc);
        sgy_tc     = sign(Y_tc(1,1));
        Y_tc       = sgy_tc*Y_tc;
        Ym_tc      = reshape(pcm_tc,nrep,ny_tc);
        Ym_tc      = sgy_tc*Ym_tc;
        Ys_tc      = reshape(pcs_tc,nrep,ny_tc);
        Ys_tc      = sgy_tc*Ys_tc;

        Y_tc     = Y_tc(:, order_tc); 
        Ym_tc    = Ym_tc(:,order_tc);
        Ys_tc    = Ys_tc(:,order_tc);


        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')
        disp('                          TC-VAR SHOCKS CORRELATED, 1 YES :   1');
        disp('                          TC-VAR CORR STD :   0.1');
        disp(' ')
        disp('                          PRIOR for VAR:  Optimized Minnesota prior');
        disp(' ')
        disp(['                          FREQUENCY ID:   ',[spec_id.NameFD_ID{1,kk}]]);
        disp(['                          SHOCK TARGET:   ',[str1{ic}]]);
        disp(' ')
        disp('------------------------------------------------------------------------------')
        disp(' ')

        % Plot IRFs         
        scrsz = get(0,'ScreenSize');
        set(0,'defaulttextinterpreter','latex')
        set(0,'defaultaxesfontname','times')
        set(0,'DefaultAxesFontSize',30)
        set(0,'DefaultTextFontSize',30);

        vname     = str1(order);
        Case      = str1(ic);
        fig_title = string(strcat('IRFs: shock targeting ',Case));
        
        if length(order) == 4
            fig = figure('Position',[6,185,1660,365],'Name',fig_title,'Color','w','OuterPosition',[5,179,1662,446]);
        elseif length(order) == 6
            fig = figure('Position',[4,36,1703,753],'Name',fig_title,'Color','w','OuterPosition',[3,30,1705,836]);
        end
        for ii=1:norder

            if length(order) == 4
                subplot(1,4,ii);
            elseif length(order) == 6
                subplot(2,3,ii);
            end
            
            shadedplot(smpl,Ys_tc(smpl,ii)',Ym_tc(smpl,ii)',[0.83 0.83 0.999],[0.5 0.5 0.99]);
            hold on;
                plot(smpl,Y_tc(smpl,ii),'color',[0.5 0.5 0.9],'linewidth',3); 
                plot(smpl,Y(smpl,ii),'k'); 
                plot(smpl,Ym(smpl,ii),'k--');
                plot(smpl,Ys(smpl,ii),'k--');
            hold off;

            title(vname(ii));
            if ii == 1
                ylabel({'';'Frequencies';spec_id.NameFD_ID{1,kk};''},'Interpreter','latex')
            end
            if ic ==2
                if order(ii)==2 || order(ii)==7
                    ylim([-0.6 0.2])
                    yticks(-0.6:0.2:0.2)
                elseif order(ii) == 8
                    ylim([-2 6])
                    yticks(-2:2:6)
                elseif order(ii)==3
                    ylim([-0.3 0.9])
                    yticks(-0.3:0.3:0.9)
                elseif order(ii)==4 
                    ylim([-0.3 0.6])
                    yticks(-0.3:0.3:0.6)
                elseif order(ii)==5 
                    ylim([-0.1 0.3])
                    yticks(-0.1:0.1:0.3)
                end
            elseif ic ==8
                if order(ii)==2 || order(ii)==7
                    ylim([-0.6 0.3])
                    yticks(-0.6:0.3:0.3)
                elseif order(ii)==8
                    ylim([-4 6])
                    yticks(-4:2:6)
                elseif order(ii)==3
                    ylim([-0.5 1])
                    yticks(-0.5:0.5:1)
                elseif order(ii)==4 
                    ylim([-0.6 0.6])
                    yticks(-0.6:0.3:0.6)
                elseif order(ii)==5 
                    ylim([-0.2 0.4])
                    yticks(-0.2:0.2:0.4)
                end            
            end
        end
        str_ic = str1{ic};
        print('-depsc2',['figure/Figure_5_',spec_id.NameFD_ID{1,kk},'.eps']);
        exportgraphics(gcf, ['figure/Figure_5_',spec_id.NameFD_ID{1,kk},'.pdf'], 'ContentType', 'vector');
        pause(1)
    end
end