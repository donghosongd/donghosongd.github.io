clc;clear

path('data',path)
path('estimation files VAR',path)
path('results',path)

% Seed rng
rng(1234567890)

% Loading the data
load_data_unr_spf
str        = str_ind(:,select);          % Order labels to {Y,U,R,pi,Infl.Exp.4q,Infl.Exp.40q,UnR.Exp.4q}
y          = YY(20:end,[1 2 3 4 5 6 7]); % we use from 1960:Q1 onward (our data start from 1955:Q2)
n1         = find(time_data==1991);
variables  = str([1 2 3 4 5 6 7]);


[T,n]      = size(y); 
spec       = [];
spec.lags  = 2;     % number of lags on the VAR
spec.nsim  = 50000; % number of posterior draws

for est_case=1:3
    
    % Defines the matrix with the linear transformations used to elicit the Long Run Prior
    %         Yg  U   R  \pi  \pi^e   \pi^e10 U^e
    spec.H = [
              1   0   0   0     0      0       0  ; % Y
              0   1   0   0     0      0       1  ; % U + U^e
              0   1   0   0     0      0      -1  ; % U - Y^e
              0   0   1  -1     0      0       0  ;
              0   0   0   0     1     -1       0  ;
              0   0   0  -1     1      0       0  ;
              0   0   0  -1     0     -1       0  ];

    if est_case==1
        % no prior
        spec.mn         = 0;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==2
        % optimize MN prior
        spec.mn         = 1;
        spec.IndPhi     = zeros(1,n);
        spec.SinglePhi  = 0;
    elseif est_case==3
        % optimize MN+PLR prior
        spec.mn         = 1;
        spec.IndPhi     = ones(1,n);
        spec.SinglePhi  = 0;
    end

    % initialize
    spec.Phi        = zeros(1+n*spec.lags,n);
    % residual variance of AR(1) for each variable
    spec.Sig        = fitARmodel(y);

    % Gibbs sampler
    [Phi_var,Sig_var,PHIF_var,DD_var,Y_var,PHIFpm_var,DDpm_var] = Gibbs(y,spec,est_case);

    % deterministic components: GLP
    DC_path        = deterministic_components(DDpm_var(end,:)',squeeze(PHIFpm_var(end,:,:)),y(1:spec.lags,:),T+40);

    save(['results/estimation_var_', num2str(est_case), '.mat'],'Phi_var','Sig_var','DD_var','PHIFpm_var','DDpm_var','Y_var','variables','y','spec','DC_path');

end





















