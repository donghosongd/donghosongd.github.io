function r=printresults3(x,cdes,rdes)
% function hhh=printresults(x,cdes,rdes)
% x: data matrix
% cdes: colum names
% rdes: row names
aa='-------------------------------------';
if iscell(rdes)==0
    for i=1:size(rdes,1)
        rdes2{i}=rdes(i,:);
    end
else
    rdes2=rdes;
end
if size(cdes,1)<size(x,2)
    if iscell(cdes)
        cdes2=cdes;
    else
        for i=1:size(x,2)
            cdes2{i}=cdes;
        end
    end
else
    for i=1:size(x,2)
        cdes2{i}=cdes(i,:);
    end
end
r=[{aa(:,1:10)},cdes2;rdes2.',compose('%.1f', x)];