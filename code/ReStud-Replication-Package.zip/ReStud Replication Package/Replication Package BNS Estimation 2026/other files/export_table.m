function export_table(r, tbl_file, panel)
% EXPORT_TABLE  Append one panel of a table to a .csv file.
%
%   export_table(r, tbl_file, panel)
%
%   r        : cell array of strings returned by printresults3 (header row
%              followed by one row per posterior statistic), i.e. exactly
%              what is printed to the MATLAB console
%   tbl_file : path of the .csv file; created by the calling Do_Table_* script
%   panel    : text label describing the panel, written above the numbers
%
% The summarize_* scripts call this function only when the variable tbl_file
% exists, i.e. when they are invoked by a Do_Table_* script.

fid = fopen(tbl_file,'a');
fprintf(fid,'%s\n', panel);
for i = 1:size(r,1)
    fprintf(fid,'%s\n', strjoin(strtrim(r(i,:)),','));
end
fprintf(fid,'\n');
fclose(fid);
end
