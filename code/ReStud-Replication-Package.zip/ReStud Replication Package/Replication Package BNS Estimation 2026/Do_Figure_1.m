clear
close all
clc

path('figure',path)
path('other files',path)
path('data',path)
path('estimation files',path)
path('results',path)

load_data_unr_spf
n1         = 19;  % obs 19 - 1959:Q4
YYY        = YY(n1+1:end,:);
time       = time(n1+1:end);
[T,nv]     = size(YYY);

load('estimation_tcvar_1_0.1.mat')

plot_TrendCycle_Figure_1