clear
close all
clc

path('other files',path)
path('max-share identification files',path)
path('results',path)

tbl_file = 'results/Table_2.csv';   % the table printed below is also saved to this file
if exist(tbl_file,'file'), delete(tbl_file); end


disp(' ')
disp('------------------------------------------------------------------------------')
disp('------------------------------------------------------------------------------')
disp(' ')
disp('                         Baseline data   ');
disp(' ')
disp('------------------------------------------------------------------------------')
disp('------------------------------------------------------------------------------')
disp(' ')

summarize_shocks_var_1_Table_2;
summarize_shocks_var_2_Table_2;
summarize_shocks_var_3_Table_2;

disp(' ')
disp('------------------------------------------------------------------------------')
disp('------------------------------------------------------------------------------')
disp(' ')
disp('                         Angeletos et al. (2020) data   ');
disp(' ')
disp('------------------------------------------------------------------------------')
disp('------------------------------------------------------------------------------')
disp(' ')

summarize_shocks_var_aer_1_Table_2;
summarize_shocks_var_aer_2_Table_2;
summarize_shocks_var_aer_3_Table_2;

disp(' ')
disp('------------------------------------------------------------------------------')
disp('------------------------------------------------------------------------------')
