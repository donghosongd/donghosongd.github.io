clc;clear;close all

path('max-share identification files',path)
path('results',path)

%%%%%%%%%%%%%%%%%%%% Load estimation results and settings
% load estimation results
spec_id.corr    = 1;
spec_id.corrstd = 0.1;
load(['results/estimation_tcvar_wo_', num2str(spec_id.corr),'_', num2str(spec_id.corrstd),  '.mat'])  

% burn initial draws
nsim    = spec.nsim;        spec_id.nsim     = nsim; 
nburn   = spec.nburn;       spec_id.nburn    = nburn; 
skip    = 10;      
spec_id.skip  = skip;           
skip_id = 1;                spec_id.skip_id  = skip_id;     

grid_skip  = 1:skip:(nsim-nburn);
grid_skip_id = 1:skip_id:(nsim-nburn)/skip;

% after throwing initial draws, pick every `skip'th draw
Phi_var    = Phi_var(nburn+1:nsim,:,:);
Sig_var    = Sig_var(nburn+1:nsim,:,:);
Phi_var    = Phi_var(grid_skip,:,:);
Sig_var    = Sig_var(grid_skip,:,:);
para_trend = para_trend(grid_skip,:); % First column: constant for AR(1) trend growth
                                      % Second column: persistence of AR(1) trend growth

% to save time, pick every `skip_ident'th draw
Phi_var_id = Phi_var(grid_skip_id,:,:);
Sig_var_id = Sig_var(grid_skip_id,:,:);
para_trend_id = para_trend(grid_skip_id,:);

% Define vars
ncyc    = size(Y_cycle,3);  spec_id.ncyc  = ncyc;  % number of cyclical components
nlags   = spec.nlags;       spec_id.nlags = nlags; % number of lags
ntrn    = size(Y_trend,3);  spec_id.ntrn  = ntrn;  % number of trend components
ne      = size(Sig_var,2);  spec_id.ne    = ne;  % number of shocks
Ident   = eye(ncyc);

%%%%%%%%%%%%%%%%% Max-share identification
% Settings
spec_id.maxhor  = 200; 
spec_id.nrep    = 50;  
spec_id.test    = 1;   
spec_id.grid    = 1024;
spec_id.alpha   = 68;  

spec_id.MYobs = [1 0 0 0   1 0 0 0  -1 0 0 0    
                 0 1 0 0   0 1 0 0   0 0 0 0
                 0 0 1 1   0 0 1 0   0 0 0 0
                 0 0 0 1   0 0 0 1   0 0 0 0];

spec_id.MYtrn = [eye(ntrn) zeros(ntrn,ncyc*nlags)];

NameCase = {'TCVAR_wo_cyc2all'}; 
spec_id.NameCase = NameCase;

spec_id.MYcyc = [zeros(ncyc,ntrn) eye(ncyc) zeros(ncyc)];
spec_id.nycyc    = size(spec_id.MYcyc,1);   

spec_id.MY = [spec_id.MYcyc; spec_id.MYtrn; spec_id.MYobs];
spec_id.MY = [spec_id.MY zeros(size(spec_id.MY,1),2);
                zeros(2,size(spec_id.MY,2)) eye(2)];

spec_id.ny      = size(spec_id.MY,1);  
spec_id.all     = 0; 
spec_id.Idv     = 1:spec_id.nycyc; 
spec_id.ncase   = size(spec_id.Idv,2);

spec_id.NameFD_ID  = {'0-inf-Q'}; 
spec_id.FD_ID_WMIN =    0;   
spec_id.FD_ID_WMAX = 2*pi;

spec_id.NameFD_VC  = {'0-inf-Q'};
spec_id.FD_VC_WMIN =    0;
spec_id.FD_VC_WMAX = 2*pi;

for kk = 1:size(spec_id.FD_ID_WMIN,2)
    spec_id.namefd_id = spec_id.NameFD_ID(kk);
    spec_id.fd_id_wmin   = spec_id.FD_ID_WMIN(kk);   
    spec_id.fd_id_wmax   = spec_id.FD_ID_WMAX(kk);   
    
    spec_id.namefd_vc = spec_id.NameFD_VC(kk);
    spec_id.fd_vc_wmin   = spec_id.FD_VC_WMIN(kk);   
    spec_id.fd_vc_wmax   = spec_id.FD_VC_WMAX(kk);   
    
    [SVT,SVT_stat,IRFsr,VD] = identification_func_tcvar(Phi_var_id,Sig_var_id,para_trend_id,spec_id);
    
    save(['results/identification_',NameCase{1,1},'_',num2str(spec_id.corr),'_', num2str(spec_id.corrstd),'_',...
        spec_id.NameFD_ID{1,kk},'_', spec_id.NameFD_VC{1,kk},'.mat'],...
        'SVT','SVT_stat','IRFsr','VD','spec_id','str');
    
    clear SVT SVT_stat IRFsr VD 
end
