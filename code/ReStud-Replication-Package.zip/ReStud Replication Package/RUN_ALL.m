% RUN_ALL.m: master script for the replication package of
% "Inflation and Real Activity over the Business Cycle"
% (Bianchi, Nicolo`, Song; Review of Economic Studies).
% Runs the whole workflow, from the raw data to every figure and table.
% Run it from this folder. Console output is saved to RUN_ALL_log.txt.
% (The routines called below start with `clear`; this script uses no
% workspace variables.)

diary(fullfile(pwd,'RUN_ALL_log.txt'))
disp(['RUN_ALL started: ' char(datetime('now'))])

%% Step 1: data preparation (under a minute)
% Builds the three analysis datasets from the raw Excel files and copies
% them to "Replication Package BNS Estimation 2026/data".
cd('Replication Package BNS Data 2026')
MAIN_data
cd('..')

%% Step 2: estimation, identification, historical shocks, forecasting
% (about 44 hours; see the ReadMe for the time of each routine)
cd('Replication Package BNS Estimation 2026')
MASTER

%% Step 3: Figures 1-6 (saved to "figure") and Tables 1-4 (printed and
% saved to "results")
Do_Figure_1
Do_Figure_2
Do_Figure_3
Do_Figure_4
Do_Figure_5
Do_Figure_6
Do_Table_1
Do_Table_2
Do_Table_3
Do_Table_4
cd('..')

%% Step 4: simulation study and Figure 7 (saved to "figures")
cd('Replication Package BNS Simulation 2026')
MAIN_SIMULATION
Do_Figure_7
cd('..')

disp(['RUN_ALL finished: ' char(datetime('now'))])
diary off
