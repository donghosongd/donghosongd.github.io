clear; clc; close all

path('figures',path)
path('files',path)
path('estimates',path)

rng(1);

pmax  = 41;

%% DGP from TC-VAR
nx = 6; nz = 2; neps = 4;

sigcu  = 0.2;
sigcpi = 0.2;
sigtu  = 0.0;
sigtpi = 1.0;

ru  = 0.85;  Tu = 16;
rpi = 0.95; Tpi = 32;

au  = 2*ru*cos(2*pi/Tu);
bu  = -ru^2;

api = 2*rpi*cos(2*pi/Tpi);
bpi = -rpi^2;

psi = -25*pi/180;
qq  = [cos(psi) sin(psi);
      -sin(psi) cos(psi)];

rho1 = qq*diag([au, api])*qq';
rho2 = qq*diag([bu, bpi])*qq';


Phi = [1  0      0          0         0        0 ;
       0  1      0          0         0        0 ;
       0  0    rho1(1,1) rho1(1,2) rho2(1,1) rho2(1,2) ;
       0  0    rho1(2,1) rho1(2,2) rho2(2,1) rho2(2,2) ;
       0  0      1          0         0        0 ;
       0  0      0          1         0        0];

Lambda_x = [0  0   1     0    0   0;
            0  1   0     1    0   0 ];


Sigma = [sigtu  0      0     0;
           0  sigtpi   0     0;
           0    0    sigcu   0;
           0    0      0    sigcpi].^2;

R = [eye(neps);zeros(nx-neps,neps)];

% robust factorization for diagonal Sigma even if some variances are 0:
Q = diag(sqrt(diag(Sigma)));     % eps_t = Q w_t, w_t~N(0,I)


truepara = [rho1(1,1);rho1(1,2);rho1(2,2);rho2(1,1);rho2(1,2);rho2(2,2);sigtpi;sigcu;sigcpi];

%% simulate data to study small-sample issues

nT   = 1000;
T    = nT+pmax;
nsim = 100;

xvec = zeros(T,nx,nsim);
zvec = zeros(T,nz,nsim);

for jj=1:nsim
    w    = randn(T,neps);
    eps  = (Q*w')';
    for t = 1:T
        if t>1
            xvec(t,:,jj) = Phi*xvec(t-1,:,jj)' + R*eps(t,:)';
        else
            xvec(t,:,jj) = R*eps(t,:)';
        end
        zvec(t,:,jj) = Lambda_x*xvec(t,:,jj)';
    end
end

reverseStr = [];

summ_var   = [];
summ_tcvar = [];

para       = [0.85;16;0.95;32;-0.45;1.0;0.2];
   
for jj=1:nsim

    reverseStr = displayprogress(100*jj/nsim, reverseStr);

    summ_var_jj = [];

    z  = squeeze(zvec(:,:,jj));
    nY = size(z,2);


    %% VAR(p) estimation
    for p=1:pmax

        lhs  = z(p+1:nT+p,:);
        rhs = [];
        for lags = 1:p
            rhs = [rhs z(p+1-lags:nT+p-lags,:)];
        end
        rhs  = [rhs ones(nT,1)];
        beta = rhs \ lhs;
        sigu = ((lhs - rhs*beta)'*(lhs - rhs*beta)) / (nT - (nY*p+1));

        Dhatss    = chol(sigu)';
        VAR_PHIss = beta(1:nY*p,:)';
        MXvarss   = [VAR_PHIss;[kron(eye(p-1),eye(nY)) zeros(nY*(p-1),nY)]];
        MEvarss   = zeros(size(MXvarss,1),nY);
        MEvarss(1:nY,1:nY) = Dhatss;
        MYvarss   = zeros(nY,size(MXvarss,1));
        MYvarss(:,1:nY) = eye(nY);

        summ_var_jj{p}.MXvarss = MXvarss;
        summ_var_jj{p}.MEvarss = MEvarss;
        summ_var_jj{p}.MYvarss = MYvarss; 
        summ_var_jj{p}.Dhatss  = Dhatss;
    end

    summ_var{jj} = summ_var_jj;


    %% TC-VAR estimation
    
    YY    = z(1:nT+2,:); 

    bound = [[0.0  0.9999];  % ru
             [6    40];      % Tu
             [0.0  0.9999];  % rpi
             [6    40];      % Tpi
             [-1.0  0.0];    % psi
             [0.1  1.5];     % sigtpi
             [0.1  1.5]];    % sigcu 

    
    options = psoptimset('Display', 'off',  'UseParallel', 'always','TolFun',1e-8,...
                         'TolX',1e-20,'MaxIter',500,'CompletePoll', 'on', 'Vectorized','off','TolMesh', 1e-10);

    myfun   = @(x) evallh_1t2c(YY,x);

   
    para    = patternsearch(myfun,para,[],[],[],[],bound(:,1),bound(:,2),[],options);

    [DD,ZZ,PHIF,RR,SIG] = coefficients_1t2c(para);


    MX      = PHIF;
    ME      = diag(sqrt(diag(SIG)));
    MYVD    = ZZ(1:nY,:);
    MYID    = ZZ(1:nY,:); MYID(1:nY,1:2) = 0;

    summ_tcvar{jj}.para = para;
    summ_tcvar{jj}.MX   = MX;
    summ_tcvar{jj}.ME   = ME;
    summ_tcvar{jj}.MYVD = MYVD; 
    summ_tcvar{jj}.MYID = MYID;

end

save(['estimates/finitesample_1t2c_',num2str(nT),'.mat'],'truepara','summ_tcvar','summ_var','pmax');
