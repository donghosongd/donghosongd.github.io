%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                               %
%  Do_Figure_7: produces and exports the two panels of Figure 7 %
%                                                               %
%  Panel (A) "Figure_7_Population":   variance decompositions   %
%  based on population coefficients of the TC-VAR and of its    %
%  finite-lag VAR(p) approximations.                            %
%                                                               %
%  Panel (B) "Figure_7_FiniteSample": variance decompositions   %
%  based on finite-sample estimates. The routine to run before  %
%  is MAIN_SIMULATION.m, which simulates time series from the   %
%  TC-VAR and estimates finite-lag VAR(p) models on them (its   %
%  output is saved in estimates/finitesample_1t2c_1000.mat).    %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear; clc; close all

path('figures',path)
path('files',path)
path('estimates',path)

rng(1);

show_finite_sample = 1;
pmax               = 41;

if show_finite_sample ==1
    load('estimates/finitesample_1t2c_1000.mat')
    nsim =  length(summ_tcvar);
end


%% DGP from TC-VAR
nx = 6; nz = 2; neps = 4;

sigcu  = 0.2;
sigcpi = 0.2;
sigtu  = 0.0;
sigtpi = 1.0;

ru  = 0.85;  Tu = 16;
rpi = 0.95; Tpi = 32;

au  = 2*ru*cos(2*pi/Tu);
bu  = -ru^2;

api = 2*rpi*cos(2*pi/Tpi);
bpi = -rpi^2;

psi = -25*pi/180;
qq  = [cos(psi) sin(psi);
      -sin(psi) cos(psi)];

rho1 = qq*diag([au, api])*qq';
rho2 = qq*diag([bu, bpi])*qq';


Phi = [1  0      0          0         0        0 ;
       0  1      0          0         0        0 ;
       0  0    rho1(1,1) rho1(1,2) rho2(1,1) rho2(1,2) ;
       0  0    rho1(2,1) rho1(2,2) rho2(2,1) rho2(2,2) ;
       0  0      1          0         0        0 ;
       0  0      0          1         0        0];

Lambda_x = [0  0   1     0    0   0;
            0  1   0     1    0   0 ];


Sigma = [sigtu  0      0     0;
           0  sigtpi   0     0;
           0    0    sigcu   0;
           0    0      0    sigcpi].^2;

R = [eye(neps);zeros(nx-neps,neps)];

% robust factorization for diagonal Sigma even if some variances are 0:
Q = diag(sqrt(diag(Sigma)));     % eps_t = Q w_t, w_t~N(0,I)


%% Map to ABCD form
A = Phi;
B = R*Q;
C = Lambda_x*A;
D = Lambda_x*B;

[Omega,K,Dhat,Bhat,info] = solve_FV2007_eq25_iter(A,B,C,D,'Tol',1e-12,'MaxIter',10000,'Damping',0.8,'Ridge',1e-10);
assert(info.converged,'Riccati iteration did not converge');

% VAR infinity representation: x_{t} = \sum_{s=1}^{\infty} Psi(:,:,s)*x_{t-1} + u_t, u_t \sim N(0,\Sigma_u) where \Sigma_u = Dhat*Dhat';
Smax = 200;
F    = A - Bhat*(Dhat\C);
G    = Bhat / Dhat;
Psi  = zeros(nz,nz,Smax+1);
Fs  = eye(nx);
for s = 0:Smax
    Psi(:,:,s+1) = C*Fs*G;
    Fs = Fs*F;
end


%% max-share ID and VD
nY      = size(Lambda_x,1);
WfreqVD = [2*pi/32  2*pi/6;
           2*pi/50  2*pi/16];
nW      = size(WfreqVD,1);

WfreqID = [0 2*pi];
MX      = Phi;
ME      = Q;
MYVD    = Lambda_x;
MYID    = Lambda_x; MYID(1:nY,1:2) = 0;
Icase   = 1;    % location of max-share component based on MYID, which picks the 3rd component of state vector for truth,
                % and 1st component of observable vector for others

vdcomp_true    = zeros(nW,nY);      spectra_true    = [];
vdcomp_tcvar   = zeros(nW,nY);      spectra_tcvar   = [];
vdcomp_tcvarmx = zeros(nW,nY);      spectra_tcvarmx = [];


[vdc_true_c,~,~,Qat,Qbs] = maxShareID(MYID,MYID,MX,ME,Q,Icase,WfreqID,WfreqID,nY);


for bb=1:nW
    [vdc_true,sptr_true,frq_true]    = maxShareID(MYID,MYVD,MX,ME,Q,Icase,WfreqID,WfreqVD(bb,:),nY);
    vdcomp_true(bb,:)                = vdc_true;
    spectra_true.spectra{bb}         = sptr_true;
    spectra_true.frequency{bb}       = frq_true;

    [vdc_tcvar,sptr_tcvar,frq_tcvar] = maxShareID(MYVD,MYVD,MX,ME,Q,Icase,WfreqVD(bb,:),WfreqVD(bb,:),nY);
    vdcomp_tcvar(bb,:)               = vdc_tcvar;
    spectra_tcvar.spectra{bb}        = sptr_tcvar;


     % mix: max-share id based on 6-32 quarters, but conduct VD based on different frequency bands
    [vdc_tcvarmx,sptr_tcvarmx]       = maxShareID(MYVD,MYVD,MX,ME,Q,Icase,WfreqVD(1,:),WfreqVD(bb,:),nY);
    vdcomp_tcvarmx(bb,:)             = vdc_tcvarmx;
    spectra_tcvarmx.spectra{bb}      = sptr_tcvarmx;

end

vdcomp_var     = zeros(pmax,nW,nY);
vdcomp_varmx   = zeros(pmax,nW,nY);
spectra_diff   = zeros(pmax,nW);

for p=1:pmax

    % this is population VAR
    VAR_PHI = [];
    for lags=1:p
        VAR_PHI = [VAR_PHI squeeze(Psi(:,:,lags))];
    end
    MXvar = [VAR_PHI;[kron(eye(p-1),eye(nY)) zeros(nY*(p-1),nY)]];
    MYvar = zeros(nY,size(MXvar,1));
    MYvar(:,1:nY) = eye(nY);
    MEvar = zeros(size(MXvar,1),nY);
    MEvar(1:nY,1:nY) = Dhat;

    for bb=1:nW
        [vdc_varp,sptr_varp,frq_varp] = maxShareID(MYvar,MYvar,MXvar,MEvar,Dhat,Icase,WfreqVD(bb,:),WfreqVD(bb,:),nY);
        vdcomp_var(p,bb,:)            = vdc_varp;

        % mix: max-share id based on 6-32 quarters, but conduct VD based on different frequency bands
        [vdc_varpmx,sptr_varpmx]      = maxShareID(MYvar,MYvar,MXvar,MEvar,Dhat,Icase,WfreqVD(1,:),WfreqVD(bb,:),nY);
        vdcomp_varmx(p,bb,:)          = vdc_varpmx;

        idx   = find(frq_varp==1);
        err   = 0;
        for k = idx
            err   = err   + norm(sptr_varp(:,:,k)   - spectra_true.spectra{bb}(:,:,k),'fro');
        end
        err   = err   / numel(idx);

        spectra_diff(p,bb)   = err;
    end
end


%% Figure 7, Panel (A): based on population coefficients
vtitle = round((2*pi)./WfreqVD);

scrsz = get(0,'ScreenSize');
set(0,'defaulttextinterpreter','latex')
set(0,'defaultaxesfontname','times')
set(0,'DefaultAxesFontSize',23)
set(0,'DefaultTextFontSize',23);

fig = figure('Position',[20,20,900,600],'Name',...
'','Color','w','Position',[1 scrsz(4)/20 scrsz(3)/1.25 scrsz(4)/2.75]);

for ii=1:nW
    subplot(1,2*nW,nW*(ii-1)+1)
    hold on
    k1=plot([1:pmax],vdcomp_true(ii,1)*ones(pmax,1),'Color',[0.1 0.6 0.1],'linewidth',5);
    k2=plot([1:pmax],vdcomp_tcvar(ii,1)*ones(pmax,1),'b-^','linewidth',2,...
        'markerfacecolor',[0.7 0.7 0.9],'MarkerIndices', 1:6:pmax,'markersize',10);
    k3=plot([1:pmax],squeeze(vdcomp_var(:,ii,1)),'r-s','linewidth',2,...
        'markerfacecolor',[0.99 0.9 0.9],'MarkerIndices', 1:4:pmax,'markersize',12);
    kk=legend([k1,k2,k3],'TC-VAR: Baseline ID','TC-VAR: Freq.-band ID','VAR(p): Freq.-band ID','location','southwest');legend('boxoff');
    ylabel('Unemployment (\%)');xlabel('VAR lags (p)');
    title(sprintf('%d to %d quarters', vtitle(ii,2), vtitle(ii,1)));
    axis([1 pmax 0 100])

    subplot(1,2*nW,nW*(ii-1)+2)
    hold on
    k1=plot([1:pmax],vdcomp_true(ii,2)*ones(pmax,1),'Color',[0.1 0.6 0.1],'linewidth',5);
    k2=plot([1:pmax],vdcomp_tcvar(ii,2)*ones(pmax,1),'b-^','linewidth',2,...
        'markerfacecolor',[0.7 0.7 0.9],'MarkerIndices', 1:6:pmax,'markersize',10);
    k3=plot([1:pmax],squeeze(vdcomp_var(:,ii,2)),'r-s','linewidth',2,...
        'markerfacecolor',[0.99 0.9 0.9],'MarkerIndices', 1:4:pmax,'markersize',12);
    ylabel('Inflation (\%)');xlabel('VAR lags (p)');
    title(sprintf('%d to %d quarters', vtitle(ii,2), vtitle(ii,1)));
    axis([1 pmax 0 100])
end
print('-depsc2','figures/Figure_7_Population.eps');
exportgraphics(gcf, 'figures/Figure_7_Population.pdf', 'ContentType', 'vector');



if show_finite_sample==0
    return
end


%% Figure 7, Panel (B): based on finite-sample estimates
vdcomp_tcvar_base_ss_c = zeros(nY,nsim);
vdcomp_tcvar_base_ss   = zeros(nW,nY,nsim);
vdcomp_tcvar_freq_ss   = zeros(nW,nY,nsim);
vdcomp_tcvarmx_freq_ss = zeros(nW,nY,nsim);
vdcomp_var_freq_ss     = zeros(pmax,nW,nY,nsim);
vdcomp_varmx_freq_ss   = zeros(pmax,nW,nY,nsim);

spectra_diff_varss     = zeros(pmax,nW,nsim);
spectra_diff_tcvarss   = zeros(pmax,nW,nsim);


reverseStr = [];

for jj=1:nsim

    reverseStr = displayprogress(100*jj/nsim, reverseStr);

    MXss    = summ_tcvar{jj}.MX;
    MEss    = summ_tcvar{jj}.ME;
    MYssVD  = summ_tcvar{jj}.MYVD;
    MYssID  = summ_tcvar{jj}.MYID;
    Qss     = MEss;

    vdc_truess_c = maxShareID(MYssID,MYssID,MXss,MEss,Qss,Icase,WfreqID,WfreqID,nY);
    vdcomp_tcvar_base_ss_c(:,jj) = vdc_truess_c;


    for p=1:pmax
        MYvarss = summ_var{jj}{p}.MYvarss;
        MXvarss = summ_var{jj}{p}.MXvarss;
        MEvarss = summ_var{jj}{p}.MEvarss;
        Dhatss  = summ_var{jj}{p}.Dhatss;



        for bb=1:nW
            [vdc_truess,sptr_truess]             = maxShareID(MYssID,MYssVD,MXss,MEss,Qss,Icase,WfreqID,WfreqVD(bb,:),nY);
            vdcomp_tcvar_base_ss(bb,:,jj)        = vdc_truess;

            [vdc_tcvarss,sptr_tcvarss]           = maxShareID(MYssVD,MYssVD,MXss,MEss,Qss,Icase,WfreqVD(bb,:),WfreqVD(bb,:),nY);
            vdcomp_tcvar_freq_ss(bb,:,jj)        = vdc_tcvarss;

            [vdc_tcvarmxss,sptr_tcvarmxss]       = maxShareID(MYssVD,MYssVD,MXss,MEss,Qss,Icase,WfreqVD(1,:),WfreqVD(bb,:),nY);
            vdcomp_tcvarmx_freq_ss(bb,:,jj)      = vdc_tcvarmxss;

            [vdc_varpss,sptr_varpss,frq_varpss]  = maxShareID(MYvarss,MYvarss,MXvarss,MEvarss,Dhatss,Icase,WfreqVD(bb,:),WfreqVD(bb,:),nY);
            vdcomp_var_freq_ss(p,bb,:,jj)        = vdc_varpss;

            [vdc_varpssmx,sptr_varpssmx]         = maxShareID(MYvarss,MYvarss,MXvarss,MEvarss,Dhatss,Icase,WfreqVD(1,:),WfreqVD(bb,:),nY);
            vdcomp_varmx_freq_ss(p,bb,:,jj)      = vdc_varpssmx;

            idx        = find(frq_varpss==1);
            errvarss   = 0;
            errtcvarss = 0;
            for k = idx
                errvarss   = errvarss    + norm(sptr_varpss(:,:,k)   - spectra_true.spectra{bb}(:,:,k),'fro');
                errtcvarss = errtcvarss  + norm(sptr_truess(:,:,k)   - spectra_true.spectra{bb}(:,:,k),'fro');
            end
            errvarss   = errvarss   / numel(idx);
            errtcvarss = errtcvarss / numel(idx);

            spectra_diff_varss(p,bb,jj)    = errvarss;
            spectra_diff_tcvarss(p,bb,jj)  = errtcvarss;
        end
    end

end


disp('VD of cyclical components')
[quantile(vdcomp_tcvar_base_ss_c',0.16)' quantile(vdcomp_tcvar_base_ss_c',0.50)' quantile(vdcomp_tcvar_base_ss_c',0.84)']

fig = figure('Position',[20,20,900,600],'Name',...
'','Color','w','Position',[1 scrsz(4)/20 scrsz(3)/1.25 scrsz(4)/2.75]);

for ii=1:nW
    subplot(1,2*nW,nW*(ii-1)+1)
    hold on
    s2=shadedplot([1:pmax],quantile(squeeze(vdcomp_tcvar_base_ss(ii,1,:)),0.16)*ones(1,pmax),...
        quantile(squeeze(vdcomp_tcvar_base_ss(ii,1,:)),0.84)*ones(1,pmax),[0.9 0.9 0.9],[0.9 0.9 0.9]);
    hold on
    k2=plot([1:pmax],median(squeeze(vdcomp_tcvar_base_ss(ii,1,:)))*ones(pmax,1),'k-o','linewidth',2,...
        'markerfacecolor',[0.5 0.5 0.5],'MarkerIndices', 1:8:pmax,'markersize',10);
    k3=plot([1:pmax],median(squeeze(vdcomp_tcvar_freq_ss(ii,1,:)))*ones(pmax,1),'b-^','linewidth',2,...
        'markerfacecolor',[0.7 0.7 0.9],'MarkerIndices', 1:6:pmax,'markersize',10);
    k31=plot([1:pmax],quantile(squeeze(vdcomp_tcvar_freq_ss(ii,1,:)),0.16)*ones(pmax,1),'b--','linewidth',2);
    k32=plot([1:pmax],quantile(squeeze(vdcomp_tcvar_freq_ss(ii,1,:)),0.84)*ones(pmax,1),'b--','linewidth',2);
    k4=plot([1:pmax],median(squeeze(vdcomp_var_freq_ss(:,ii,1,:)),2),'r-s','linewidth',2,...
        'markerfacecolor',[0.99 0.9 0.9],'MarkerIndices', 1:4:pmax,'markersize',12);
    k41=plot([1:pmax],quantile(squeeze(vdcomp_var_freq_ss(:,ii,1,:))',0.16),'r--','linewidth',1);
    k42=plot([1:pmax],quantile(squeeze(vdcomp_var_freq_ss(:,ii,1,:))',0.84),'r--','linewidth',1);
    hold on
    k1=plot([1:pmax],vdcomp_true(ii,1)*ones(pmax,1),'Color',[0.1 0.6 0.1],'linewidth',4);


    kk=legend([k1,k2,k3,k4],'TC-VAR (P): Baseline ID','TC-VAR (F): Baseline ID',...
        'TC-VAR (F): Freq.-band ID','VAR(p) (F): Freq.-band ID','location','southwest');legend('boxoff');

    ylabel('Unemployment (\%)');xlabel('VAR lags (p)');
    title(sprintf('%d to %d quarters', vtitle(ii,2), vtitle(ii,1)));
    axis([1 pmax 0 100])

    subplot(1,2*nW,nW*(ii-1)+2)
    hold on
    s2=shadedplot([1:pmax],quantile(squeeze(vdcomp_tcvar_base_ss(ii,2,:)),0.16)*ones(1,pmax),...
        quantile(squeeze(vdcomp_tcvar_base_ss(ii,2,:)),0.84)*ones(1,pmax),[0.9 0.9 0.9],[0.9 0.9 0.9]);
    hold on
    k2=plot([1:pmax],median(squeeze(vdcomp_tcvar_base_ss(ii,2,:)))*ones(pmax,1),'k-o','linewidth',2,...
        'markerfacecolor',[0.5 0.5 0.5],'MarkerIndices', 1:8:pmax,'markersize',10);
    k3=plot([1:pmax],median(squeeze(vdcomp_tcvar_freq_ss(ii,2,:)))*ones(pmax,1),'b-^','linewidth',2,...
        'markerfacecolor',[0.7 0.7 0.9],'MarkerIndices', 1:6:pmax,'markersize',10);
    k31=plot([1:pmax],quantile(squeeze(vdcomp_tcvar_freq_ss(ii,2,:)),0.16)*ones(pmax,1),'b--','linewidth',2);
    k32=plot([1:pmax],quantile(squeeze(vdcomp_tcvar_freq_ss(ii,2,:)),0.84)*ones(pmax,1),'b--','linewidth',2);
    k4=plot([1:pmax],median(squeeze(vdcomp_var_freq_ss(:,ii,2,:)),2),'r-s','linewidth',2,...
        'markerfacecolor',[0.99 0.9 0.9],'MarkerIndices', 1:4:pmax,'markersize',12);
    k41=plot([1:pmax],quantile(squeeze(vdcomp_var_freq_ss(:,ii,2,:))',0.16),'r--','linewidth',1);
    k42=plot([1:pmax],quantile(squeeze(vdcomp_var_freq_ss(:,ii,2,:))',0.84),'r--','linewidth',1);
    hold on
    k1=plot([1:pmax],vdcomp_true(ii,2)*ones(pmax,1),'Color',[0.1 0.6 0.1],'linewidth',4);
    ylabel('Inflation (\%)');xlabel('VAR lags (p)');
    title(sprintf('%d to %d quarters', vtitle(ii,2), vtitle(ii,1)));
    axis([1 pmax 0 100])
end
print('-depsc2','figures/Figure_7_FiniteSample.eps');
exportgraphics(gcf, 'figures/Figure_7_FiniteSample.pdf', 'ContentType', 'vector');
