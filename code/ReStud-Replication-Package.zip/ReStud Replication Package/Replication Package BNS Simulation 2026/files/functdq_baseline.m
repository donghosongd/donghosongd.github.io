function q = functdq_baseline(res,S,idx,weight)
% Baseline (time-domain) max-share:
%   max_{q'Sigma q=1} q'(Sigma * A * Sigma)q,  A = sum_i w_i * sum_{j>=0} a_j'a_j
% where a_j = MY(idx(i),:)*MX^j*ME  and sum_{j>=0} a_j'a_j = ME' * X * ME,
% with X solving X = MX' X MX + C'C (discrete Lyapunov), C = MY(idx(i),:).

ne = size(S,2);
MX = res.mx;  nx = size(MX,1);
MY = res.my;
ME = [S(:,1:ne); zeros(nx-size(S,1),ne)];

Sigma = eye(ne);                      % identity: the shock covariance scale is already embedded in ME via S
L = chol(Sigma,'lower');

idx = idx(:);
A = zeros(ne);
for i=1:numel(idx)
    C = MY(idx(i),:);
%    X = dlyap(MX', C'*C);
    tol = 1e-10;
    X = zeros(nx); Phi_j = eye(nx);
    for j=0:20000
        add = Phi_j'*(C'*C)*Phi_j;
        X = X + add;
        if norm(add,'fro') < tol, break; end
        Phi_j = MX*Phi_j;
    end

    A = A + weight(i) * (ME' * X * ME);
end

[P,D] = eig(L' * A * L);
[~,k] = max(real(diag(D)));
u = real(P(:,k));
q = (L') \ u;
q = q ./ sqrt(real(q' * Sigma * q));  % enforce q'Sigma q = 1

end