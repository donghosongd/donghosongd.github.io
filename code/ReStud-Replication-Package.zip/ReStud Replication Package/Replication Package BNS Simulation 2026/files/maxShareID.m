function [vdc,spectr,frq,Q,Qbs] = maxShareID(MYID,MYVD,MX,ME,S,Icase,WfreqID,WfreqVD,nX)

% settings: Shock identification (i.e. Angeletos et al., 2020)
%grid    = 12*1024;
grid    = 1024;

all     = 0;     % If 1, reports both eigenvalues and eigenvectors. 
                 % If 0, only eigenvectors (corresponding to vector 'q' in paper).                    
Idv     = 1:nX;  % index of variable for which we maximize the variance contribution 


% Build the state space representation for draw i;
% S     = chol(Sig_var)'; 
% tmp   = Phi_var';      
% DYN   = tmp(:,1:nvar*p);   % drop constant if exists
% MX    = blkdiag(eye(ntn),[DYN;eye(nvar*(p-1)) zeros(nvar*(p-1),nvar)]);
% nx    = size(MX,1);
% ME    = [S;zeros(nx-nvar-ntn,ne)];


% state-space representation
modvar_vd.mx    = MX;
modvar_vd.my    = MYVD;    % observed
modvar_vd.me    = ME;

modvar_id.mx = MX;
modvar_id.my = MYID; % cyclical
modvar_id.me = ME;

% computes the MBC shock, then the IRFs, FEV and variance decomposition to this shock;
idx              = Idv(Icase);
nidx             = size(idx,1)*size(idx,2); 
weight           = ones(1,nidx)/nidx;  % weight to assign to each variable when trying to maximize other several variables.  
Q                = funcfdq(modvar_id,S,WfreqID(1),WfreqID(2),idx,weight,grid,all); % Computes the MBC shock targeting each case ic: alternative ID
Qbs              = functdq_baseline(modvar_id,S,idx,weight);                       % Computes the MBC shock targeting each case ic: baseline ID
[vdc,spectr,frq] = vdshare(modvar_vd,S,Q,grid,WfreqVD(1),WfreqVD(2));              % Computes the variance decomposition *over* two frequency bands (sr and lr) using *FD*


end

function Q = funcfdq(res,S,wmin,wmax,idx,weight,grid,all)
    % Computes the impulse vector for a specific set of variables
    freqs   = linspace(1e-11,2*pi-1e-11,grid);
    F       = zeros(size(freqs));
    F(and((freqs>=wmin),(freqs<=wmax)))= 1;
    F(and((freqs>=(2*pi-wmax)),(freqs<=(2*pi-wmin))))= 1;
    
    ne      = size(S,2);
    MX      = res.mx;
    nx      = size(MX,1);
    MY      = res.my;
    ME      = [S(:,1:ne);zeros(nx-size(S,1),ne)];
    im      = sqrt(-1);
    zi      = exp(-im*freqs);
    r2pi    = 1/(2*pi);
    nidx    = size(idx,1)*size(idx,2); % Julia: length(idx);
    VD      = zeros(ne,ne);
    for i = 1:nidx
        sp      = zeros(grid,1);
        sp2     = zeros(grid,ne*ne);
        for gp = 1:grid
            if F(gp)==1
                fom     = MY(idx(i),:)*((eye(nx)-MX*zi(gp))\ME); 
                tmp     = r2pi*(fom*fom');
                tmp     = F(gp)*tmp;
                sp(gp)  = tmp;
                tmp     = r2pi*(fom'*fom);
                tmp     = F(gp)*tmp;
                sp2(gp,:) = (tmp(:))';
            end
        end        
        sp(isnan(sp))   = 0.0;
        sp2(isnan(sp2)) = 0.0;
        VTtmp           = 2*pi*real(ifft(sp,[],1));
        VDtmp           = 2*pi*real(ifft(sp2,[],1));
        VD              = VD+weight(i)*reshape(VDtmp(1,:)./VTtmp(1),ne,ne); 
    end
    [P,D]     = eig(VD); 
    [~,imax]= max(abs(diag(D)));
    if all
        Q.D = D;
        Q.P = P;
    else
        Q       = real(P(:,imax));
    end
end





function [SVTsr,Sy_band,Fsr] = vdshare(res,S,Q,grid,wmin,wmax)
    % Computes the variance decomposition
    freqs   = linspace(1e-6,2*pi-1e-6,grid);
    Fsr     = zeros(size(freqs));   

    Fsr(and((freqs>=wmin(1)),(freqs<=wmax(1))))= 1;
    Fsr(and((freqs>=(2*pi-wmax(1))),(freqs<=(2*pi-wmin(1)))))= 1;
    
    MX      = res.mx;
    nx      = size(MX,1);
    ns      = size(S,1);
    ne      = size(S,2);
    MY      = res.my;
    ME0     = [S;zeros(nx-ns,ne)];
    ME2     = [S*Q;zeros(nx-ns,1)];
    im      = sqrt(-1);
    zi      = exp(-im*freqs);
    r2pi    = 1/(2*pi);
    ny      = size(MY,1);
    SVTsr   = zeros(1,ny);
    
    for i = 1:ny
        spsr0     = zeros(grid,1);
        spsr2     = zeros(grid,1);
        
        for gp = 1:grid
            if Fsr(gp)==1
                fom0        = MY(i,:)*((eye(nx)-MX*zi(gp))\ME0);
                fom2        = MY(i,:)*((eye(nx)-MX*zi(gp))\ME2);
                spsr0(gp)   = r2pi*(fom0*fom0');
                spsr2(gp)   = r2pi*(fom2*fom2');
            end
        end
        spsr0(isnan(spsr0))=0;
        spsr2(isnan(spsr2))=0;      

        V0tmp       = 2*pi*real(ifft(spsr0,[],1));
        V2tmp       = 2*pi*real(ifft(spsr2,[],1));
        SVTsr(i)    = 100*V2tmp(1)/V0tmp(1); % share in total Volatility
           
    end
    
    % full spectra (band-masked)
    Sy_band = complex(zeros(ny,ny,grid));

    for gp = 1:grid
        if Fsr(gp)==1
            X0 = (eye(nx) - MX*zi(gp)) \ ME0;   % nx×ne
            F0 = MY * X0;                       % ny×ne
            Sy_band(:,:,gp) = r2pi*(F0*F0');    % ny×ny
        end
    end

end