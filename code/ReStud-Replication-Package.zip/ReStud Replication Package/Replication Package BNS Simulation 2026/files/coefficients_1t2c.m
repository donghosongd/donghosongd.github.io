function [DD,ZZ,PHIF,RR,SIG,check] = coefficients_1t2c(para)

% state-space form for TC-VAR

ru      = para(1);
Tu      = para(2);
rpi     = para(3);
Tpi     = para(4);
psi     = para(5);
sigtpi  = para(6);
sigcu   = para(7);
sigcpi  = sigcu;


au  = 2*ru*cos(2*pi/Tu);
bu  = -ru^2;

api = 2*rpi*cos(2*pi/Tpi);
bpi = -rpi^2;

qq  = [cos(psi) sin(psi);
      -sin(psi) cos(psi)];

rho1 = qq*diag([au, api])*qq';
rho2 = qq*diag([bu, bpi])*qq';

PHIF = [1  0      0          0         0        0 ;
        0  1      0          0         0        0 ;
        0  0    rho1(1,1) rho1(1,2) rho2(1,1) rho2(1,2) ;
        0  0    rho1(2,1) rho1(2,2) rho2(2,1) rho2(2,2) ;
        0  0      1          0         0        0 ;
        0  0      0          1         0        0];

check = all(abs(eig(PHIF(3:end,3:end)))<1);

ZZ     = [0  0   1     0    0   0;
          0  1   0     1    0   0 ];

SIG  = [0     0     0       0 ;
        0  sigtpi   0       0 ;
        0     0   sigcu     0 ;
        0     0     0     sigcpi].^2;

nx   = size(PHIF,1);
neps = size(SIG,1);

RR   = [eye(neps);zeros(nx-neps,neps)];
DD   = zeros(nx,1);


end