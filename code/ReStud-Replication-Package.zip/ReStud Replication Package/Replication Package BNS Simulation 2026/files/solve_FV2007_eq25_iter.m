function [Omega,K,Dhat,Bhat,info] = solve_FV2007_eq25_iter(A,B,C,D,varargin)
%SOLVE_FV2007_EQ25_ITER  Fixed-point iteration for FV (2007) eq. (25a)-(25d)
%
% Solves the steady-state Riccati equation (25a) by iteration:
%   Omega = A*Omega*A' + B*B' - (A*Omega*C' + B*D') * (C*Omega*C' + D*D')^{-1} * (A*Omega*C' + B*D')'
% and then computes:
%   K    = (A*Omega*C' + B*D') * (C*Omega*C' + D*D')^{-1}              (25b)
%   Dhat*Dhat' = D*D' + C*Omega*C'                                     (25c)
%   Bhat = K*Dhat                                                      (25d)
%
% Inputs:
%   A (nx x nx), B (nx x ne), C (ny x nx), D (ny x ne)
%
% Name-value options:
%   'Omega0'   : initial Omega (nx x nx). Default: zeros(nx)
%   'Tol'      : convergence tol on relative Frobenius norm. Default: 1e-10
%   'MaxIter'  : max iterations. Default: 5000
%   'Damping'  : lambda in (0,1]. Default: 1 (no damping)
%   'Ridge'    : epsilon >= 0 added to S=C*Omega*C'+D*D'. Default: 0
%   'Verbose'  : true/false. Default: false
%
% Outputs:
%   Omega : converged state covariance (nx x nx)
%   K     : steady-state gain (nx x ny)
%   Dhat  : lower-triangular Cholesky factor so that Dhat*Dhat' = D*D' + C*Omega*C'
%   Bhat  : innovations loading = K*Dhat
%   info  : struct with fields iter, converged, relerr
%
% Notes:
% - Uses Cholesky to solve linear systems; avoids explicit inversion.
% - Symmetrizes Omega each iteration.

% ---------- parse options ----------
p = inputParser;
p.addParameter('Omega0', []);
p.addParameter('Tol', 1e-10);
p.addParameter('MaxIter', 5000);
p.addParameter('Damping', 1.0);
p.addParameter('Ridge', 0.0);
p.addParameter('Verbose', false);
p.parse(varargin{:});
opt = p.Results;

% ---------- dims / checks ----------
nx = size(A,1);
ny = size(C,1);
ne = size(B,2);

assert(isequal(size(A),[nx nx]), 'A must be nx-by-nx');
assert(size(B,1)==nx,            'B must be nx-by-ne');
assert(size(C,2)==nx,            'C must be ny-by-nx');
assert(size(D,1)==ny && size(D,2)==ne, 'D must be ny-by-ne');

if isempty(opt.Omega0)
    Omega = zeros(nx);
else
    Omega = opt.Omega0;
end
Omega = (Omega + Omega')/2;

tol     = opt.Tol;
maxIter = opt.MaxIter;
lam     = opt.Damping;
ridge   = opt.Ridge;
verbose = opt.Verbose;

if ~(lam>0 && lam<=1)
    error('Damping must be in (0,1].');
end
if ridge < 0
    error('Ridge must be >= 0.');
end

% ---------- iterate ----------
converged = false;
relerr = NaN;

for it = 1:maxIter
    % S = C*Omega*C' + D*D' (+ ridge I)
    S = C*Omega*C' + (D*D');
    if ridge > 0
        S = S + ridge*eye(ny);
    end
    S = (S + S')/2; % numerical symmetry

    % G = A*Omega*C' + B*D'
    G = A*Omega*C' + B*(D');

    % Compute K = G * S^{-1} via Cholesky
    [Ls,ps] = chol(S,'lower');
    if ps ~= 0
        % If not PD, add a small ridge adaptively
        epsTry = max(ridge, 1e-12);
        ok = false;
        for k = 1:12
            Stry = S + epsTry*eye(ny);
            Stry = (Stry + Stry')/2;
            [Ls,ps2] = chol(Stry,'lower');
            if ps2==0
                S = Stry; ps = 0; ok = true; break;
            end
            epsTry = epsTry * 10;
        end
        if ~ok
            error('Failed chol(S). S not PD even after ridge increases.');
        end
    end

    % Solve for K: K = G / S  = (G / (Ls')) / Ls
    % More stably: K = ( (G / Ls') / Ls )
    K = (G / (Ls')) / Ls;

    % Riccati update: Omega_new = A*Omega*A' + B*B' - K*S*K'
    Omega_new = A*Omega*A' + B*B' - K*S*K';
    Omega_new = (Omega_new + Omega_new')/2;

    % Damped update
    Omega_next = (1-lam)*Omega + lam*Omega_new;
    Omega_next = (Omega_next + Omega_next')/2;

    % convergence check
    relerr = norm(Omega_next - Omega,'fro') / max(1, norm(Omega,'fro'));
    if verbose && (mod(it,50)==0 || it==1)
        fprintf('iter %5d | relerr = %.3e\n', it, relerr);
    end

    Omega = Omega_next;

    if relerr < tol
        converged = true;
        break;
    end
end

% ---------- final K, Dhat, Bhat ----------
% Recompute with final Omega
S = C*Omega*C' + (D*D');
if ridge > 0
    S = S + ridge*eye(ny);
end
S = (S + S')/2;

G = A*Omega*C' + B*(D');

[Ls,ps] = chol(S,'lower');
if ps ~= 0
    error('Final chol(S) failed. Try increasing Ridge option.');
end
K = (G / (Ls')) / Ls;

% Dhat*Dhat' = D*D' + C*Omega*C'  (eq 25c)
Sigma_y = D*D' + C*Omega*C';
Sigma_y = (Sigma_y + Sigma_y')/2;

[Ly,py] = chol(Sigma_y,'lower');
if py ~= 0
    % add tiny ridge if needed
    epsTry = 1e-12;
    ok = false;
    for k = 1:12
        SigTry = Sigma_y + epsTry*eye(ny);
        SigTry = (SigTry + SigTry')/2;
        [Ly,py2] = chol(SigTry,'lower');
        if py2==0
            Sigma_y = SigTry; ok = true; break;
        end
        epsTry = epsTry * 10;
    end
    if ~ok
        error('Failed chol(D*D'' + C*Omega*C'').');
    end
end
Dhat = Ly;

% Bhat = K*Dhat  (eq 25d)
Bhat = K*Dhat;

% ---------- info ----------
info.iter      = it;
info.converged = converged;
info.relerr    = relerr;

if ~converged
    warning('Riccati iteration did not converge in %d iterations (relerr=%.3e). Try damping<1 or Ridge>0.', ...
        maxIter, relerr);
end
end
