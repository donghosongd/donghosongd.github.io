%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                               %
%  MAIN_data.m: builds the analysis datasets from the raw data  %
%  files (Data_*.xlsx) and copies them to the "data" folder of  %
%  the estimation package. Run from this folder.                %
%                                                               %
%  Output (saved in this folder and copied):                    %
%    data_1955_2019.mat   macroeconomic series                  %
%    data_infl_exp_19.mat inflation expectations                %
%    data_unr_exp_19.mat  unemployment expectations             %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
close all
clc

build_data_macro;
build_data_infl_exp_19;
build_data_unr_exp_19;

% copy the analysis datasets to the estimation package
if isfolder(fullfile('..','Replication Package BNS Estimation 2026','data'))
    copyfile('data_1955_2019.mat',  fullfile('..','Replication Package BNS Estimation 2026','data'));
    copyfile('data_infl_exp_19.mat',fullfile('..','Replication Package BNS Estimation 2026','data'));
    copyfile('data_unr_exp_19.mat', fullfile('..','Replication Package BNS Estimation 2026','data'));
    disp('Analysis datasets built and copied to ../Replication Package BNS Estimation 2026/data')
else
    warning('Estimation package folder not found: copy the three .mat files to its "data" folder manually.')
end
