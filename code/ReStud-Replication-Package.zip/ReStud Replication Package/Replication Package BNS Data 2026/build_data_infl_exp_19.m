clear; close; clc;

% Inflation expectations (quarterly, 1955:Q1-2019:Q4), read from the sheet
% "Data_expectations" of Data_expectations_inflation.xlsx:
%   column 1: date (year + quarter/4)
%   column 2: median SPF forecast of one-year-ahead PGDP inflation (INFPGDP1YR),
%             converted to a quarterly rate (x/4)
%   column 3: ten-year-ahead CPI inflation expectations (Blue Chip 1979:Q4-1991:Q1,
%             SPF INFCPI10YR from 1991:Q4), adjusted for the historical average difference between
%             CPI and PGDP inflation and converted to a quarterly rate (x/4)
% The sheets "Raw" and "Historical" of the same file contain the underlying
% SPF series, the adjusted ten-year series and the CPI-PGDP adjustment. The
% series are stored with 10-decimal precision.
%
% The Blue Chip values (column INFCPI10YR_BlueChip of sheet "Raw") are from
% the Federal Reserve Bank of Philadelphia file Additional-CPIE10.xlsx (copy in
% this folder). For each quarter in which that column is filled, the code
% computes (forecast - CPI-PGDP gap)/4.

xlsfile = 'Data_expectations_inflation.xlsx';

DATA = readmatrix(xlsfile,'Sheet','Data_expectations');
DATA = DATA(~isnan(DATA(:,1)),:);      % drop empty trailing rows

% Blue Chip forecasts, if the user has entered them in sheet "Raw"
% (columns: 1 YEAR, 2 QUARTER, 3 INFPGDP1YR, 4 INFCPI10YR_SPF,
%  5 INFCPI10YR_BlueChip, 6 Adj_INFCPI10YR_combined, 8 Historical gap)
RAW  = readmatrix(xlsfile,'Sheet','Raw');
RAW  = RAW(~isnan(RAW(:,1)),:);
gap  = RAW(1,8);                                       % 1955:Q2-2019:Q4 average CPI-PGDP inflation gap
ibc  = find(~isnan(RAW(:,5)));
if ~isempty(ibc)
    dates_bc = RAW(ibc,1) + (RAW(ibc,2)-1)/4;
    [ok,irow] = ismember(round(dates_bc,4), round(DATA(:,1),4));
    if ~all(ok), error('Blue Chip entries in sheet Raw have dates outside 1955:Q1-2019:Q4.'); end
    DATA(irow,3) = (RAW(ibc,5) - gap)/4;
    fprintf('Blue Chip forecasts found for %d quarters (%.2f-%.2f): adjusted ten-year series filled in.\n', ...
        numel(ibc), min(dates_bc), max(dates_bc));
else
    fprintf('NOTE: column INFCPI10YR_BlueChip is empty; the ten-year series is missing before 1991:Q4.\n');
end

data_infl_exp_19  = round(DATA,10);

infl_exp_dates_19 = data_infl_exp_19(:,1);
infl_exp_4q_19    = data_infl_exp_19(:,2);
infl_exp_40q_19   = data_infl_exp_19(:,3);

save('data_infl_exp_19','data_infl_exp_19','infl_exp_4q_19','infl_exp_40q_19','infl_exp_dates_19');
