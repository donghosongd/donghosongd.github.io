clear; close; clc;

DATA=xlsread('Data_macro_1955_2019.xlsx');
Dates	        = DATA(:,1);
A939RX0Q048SBEA	= DATA(:,2);
GDP	            = DATA(:,3);
GDPDEF	        = DATA(:,4);
DNDGRE1Q156NBEA	= DATA(:,5);
DSERRE1Q156NBEA	= DATA(:,6);
DDURRE1Q156NBEA	= DATA(:,7);
A006RE1Q156NBEA	= DATA(:,8);
OPHNFB	        = DATA(:,9);
PRS85006173	    = DATA(:,10);
PRS85006023	    = DATA(:,11);
CNP16OV	        = DATA(:,12);
CE16OV          = DATA(:,13);
UNRATE	        = DATA(:,14);
FEDFUNDS	    = DATA(:,15);
DTFPu           = DATA(:,16);

Y = 100*log(A939RX0Q048SBEA);
C = 100*log((DNDGRE1Q156NBEA + DSERRE1Q156NBEA).* A939RX0Q048SBEA);
I = 100*log((DDURRE1Q156NBEA + A006RE1Q156NBEA).* A939RX0Q048SBEA);
h = 100*log(PRS85006023.*CE16OV./CNP16OV);
R = FEDFUNDS/4;
yh = 100*log(OPHNFB);
why = 100*log(PRS85006173);

Dates = Dates(2:end);
Y = Y(2:end);
C = C(2:end);
I = I(2:end);
h = h(2:end);
pinf = 100 * log(GDPDEF(2:end)./GDPDEF(1:end-1));
unemp = UNRATE(2:end);
R = R(2:end);
yh = yh(2:end);
why = why(2:end);
TFP = cumsum(DTFPu(2:end)/4);

X_19 = [Dates Y  I C h unemp why R pinf yh TFP]; 

save("data_1955_2019",'X_19');
