clear; close; clc;

% Unemployment expectations (quarterly, 1955:Q1-2019:Q4), read from the sheet
% "UNEMP6" of Data_expectations_unemp.xlsx:
%   column 1: date (year + quarter/4)
%   column 2: median SPF forecast of the unemployment rate four quarters ahead
%             (UNEMP6, percent)
% The sheet "Median_Level" contains the series as downloaded from the
% Federal Reserve Bank of Philadelphia. The series is stored with 6-decimal
% precision.

DATA = readmatrix('Data_expectations_unemp.xlsx','Sheet','UNEMP6');
DATA = DATA(~isnan(DATA(:,1)),:);      % drop empty trailing rows
data_unr_exp_19  = round(DATA,6);

unr_exp_dates_19 = data_unr_exp_19(:,1);
unr_exp_4q_19    = data_unr_exp_19(:,2);

save('data_unr_exp_19','data_unr_exp_19','unr_exp_4q_19','unr_exp_dates_19');
